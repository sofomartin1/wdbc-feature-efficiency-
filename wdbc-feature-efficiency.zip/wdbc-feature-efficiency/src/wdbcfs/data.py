"""Data loading, validation and feature metadata."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import ROOT

PROPERTIES = [
    "radius", "texture", "perimeter", "area", "smoothness",
    "compactness", "concavity", "concave_points", "symmetry", "fractal_dimension",
]
FAMILIES = {"mean": "Mean", "error": "Standard error", "worst": "Worst"}


def feature_family(name: str) -> str:
    if name.startswith("mean_"):
        return "mean"
    if name.startswith("worst_"):
        return "worst"
    if name.endswith("_error"):
        return "error"
    raise ValueError(name)


def feature_property(name: str) -> str:
    fam = feature_family(name)
    if fam == "error":
        return name[: -len("_error")]
    return name[len(fam) + 1:]


def pretty(name: str) -> str:
    """Human-readable feature label, e.g. 'worst_concave_points' -> 'Worst concave points'."""
    fam = feature_family(name)
    prop = feature_property(name).replace("_", " ")
    if fam == "error":
        return f"{prop.capitalize()} (SE)"
    return f"{fam.capitalize()} {prop}"


def load(cfg: dict) -> tuple[pd.DataFrame, np.ndarray, list[str]]:
    """Return (X as DataFrame, y with 1 = Malignant, feature names) after validation."""
    df = pd.read_csv(ROOT / cfg["data"]["path"])
    label = cfg["data"]["label"]
    feats = [c for c in df.columns if c != label]
    if len(df) != cfg["data"]["expected_n"]:
        raise ValueError(f"expected {cfg['data']['expected_n']} rows, found {len(df)}")
    if len(feats) != cfg["data"]["expected_features"]:
        raise ValueError(f"expected {cfg['data']['expected_features']} features, found {len(feats)}")
    if df.isna().any().any():
        raise ValueError("missing values present")
    if set(df[label].unique()) != {"Malignant", "Benign"}:
        raise ValueError("label must be Malignant/Benign")
    y = (df[label] == cfg["study"]["positive_class"]).astype(int).to_numpy()
    X = df[feats].astype(float)
    return X, y, feats
