"""Single results store: scalars in results/estimates.json, tables as CSV, arrays as NPZ.

Figures and tables are rendered only from this store, so a number cannot appear in
a display without having been written here by an analysis script.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from .config import ROOT

RES = ROOT / "results"
EST = RES / "estimates.json"


def _clean(v):
    if isinstance(v, dict):
        return {str(k): _clean(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_clean(x) for x in v]
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return None if np.isnan(v) else float(v)
    if isinstance(v, float) and np.isnan(v):
        return None
    if isinstance(v, np.ndarray):
        return _clean(v.tolist())
    return v


def load_estimates() -> dict:
    if EST.exists():
        return json.loads(EST.read_text(encoding="utf-8"))
    return {}


def put(section: str, values: dict) -> None:
    """Replace one top-level section of estimates.json."""
    est = load_estimates()
    est[section] = _clean(values)
    EST.parent.mkdir(parents=True, exist_ok=True)
    EST.write_text(json.dumps(est, indent=1, sort_keys=True), encoding="utf-8")


def get(section: str) -> dict:
    return load_estimates()[section]


def save_table(name: str, df: pd.DataFrame) -> Path:
    p = RES / "tables" / f"{name}.csv"
    p.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(p, index=False, float_format="%.10g")
    return p


def load_table(name: str) -> pd.DataFrame:
    return pd.read_csv(RES / "tables" / f"{name}.csv", keep_default_na=True)


def save_arrays(name: str, **arrays) -> Path:
    p = RES / "arrays" / f"{name}.npz"
    p.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(p, **arrays)
    return p


def load_arrays(name: str):
    return np.load(RES / "arrays" / f"{name}.npz", allow_pickle=True)
