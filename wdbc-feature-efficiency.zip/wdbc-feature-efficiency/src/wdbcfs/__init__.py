"""wdbcfs — leakage-free feature-efficiency analysis of the WDBC breast-tumour dataset."""
__version__ = "1.0.0"
