"""Filter feature rankers and a fold-internal top-k selector.

All rankers are fitted on the training portion of a fold only, so the test fold
never influences which features are retained.
"""
from __future__ import annotations

import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_selection import chi2, mutual_info_classif


def score_features(X: np.ndarray, y: np.ndarray, method: str, seed: int = 0,
                   mi_neighbors: int = 3) -> np.ndarray:
    """Return one non-negative relevance score per feature (higher = more relevant).

    Correlation      |Pearson r| between feature and binary label (point-biserial).
    InformationGain  mutual information I(X_j; Y), k-NN estimator (Kraskov et al.).
    ChiSquare        chi-square statistic on min-max scaled features.
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y)
    if method == "Correlation":
        Xc = X - X.mean(0)
        yc = y - y.mean()
        den = np.sqrt((Xc ** 2).sum(0) * (yc ** 2).sum())
        return np.abs((Xc * yc[:, None]).sum(0) / den)
    if method == "InformationGain":
        return mutual_info_classif(X, y, n_neighbors=mi_neighbors, random_state=seed)
    if method == "ChiSquare":
        lo, hi = X.min(0), X.max(0)
        rng = np.where(hi - lo > 0, hi - lo, 1.0)
        stat, _ = chi2((X - lo) / rng, y)
        return np.nan_to_num(stat)
    raise ValueError(method)


def rank_from_scores(scores: np.ndarray) -> np.ndarray:
    """Feature indices ordered from most to least relevant (stable for ties)."""
    return np.argsort(-scores, kind="mergesort")


class TopK(BaseEstimator, TransformerMixin):
    """Keep the k highest-ranked features; columns are returned in original order."""

    def __init__(self, method: str = "Correlation", k: int = 5, seed: int = 0, mi_neighbors: int = 3,
                 order: np.ndarray | None = None):
        self.method = method
        self.k = k
        self.seed = seed
        self.mi_neighbors = mi_neighbors
        self.order = order  # optional precomputed ranking (used to reuse one ranking across k)

    def fit(self, X, y=None):
        if self.order is not None:
            order = np.asarray(self.order)
        else:
            order = rank_from_scores(score_features(X, y, self.method, self.seed, self.mi_neighbors))
        self.support_ = np.sort(order[: self.k])
        return self

    def transform(self, X):
        return np.asarray(X)[:, self.support_]
