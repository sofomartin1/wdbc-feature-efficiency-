"""Performance metrics and statistical procedures.

References for the procedures implemented here are listed in the repository README.
"""
from __future__ import annotations

import numpy as np
from scipy import stats
from sklearn.metrics import (brier_score_loss, cohen_kappa_score, matthews_corrcoef, roc_auc_score)

METRICS = ["AUC", "Accuracy", "Sensitivity", "Specificity", "PPV", "NPV", "F1", "MCC", "Kappa",
           "BalancedAccuracy", "Brier"]


# --------------------------------------------------------------------------- fold-level
def confusion(y, p, thr=0.5):
    yhat = (np.asarray(p) >= thr).astype(int)
    y = np.asarray(y)
    tp = int(((yhat == 1) & (y == 1)).sum())
    tn = int(((yhat == 0) & (y == 0)).sum())
    fp = int(((yhat == 1) & (y == 0)).sum())
    fn = int(((yhat == 0) & (y == 1)).sum())
    return tp, fp, fn, tn


def _div(a, b):
    return a / b if b else float("nan")


def classification_metrics(y, p, thr=0.5) -> dict:
    y = np.asarray(y)
    p = np.asarray(p, dtype=float)
    tp, fp, fn, tn = confusion(y, p, thr)
    yhat = (p >= thr).astype(int)
    sens = _div(tp, tp + fn)
    spec = _div(tn, tn + fp)
    ppv = _div(tp, tp + fp)
    out = {
        "AUC": roc_auc_score(y, p),
        "Accuracy": (tp + tn) / len(y),
        "Sensitivity": sens,
        "Specificity": spec,
        "PPV": ppv,
        "NPV": _div(tn, tn + fn),
        "F1": _div(2 * tp, 2 * tp + fp + fn),
        "MCC": matthews_corrcoef(y, yhat),
        "Kappa": cohen_kappa_score(y, yhat),
        "BalancedAccuracy": (sens + spec) / 2,
        "Brier": brier_score_loss(y, p),
        "TP": tp, "FP": fp, "FN": fn, "TN": tn,
    }
    return out


# --------------------------------------------------------------------------- resampling inference
def corrected_t(values, n_train: int, n_test: int, null: float = 0.0, alpha: float = 0.05,
                bounds: tuple | None = None) -> dict:
    """Nadeau-Bengio corrected resampled t statistic for J repeated-CV estimates.

    var_corrected = (1/J + n_test/n_train) * s^2, df = J - 1.
    """
    v = np.asarray(values, dtype=float)
    J = len(v)
    m = v.mean()
    s2 = v.var(ddof=1)
    se = np.sqrt((1.0 / J + n_test / n_train) * s2)
    tcrit = stats.t.ppf(1 - alpha / 2, J - 1)
    if se > 0:
        t = (m - null) / se
        p = 2 * stats.t.sf(abs(t), J - 1)
    else:  # every resampled difference identical: no evidence against the null when m equals it
        t = 0.0 if m == null else np.inf
        p = 1.0 if m == null else 0.0
    lo, hi = m - tcrit * se, m + tcrit * se
    if bounds is not None:  # metrics bounded on [0, 1] are truncated at the bound
        lo, hi = max(lo, bounds[0]), min(hi, bounds[1])
    return {"mean": m, "sd": np.sqrt(s2), "se": se, "lo": lo, "hi": hi,
            "t": t, "df": J - 1, "p": p}


def holm(pvals):
    p = np.asarray(pvals, dtype=float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    running = 0.0
    for rank, idx in enumerate(order):
        running = max(running, (m - rank) * p[idx])
        adj[idx] = min(1.0, running)
    return adj


def bh(pvals):
    p = np.asarray(pvals, dtype=float)
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m)
    prev = 1.0
    for rank in range(m - 1, -1, -1):
        idx = order[rank]
        prev = min(prev, p[idx] * m / (rank + 1))
        adj[idx] = prev
    return adj


# --------------------------------------------------------------------------- DeLong
def _midrank(x):
    order = np.argsort(x, kind="mergesort")
    xs = x[order]
    n = len(x)
    ranks = np.empty(n)
    i = 0
    while i < n:
        j = i
        while j < n and xs[j] == xs[i]:
            j += 1
        ranks[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    out = np.empty(n)
    out[order] = ranks
    return out


def delong(y, preds: list[np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
    """Fast DeLong (Sun & Xu, 2014): returns (AUCs, covariance matrix)."""
    y = np.asarray(y)
    pos = y == 1
    m, n = pos.sum(), (~pos).sum()
    P = np.vstack(preds).astype(float)
    k = P.shape[0]
    tx = np.empty((k, m))
    ty = np.empty((k, n))
    tz = np.empty((k, m + n))
    for r in range(k):
        x, yy = P[r, pos], P[r, ~pos]
        tx[r] = _midrank(x)
        ty[r] = _midrank(yy)
        tz[r] = _midrank(np.concatenate([x, yy]))
    aucs = tz[:, :m].sum(1) / (m * n) - (m + 1.0) / (2.0 * n)
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    sx = np.atleast_2d(np.cov(v01))
    sy = np.atleast_2d(np.cov(v10))
    cov = sx / m + sy / n
    return aucs, cov


def delong_ci(y, p, alpha=0.05):
    a, c = delong(y, [p])
    se = np.sqrt(c[0, 0])
    z = stats.norm.ppf(1 - alpha / 2)
    # logit-transformed interval keeps the bounds inside (0, 1)
    lg = np.log(a[0] / (1 - a[0]))
    se_l = se / (a[0] * (1 - a[0]))
    lo, hi = 1 / (1 + np.exp(-(lg - z * se_l))), 1 / (1 + np.exp(-(lg + z * se_l)))
    return float(a[0]), float(lo), float(hi)


def delong_diff(y, p1, p2, alpha=0.05):
    a, c = delong(y, [p1, p2])
    d = a[0] - a[1]
    se = np.sqrt(c[0, 0] + c[1, 1] - 2 * c[0, 1])
    z = stats.norm.ppf(1 - alpha / 2)
    pval = 2 * stats.norm.sf(abs(d) / se) if se > 0 else 1.0
    return float(d), float(d - z * se), float(d + z * se), float(pval)


def mcnemar(y, p1, p2, thr=0.5):
    """Exact (binomial) McNemar test on discordant correct/incorrect pairs."""
    c1 = (np.asarray(p1) >= thr).astype(int) == y
    c2 = (np.asarray(p2) >= thr).astype(int) == y
    b = int((c1 & ~c2).sum())
    c = int((~c1 & c2).sum())
    pval = stats.binomtest(min(b, c), b + c, 0.5).pvalue if b + c else 1.0
    return b, c, float(pval)


# --------------------------------------------------------------------------- calibration
def _logit(p, eps=1e-6):
    p = np.clip(np.asarray(p, dtype=float), eps, 1 - eps)
    return np.log(p / (1 - p))


def calibration_slope_intercept(y, p):
    """Calibration-in-the-large (intercept with logit(p) as offset) and calibration slope."""
    import statsmodels.api as sm
    lp = _logit(p)
    slope_fit = sm.GLM(y, sm.add_constant(lp), family=sm.families.Binomial()).fit()
    citl_fit = sm.GLM(y, np.ones((len(y), 1)), family=sm.families.Binomial(), offset=lp).fit()
    return float(citl_fit.params[0]), float(slope_fit.params[1])


def ece(y, p, bins=10):
    """Expected calibration error with equal-frequency bins."""
    y = np.asarray(y)
    p = np.asarray(p)
    edges = np.quantile(p, np.linspace(0, 1, bins + 1))
    idx = np.clip(np.searchsorted(edges, p, side="right") - 1, 0, bins - 1)
    e = 0.0
    for b in range(bins):
        msk = idx == b
        if msk.any():
            e += msk.mean() * abs(p[msk].mean() - y[msk].mean())
    return float(e)


def reliability_curve(y, p, bins=10):
    y = np.asarray(y)
    p = np.asarray(p)
    edges = np.quantile(p, np.linspace(0, 1, bins + 1))
    idx = np.clip(np.searchsorted(edges, p, side="right") - 1, 0, bins - 1)
    mp, ob, nn = [], [], []
    for b in range(bins):
        msk = idx == b
        if msk.any():
            mp.append(p[msk].mean())
            ob.append(y[msk].mean())
            nn.append(int(msk.sum()))
    return np.array(mp), np.array(ob), np.array(nn)


def scaled_brier(y, p):
    prev = np.mean(y)
    return 1 - brier_score_loss(y, p) / (prev * (1 - prev))


# --------------------------------------------------------------------------- decision curves
def net_benefit(y, p, t):
    y = np.asarray(y)
    n = len(y)
    tp, fp, _, _ = confusion(y, p, t)
    return tp / n - fp / n * t / (1 - t)


def net_benefit_all(y, t):
    prev = np.mean(y)
    return prev - (1 - prev) * t / (1 - t)


# --------------------------------------------------------------------------- selection stability
def nogueira(Z: np.ndarray) -> float:
    """Nogueira, Sechidis & Brown (2018) stability of M selected subsets (rows) over d features."""
    Z = np.asarray(Z, dtype=float)
    M, d = Z.shape
    pf = Z.mean(0)
    s2 = M / (M - 1) * pf * (1 - pf)
    kbar = Z.sum(1).mean()
    denom = (kbar / d) * (1 - kbar / d)
    if denom == 0:
        return 1.0
    return float(1 - s2.mean() / denom)


def jaccard(a, b) -> float:
    a, b = set(a), set(b)
    return len(a & b) / len(a | b) if (a | b) else 1.0


def mean_pairwise_jaccard(sets) -> float:
    sets = [set(s) for s in sets]
    vals = [jaccard(sets[i], sets[j]) for i in range(len(sets)) for j in range(i + 1, len(sets))]
    return float(np.mean(vals))


# --------------------------------------------------------------------------- effect sizes
def hedges_g(x1, x0):
    n1, n0 = len(x1), len(x0)
    s = np.sqrt(((n1 - 1) * np.var(x1, ddof=1) + (n0 - 1) * np.var(x0, ddof=1)) / (n1 + n0 - 2))
    d = (np.mean(x1) - np.mean(x0)) / s
    J = 1 - 3 / (4 * (n1 + n0) - 9)
    return float(d * J)
