"""Classifier factory. Every classifier is a Pipeline so that standardisation
(and, where used, feature selection) is re-fitted inside each training fold."""
from __future__ import annotations

from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import AdaBoostClassifier, GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from .selectors import TopK

MODEL_ORDER = ["LR", "RF", "GBT", "ADA", "SVM"]


def make_classifier(name: str, cfg: dict, seed: int, override: dict | None = None):
    p = dict(cfg["models"][name])
    p.pop("label", None)
    p.update(override or {})
    if name == "LR":
        return LogisticRegression(C=p["C"], max_iter=p["max_iter"], solver="lbfgs",
                                  class_weight=p.get("class_weight"))
    if name == "RF":
        return RandomForestClassifier(n_estimators=p["n_estimators"], max_features=p["max_features"],
                                      min_samples_leaf=p["min_samples_leaf"], random_state=seed,
                                      class_weight=p.get("class_weight"), n_jobs=1)
    if name == "GBT":
        return GradientBoostingClassifier(n_estimators=p["n_estimators"], learning_rate=p["learning_rate"],
                                          max_depth=p["max_depth"], subsample=p["subsample"],
                                          random_state=seed)
    if name == "ADA":
        return AdaBoostClassifier(estimator=DecisionTreeClassifier(max_depth=p["max_depth"], random_state=seed),
                                  n_estimators=p["n_estimators"], learning_rate=p["learning_rate"],
                                  random_state=seed)
    if name == "SVM":
        # Platt scaling fitted by internal 5-fold CV (replaces the deprecated probability=True)
        return CalibratedClassifierCV(SVC(C=p["C"], gamma=p["gamma"], kernel="rbf", random_state=seed),
                                      method="sigmoid", cv=5, ensemble=False)
    raise ValueError(name)


def make_pipeline(name: str, cfg: dict, seed: int, override: dict | None = None,
                  selector: TopK | None = None, scale: bool = True) -> Pipeline:
    steps = []
    if selector is not None:
        steps.append(("select", selector))
    if scale:
        steps.append(("scale", StandardScaler()))
    steps.append(("clf", make_classifier(name, cfg, seed, override)))
    return Pipeline(steps)


def label(name: str, cfg: dict) -> str:
    return cfg["models"][name]["label"]
