"""Shared figure style: one colour per entity, used identically in every figure."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402

MODEL_COLORS = {"LR": "#2a78d6", "RF": "#eb6834", "GBT": "#1baf7a", "ADA": "#eda100", "SVM": "#e87ba4",
                "LR5": "#008300", "LRc": "#4a3aa7", "TreatAll": "#52514e", "TreatNone": "#a3a29c"}
MODEL_MARKERS = {"LR": "o", "RF": "s", "GBT": "^", "ADA": "D", "SVM": "v", "LR5": "X", "LRc": "P"}
MODEL_LINES = {"LR": "-", "RF": "--", "GBT": "-.", "ADA": ":", "SVM": (0, (5, 1, 1, 1)), "LR5": (0, (3, 1)), "LRc": "-"}
SELECTOR_COLORS = {"Correlation": "#4a3aa7", "InformationGain": "#e34948", "ChiSquare": "#008300"}
SELECTOR_MARKERS = {"Correlation": "o", "InformationGain": "s", "ChiSquare": "^"}
SELECTOR_LABELS = {"Correlation": "Correlation", "InformationGain": "Information gain", "ChiSquare": "Chi-square"}
FAMILY_COLORS = {"mean": "#2a78d6", "error": "#eda100", "worst": "#e34948"}
CLASS_COLORS = {"Benign": "#2a78d6", "Malignant": "#e34948"}
INK = "#0b0b0b"
INK2 = "#52514e"
GRID = "#e4e3df"

SEQ = LinearSegmentedColormap.from_list("seq_blue", ["#f4f8fd", "#cde2fb", "#86b6ef", "#3987e5", "#1c5cab", "#0d366b"])
DIV = LinearSegmentedColormap.from_list("div_br", ["#184f95", "#3987e5", "#9ec5f4", "#f0efec", "#f3a9a8", "#e34948", "#a32a29"])


def apply():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.labelsize": 8.5,
        "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5, "legend.frameon": False,
        "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
        "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
        "grid.linewidth": 0.6, "axes.axisbelow": True, "lines.linewidth": 1.8, "savefig.dpi": 300,
        "figure.dpi": 110, "axes.titleweight": "bold", "axes.titlelocation": "left",
    })


def panel(ax, letter):
    ax.set_title(f"({letter})", loc="left", fontweight="bold")


def save(fig, path):
    fig.savefig(path, bbox_inches="tight", facecolor="white")
    plt.close(fig)
