"""Repeated stratified cross-validation utilities shared by every analysis."""
from __future__ import annotations

import os

import numpy as np
from joblib import Parallel, delayed
from sklearn.model_selection import RepeatedStratifiedKFold


def n_jobs() -> int:
    return int(os.environ.get("WDBC_JOBS", os.cpu_count() or 1))


def splits(y, folds: int, repeats: int, seed: int):
    """List of (repeat, fold, train_idx, test_idx). Identical for every analysis that
    passes the same (folds, repeats, seed), so paired comparisons share test folds."""
    rskf = RepeatedStratifiedKFold(n_splits=folds, n_repeats=repeats, random_state=seed)
    out = []
    for i, (tr, te) in enumerate(rskf.split(np.zeros(len(y)), y)):
        out.append((i // folds, i % folds, tr, te))
    return out


def fold_seed(master: int, repeat: int, fold: int) -> int:
    """Model seed depends only on (repeat, fold) so the same fold trains the same forest
    whether it is reached from the main analysis or the subset analysis at k = 30."""
    return int(master + 100 * repeat + fold)


def run(fn, items, jobs: int | None = None):
    jobs = jobs or n_jobs()
    if jobs == 1:
        return [fn(*it) for it in items]
    return Parallel(n_jobs=jobs, backend="loky")(delayed(fn)(*it) for it in items)
