# Data

## Source

**Breast Cancer Wisconsin (Diagnostic)** — Wolberg, W., Mangasarian, O., Street, N., & Street, W. (1993).
UCI Machine Learning Repository. <https://doi.org/10.24432/C5DW2B>

* Dataset page: <https://archive.ics.uci.edu/dataset/17/breast+cancer+wisconsin+diagnostic>
* Licence: Creative Commons Attribution 4.0 International (CC BY 4.0),
  <https://creativecommons.org/licenses/by/4.0/>
* The same 569 records are distributed with scikit-learn as
  `sklearn.datasets.load_breast_cancer()`.

The data were obtained from digitised images of fine-needle aspirates (FNA) of breast masses
at the University of Wisconsin Hospitals, Madison. Ten properties of the cell nuclei visible in
each image were computed from the traced nuclear boundaries (Street, Wolberg & Mangasarian,
1993, <https://doi.org/10.1117/12.148698>), and each property is summarised three ways per
image (mean, standard error, mean of the three largest values), giving 30 features. The
diagnosis (malignant or benign) is the histologically or clinically confirmed outcome.

## Files

| File | Rows × columns | Content |
|---|---|---|
| `raw/wdbc_cleaned.csv` | 569 × 31 | Analysis file read by the Python pipeline: 30 features (snake_case names) and `diagnosis` (`Malignant` / `Benign`) |
| `raw/breast_cancer_wdbc_cleaned.xlsx` | 569 × 31 | The same values in Excel format, read by the RapidMiner processes |
| `codebook.csv` | 31 rows | One row per column: position, name, label, family, property, summary statistic, definition, type, observed range, missing count |

The SPSS version of the data is `spss/wdbc_cleaned.sav` (same values and labels, plus a
`case_id` column and `malignant` coded 1 = Malignant, 0 = Benign).

`wdbc_cleaned.csv` has SHA-256 `1d1596fade984ff1e3a17c7da9656eb456573c4e5d8def91544fd7bec2d8901f`
(LF line endings; the pipeline normalises CRLF before hashing, so the checksum is the same on
Windows). Stage 01 writes the checksum to `results/estimates.json` and Table B1 prints its first
16 characters.

## Preparation

Relative to the UCI file `wdbc.data`, the only changes are:

1. the case ID column is not included;
2. the columns are named in snake_case (`mean_<property>`, `<property>_error`,
   `worst_<property>`);
3. the diagnosis is recoded `M` → `Malignant`, `B` → `Benign`.

No records were removed, there are no missing values and no duplicate records, and no values
were changed. The 17,070 feature values and 569 labels are identical to those of
`sklearn.datasets.load_breast_cancer()`; stage 01 (`scripts/01_data_audit.py`) and the unit
test `tests/test_core.py::test_matches_uci_copy` check this on every run.

The CSV can be rebuilt from the scikit-learn copy:

```python
import pandas as pd
from sklearn.datasets import load_breast_cancer

bc = load_breast_cancer()
df = pd.DataFrame(bc.data, columns=[n.replace(" ", "_") for n in bc.feature_names])
df["diagnosis"] = ["Malignant" if t == 0 else "Benign" for t in bc.target]
df.to_csv("data/raw/wdbc_cleaned.csv", index=False)
```

## Variables

| Column group | Columns |
|---|---|
| Mean of each property over the nuclei in the image | `mean_radius`, `mean_texture`, `mean_perimeter`, `mean_area`, `mean_smoothness`, `mean_compactness`, `mean_concavity`, `mean_concave_points`, `mean_symmetry`, `mean_fractal_dimension` |
| Standard error of each property within the image | `radius_error`, `texture_error`, `perimeter_error`, `area_error`, `smoothness_error`, `compactness_error`, `concavity_error`, `concave_points_error`, `symmetry_error`, `fractal_dimension_error` |
| Mean of the three largest values ("worst") | `worst_radius`, `worst_texture`, `worst_perimeter`, `worst_area`, `worst_smoothness`, `worst_compactness`, `worst_concavity`, `worst_concave_points`, `worst_symmetry`, `worst_fractal_dimension` |
| Outcome | `diagnosis`: `Malignant` (212, 37.3%) or `Benign` (357, 62.7%); malignant is the positive class throughout the analysis |

Property definitions (UCI documentation): radius, mean distance from the centre to points on
the perimeter; texture, standard deviation of grey-scale values; perimeter; area; smoothness,
local variation in radius lengths; compactness, perimeter² / area − 1.0; concavity, severity of
concave portions of the contour; concave points, number of concave portions of the contour;
symmetry; fractal dimension, "coastline approximation" − 1. The observed range of every column
is listed in `codebook.csv`.

## Citation

If you use the data, cite the dataset (above) and, for the feature extraction,
Street, W. N., Wolberg, W. H., & Mangasarian, O. L. (1993). Nuclear feature extraction for
breast tumor diagnosis. *Proc. SPIE 1905*, 861–870. <https://doi.org/10.1117/12.148698>
