"""Cell-by-cell comparison of the regenerated displays with the article's Word files.

After the pipeline has run (python run_all.py), compare every table caption, column header
and cell, and every figure caption, in results/ with the manuscript and Supplementary
Information documents:

    python tools/compare_with_manuscript.py --manuscript Manuscript.docx --supplementary Supplementary.docx

Optional: --results <dir> (default: results/ of this repository), --report <file.json>.

Text is compared after normalising whitespace and minus signs only; every other character
must agree. Cells that describe the computer the pipeline ran on (software versions,
hardware and run time in Table B1, and the wall-clock timings of Table F4) are listed
separately as machine-dependent and do not count as mismatches.
The exit status is 0 when every other caption, header and cell agrees, 1 otherwise.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "src"))
from display_plan import FIGURES, MAIN, APPENDICES, table_file  # noqa: E402

TABLE_CAP = re.compile(r"^Table ([A-F]?\d+)(?::\s*(.*))?$")
FIG_CAP = re.compile(r"^Figure ([A-F]?\d+)\.\s+(.*)$")
# (table, row label) pairs whose content depends on the machine used for the run
MACHINE_ROWS = {("B1", "Language and libraries"), ("B1", "Hardware")}
MACHINE_TABLES = {"F4"}


def norm(s: str) -> str:
    s = str(s).replace("\u2212", "-").replace("\xa0", " ")
    return re.sub(r"\s+", " ", s).strip()


def read_docx(path: Path):
    """Return ({table number: {"title", "rows"}}, {figure number: caption}) from a Word file."""
    doc = Document(str(path))
    tables, figures = {}, {}
    pending = None          # table number whose caption has been seen
    pending_title = None
    since = 0               # non-empty paragraphs since that caption
    for el in doc.element.body.iterchildren():
        tag = el.tag.split("}")[1]
        if tag == "p":
            text = norm(Paragraph(el, doc).text)
            if not text:
                continue
            m = TABLE_CAP.match(text)
            f = FIG_CAP.match(text)
            if m:
                pending, pending_title, since = m.group(1), (m.group(2) or None), 0
            elif f:
                figures[f.group(1)] = f.group(2)
                since += 1
            else:
                if pending and pending_title is None and since == 0:
                    pending_title = text      # caption split over two paragraphs ("Table F4" / title)
                since += 1
        elif tag == "tbl":
            t = Table(el, doc)
            if pending and since <= 1:
                rows = [[norm(c.text) for c in r.cells] for r in t.rows]
                tables[pending] = {"title": norm(pending_title or ""), "rows": rows}
            pending, pending_title = None, None
    return tables, figures


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--manuscript", required=True, type=Path)
    ap.add_argument("--supplementary", required=True, type=Path)
    ap.add_argument("--results", type=Path, default=ROOT / "results")
    ap.add_argument("--report", type=Path, default=None)
    a = ap.parse_args()

    t_ms, f_ms = read_docx(a.manuscript)
    t_su, f_su = read_docx(a.supplementary)
    art_tables = {**t_ms, **t_su}
    art_figs = {**f_ms, **f_su}
    plan = MAIN + [d for _, _, ds in APPENDICES for d in ds]
    tab_dir, fig_dir = a.results / "display_tables", a.results / "figures"

    out = {"mismatches": [], "machine_dependent": [], "missing": []}
    n_cells = n_ok = 0

    for kind, num in plan:
        if kind == "T":
            jp = tab_dir / table_file(num)
            if num not in art_tables:
                out["missing"].append(f"Table {num}: not found in the article files")
                continue
            if not jp.exists():
                out["missing"].append(f"Table {num}: {jp.name} not found (run the pipeline first)")
                continue
            spec = json.loads(jp.read_text(encoding="utf-8"))
            art = art_tables[num]
            gen_rows = [spec["columns"]] + spec["rows"]
            n_cells += 1
            if norm(spec["title"]) == art["title"]:
                n_ok += 1
            else:
                out["mismatches"].append({"display": f"Table {num}", "where": "title",
                                          "code": norm(spec["title"]), "article": art["title"]})
            if len(gen_rows) != len(art["rows"]):
                out["mismatches"].append({"display": f"Table {num}", "where": "shape",
                                          "code": f"{len(gen_rows)} rows", "article": f"{len(art['rows'])} rows"})
            for i, (gr, ar) in enumerate(zip(gen_rows, art["rows"])):
                if len(gr) != len(ar):
                    out["mismatches"].append({"display": f"Table {num}", "where": f"row {i}",
                                              "code": f"{len(gr)} columns", "article": f"{len(ar)} columns"})
                    continue
                for j, (gc, ac) in enumerate(zip(gr, ar)):
                    gc = norm(gc)
                    n_cells += 1
                    where = "header" if i == 0 else f"row {i} ({norm(gr[0])}), column {j + 1} ({norm(gen_rows[0][j])})"
                    if gc == ac:
                        n_ok += 1
                    elif num in MACHINE_TABLES or (num, norm(gr[0])) in MACHINE_ROWS:
                        out["machine_dependent"].append({"display": f"Table {num}", "where": where,
                                                         "code": gc, "article": ac})
                    else:
                        out["mismatches"].append({"display": f"Table {num}", "where": where, "code": gc, "article": ac})
        else:
            fig = FIGURES[num]
            n_cells += 1
            if num not in art_figs:
                out["missing"].append(f"Figure {num}: caption not found in the article files")
            elif norm(fig["title"]) != art_figs[num]:
                out["mismatches"].append({"display": f"Figure {num}", "where": "caption",
                                          "code": norm(fig["title"]), "article": art_figs[num]})
            else:
                n_ok += 1
            if not (fig_dir / fig["file"]).exists():
                out["missing"].append(f"Figure {num}: {fig['file']} not found (run the pipeline first)")

    extra = sorted(set(art_tables) - {n for k, n in plan if k == "T"}) + \
        sorted(f"Figure {n}" for n in set(art_figs) - {n for k, n in plan if k == "F"})
    out.update(n_compared=n_cells, n_identical=n_ok, unmatched_article_displays=extra)

    print(f"Compared {n_cells} captions, headers and cells across {len(plan)} displays.")
    print(f"  identical:          {n_ok}")
    print(f"  mismatches:         {len(out['mismatches'])}")
    print(f"  machine-dependent:  {len(out['machine_dependent'])} (software, hardware, run time, timings)")
    print(f"  missing:            {len(out['missing'])}")
    for m in out["missing"]:
        print("  MISSING ", m)
    for m in out["mismatches"]:
        print(f"  DIFF     {m['display']} {m['where']}\n           code:    {m['code']}\n           article: {m['article']}")
    for m in out["machine_dependent"]:
        print(f"  MACHINE  {m['display']} {m['where']}: code {m['code']!r} | article {m['article']!r}")
    if a.report:
        a.report.write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
    sys.exit(0 if not out["mismatches"] and not out["missing"] else 1)


if __name__ == "__main__":
    main()
