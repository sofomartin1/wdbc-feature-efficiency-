"""Stage 11 — model-agnostic and model-specific importance.

* Permutation importance (drop in AUC, 10 permutations) computed on the held-out fold
  of every test fold of the first CV repeat, averaged over folds.
* SHAP values for the 30-feature logistic regression (exact linear explainer on the
  standardised scale) and gradient-boosted trees (TreeExplainer), fitted on all cases.
"""
import numpy as np
import pandas as pd
import shap
from scipy import stats
from sklearn.inspection import permutation_importance

from _common import CFG, SEED, Timer
from wdbcfs import cv, data, store
from wdbcfs.models import make_pipeline

X, y, feats = data.load(CFG)
Xn = X.to_numpy()
K, R = CFG["cv"]["folds"], CFG["cv"]["repeats"]
SPLITS = [s for s in cv.splits(y, K, R, SEED) if s[0] == 0]
MODELS = CFG["selection"]["subset_models"]


def one(r, f, tr, te):
    out = {}
    for m in MODELS:
        pipe = make_pipeline(m, CFG, cv.fold_seed(SEED, r, f)).fit(Xn[tr], y[tr])
        pi = permutation_importance(pipe, Xn[te], y[te], scoring="roc_auc", n_repeats=10,
                                    random_state=cv.fold_seed(SEED, r, f), n_jobs=1)
        out[m] = pi.importances_mean
    return out


if __name__ == "__main__":
    with Timer("11 interpretability"):
        res = cv.run(one, SPLITS)
        rows = []
        for m in MODELS:
            imp = np.vstack([r[m] for r in res])
            for j, f in enumerate(feats):
                rows.append({"model": m, "feature": f, "importance": imp[:, j].mean(), "sd": imp[:, j].std(ddof=1)})
        pim = pd.DataFrame(rows)
        store.save_table("permutation_importance", pim)

        # SHAP on full-sample fits
        shap_out, rank_rows = {}, []
        lr = make_pipeline("LR", CFG, SEED).fit(Xn, y)
        Zs = lr.named_steps["scale"].transform(Xn)
        ex = shap.LinearExplainer(lr.named_steps["clf"], shap.maskers.Independent(Zs, max_samples=len(Zs)))
        shap_out["LR"] = ex.shap_values(Zs)
        gbt = make_pipeline("GBT", CFG, SEED).fit(Xn, y)
        Zg = gbt.named_steps["scale"].transform(Xn)
        shap_out["GBT"] = shap.TreeExplainer(gbt.named_steps["clf"]).shap_values(Zg)
        store.save_arrays("shap", LR=shap_out["LR"], GBT=shap_out["GBT"], Z=Zs, feats=np.array(feats))
        for m, sv in shap_out.items():
            ma = np.abs(sv).mean(0)
            for j, f in enumerate(feats):
                rank_rows.append({"model": m, "feature": f, "mean_abs_shap": ma[j]})
        shp = pd.DataFrame(rank_rows)
        store.save_table("shap_importance", shp)

        piv = pim.pivot(index="feature", columns="model", values="importance")
        rho = {f"{a}-{b}": float(stats.spearmanr(piv[a], piv[b])[0]) for a, b in
               [("LR", "RF"), ("LR", "GBT"), ("RF", "GBT")]}
        top5 = {m: piv[m].sort_values(ascending=False).head(5).index.tolist() for m in MODELS}
        sp = shp.pivot(index="feature", columns="model", values="mean_abs_shap")
        store.put("interpretability", {
            "perm_spearman": rho, "perm_top5": top5,
            "shap_top5": {m: sp[m].sort_values(ascending=False).head(5).index.tolist() for m in sp.columns},
            "shap_spearman_LR_GBT": float(stats.spearmanr(sp["LR"], sp["GBT"])[0]),
        })
        print(store.get("interpretability"))
