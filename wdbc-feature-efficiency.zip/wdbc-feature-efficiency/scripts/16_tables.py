"""Stage 16 — format every display table from the results store.

Each table is written to results/display_tables/table_<number>.json (number as in the
article: 1-10 in the main text, A1-F4 in the Supplementary Information) with its
caption, column headers, formatted cells and note. Tables B1 and B2 (reproducibility
record) are written by stage 18 after the consistency gate. The Word builder only lays these out; it never
computes or rounds a number itself.
"""
import json
import re

import numpy as np
import pandas as pd

from _common import CFG, ROOT, Timer
from display_plan import table_file
from wdbcfs import data, store
from wdbcfs.models import MODEL_ORDER

OUT = ROOT / "results" / "display_tables"
OUT.mkdir(parents=True, exist_ok=True)
X, y, feats = data.load(CFG)
D = len(feats)
SELS = CFG["selection"]["selectors"]
SUBM = CFG["selection"]["subset_models"]
SL = {"Correlation": "Correlation", "InformationGain": "Information gain", "ChiSquare": "Chi-square"}
ML = {m: CFG["models"][m]["label"] for m in MODEL_ORDER}
comp = store.get("subsets")["compact"]
five = store.get("subsets")["five"]
ML["LR5"] = f"Compact LR ({five['k']})"
ML["LRc"] = f"Compact LR ({comp['k']})"
ML["TreatAll"] = "Biopsy all"
REG = []


def f(v, d=3):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "–"
    out = f"{v:.{d}f}"
    return out[1:] if out.startswith("-") and float(out) == 0 else out   # no negative zero


def lz(v, d=3):
    """APA style: no leading zero for values that cannot exceed 1 (p, r, proportions in some places)."""
    s = f(v, d)
    return s.replace("0.", ".", 1) if s.startswith("0.") else s.replace("-0.", "-.", 1)


def pv(p):
    if p is None or (isinstance(p, float) and np.isnan(p)):
        return "–"
    if p < 0.001:
        return "< .001"
    return lz(p, 3)


def ci(lo, hi, d=3):
    return f"[{f(lo, d)}, {f(hi, d)}]"


def pct(v, d=1):
    return f"{100 * v:.{d}f}"


def emit(tid, title, columns, rows, note, landscape=False, part="main", widths=None, group=None):
    for r in rows:
        assert len(r) == len(columns), (tid, r)
        for c in r:
            assert c is not None and not re.search(r"\bnan\b", str(c), re.I), (tid, r)
    spec = {"id": tid, "title": title, "columns": columns, "rows": rows, "note": note,
            "landscape": landscape, "part": part, "widths": widths, "group": group}
    (OUT / table_file(tid)).write_text(json.dumps(spec, indent=1, ensure_ascii=False), encoding="utf-8")
    REG.append(tid)


def mlabel(m):
    return {"ADA": "AdaBoost"}.get(m, ML[m])


with Timer("16 tables"):
    est = store.load_estimates()
    dd = est["data"]

    # ------------------------------------------------------------------------- Table 1
    rows = [
        ["Source", "UCI Machine Learning Repository, Wisconsin Diagnostic Breast Cancer (WDBC)"],
        ["Cases (aspirates)", f"{dd['n']}"],
        ["Malignant / benign", f"{dd['n_malignant']} ({pct(dd['prevalence'])}%) / {dd['n_benign']} ({pct(1 - dd['prevalence'])}%)"],
        ["Features", f"{dd['n_features']} real-valued nuclear morphometry features: 10 properties x 3 statistics"],
        ["Feature families", f"Mean ({dd['n_family_mean']}), standard error ({dd['n_family_error']}), worst ({dd['n_family_worst']})"],
        ["Missing values / duplicate records", f"{dd['missing']} / {dd['duplicates']}"],
        ["Identity with UCI release (scikit-learn copy)", "Identical (all 17,070 values and 569 labels)" if dd["sklearn_match"] else "Not identical"],
        ["Features separating classes (Mann–Whitney, BH q < .05)", f"{dd['n_q05']} of {dd['n_features']}"],
        ["Features with |Hedges g| ≥ 0.8", f"{dd['n_g_large']} of {dd['n_features']}"],
        ["Strongest single feature (AUC)", f"{data.pretty(dd['best_univariate'])} ({f(dd['best_univariate_auc'])})"],
        ["Feature pairs with |r| > .90 / > .80", f"{dd['n_pairs_r90']} / {dd['n_pairs_r80']} of {dd['n_pairs']}"],
        ["Largest correlation", f"{data.pretty(dd['max_r_pair'][0])} – {data.pretty(dd['max_r_pair'][1])} (r = {lz(dd['max_r'])})"],
        ["Variance inflation factor, median (max)", f"{f(dd['vif_median'], 1)} ({f(dd['vif_max'], 1)}, {data.pretty(dd['vif_max_feature'])})"],
        ["Features with VIF > 10", f"{dd['n_vif_gt10']} of {dd['n_features']}"],
        ["Validation design", f"{est['main']['repeats']} × {est['main']['folds']}-fold repeated stratified cross-validation "
                              f"({est['main']['n_test_folds']} test folds; mean {f(est['main']['mean_n_train'], 1)} training / "
                              f"{f(est['main']['mean_n_test'], 1)} test cases)"],
    ]
    emit("1", "Composition, Class Separation and Redundancy of the WDBC Dataset", ["Characteristic", "Value"], rows,
         "BH = Benjamini–Hochberg false-discovery-rate adjustment; AUC = area under the ROC curve; VIF = variance inflation "
         "factor computed on the 30 standardised features. The malignant class is the positive class throughout.",
         widths=[2.6, 4.0])

    # ------------------------------------------------------------------------- Table 2
    mc = CFG["models"]
    tg = CFG["tuning_grids"]
    rows = [
        ["Logistic regression (LR)", f"L2 penalty, C = {mc['LR']['C']}, L-BFGS solver", f"C ∈ {{{', '.join(str(v) for v in tg['LR']['C'])}}}"],
        ["Random forest (RF)", f"{mc['RF']['n_estimators']} trees, max features = √p, min. leaf = {mc['RF']['min_samples_leaf']}",
         "max features ∈ {√p, 0.5p}; min. leaf ∈ {1, 3}"],
        ["Gradient-boosted trees (GBT)", f"{mc['GBT']['n_estimators']} trees, learning rate {mc['GBT']['learning_rate']}, depth {mc['GBT']['max_depth']}, subsample {mc['GBT']['subsample']}",
         "learning rate ∈ {0.05, 0.1}; depth ∈ {2, 3}"],
        ["AdaBoost", f"{mc['ADA']['n_estimators']} depth-{mc['ADA']['max_depth']} trees, learning rate {mc['ADA']['learning_rate']}", "Not tuned"],
        ["SVM (RBF kernel)", f"C = {mc['SVM']['C']}, γ = 1/(p·Var(X)); Platt-scaled probabilities (5-fold)", "Not tuned"],
        ["Feature selection", "Correlation |r|; information gain (k-NN mutual information, k = 3); chi-square on min–max scaled features",
         f"k ∈ {{{', '.join(str(k) for k in CFG['selection']['k_grid'])}}}"],
        ["Model-specific selection", "Recursive feature elimination (step 1) by |coefficient| (LR) or impurity importance (RF, GBT)",
         f"k = {CFG['selection']['rfe_sizes'][0]}; {CFG['selection']['rfe_repeats']} × 10 folds"],
    ]
    emit("2", "Classifier and Feature-Selection Specifications", ["Component", "Primary specification", "Nested-tuning grid / range"],
         rows, f"All components were fitted inside each training fold, after z-standardisation with training-fold means and "
               f"standard deviations; p = number of input features. Hyperparameters were fixed in advance for the primary analysis; "
               f"the grids were searched only in the nested-tuning sensitivity analysis (inner {CFG['cv']['inner_folds']}-fold, "
               f"{CFG['cv']['nested_repeats']} × 10 outer folds). Master random seed = {CFG['study']['master_seed']}.",
         widths=[1.6, 3.2, 2.2])

    # ------------------------------------------------------------------------- Table 3
    summ = store.load_table("main_summary")
    mets = ["AUC", "Accuracy", "Sensitivity", "Specificity", "PPV", "NPV", "F1", "MCC", "Kappa", "Brier"]
    rows = []
    for m in MODEL_ORDER:
        g = summ[summ.model == m].set_index("metric")
        rows.append([mlabel(m)] + [f"{f(g.loc[x, 'mean'])} ± {f(g.loc[x, 'sd'])}\n{ci(g.loc[x, 'lo'], g.loc[x, 'hi'])}" for x in mets])
    emit("3", "Full-Feature Diagnostic Performance of Five Classifiers (10 × 10 Repeated Stratified Cross-Validation)",
         ["Classifier"] + ["AUC", "Accuracy", "Sensitivity", "Specificity", "PPV", "NPV", "F1", "MCC", "κ", "Brier"], rows,
         "Cells show mean ± SD over 100 test folds and, beneath, the Nadeau–Bengio corrected 95% confidence interval "
         "(bounded metrics truncated at 1). Sensitivity, PPV and F1 treat malignancy as the positive class; classification at "
         "probability 0.5. PPV = positive predictive value; NPV = negative predictive value; MCC = Matthews correlation "
         "coefficient; κ = Cohen's kappa; Brier = mean squared error of the predicted probability (lower is better).",
         landscape=True)

    # ------------------------------------------------------------------------- Table 4
    pw = store.load_table("pairwise")
    rows = []
    for r in pw.itertuples():
        sn = {"ADA": "AdaBoost"}
        rows.append([f"{sn.get(r.a, r.a)} vs {sn.get(r.b, r.b)}", f"{f(r.dAUC, 4)} {ci(r.dAUC_lo, r.dAUC_hi, 4)}", pv(r.dAUC_p_holm),
                     f"{f(r.dAcc, 4)} {ci(r.dAcc_lo, r.dAcc_hi, 4)}", pv(r.dAcc_p_holm),
                     f"{f(r.delong_d, 4)} {ci(r.delong_lo, r.delong_hi, 4)}", pv(r.delong_p_holm),
                     f"{r.mcnemar_a_only} / {r.mcnemar_b_only}", pv(r.mcnemar_p_holm)])
    emit("4", "Pairwise Comparisons of the Five Full-Feature Classifiers",
         ["Comparison (A vs B)", "ΔAUC [95% CI]", "p (Holm)", "ΔAccuracy [95% CI]", "p (Holm)", "DeLong ΔAUC [95% CI]",
          "p (Holm)", "McNemar A-only / B-only correct", "p (Holm)"], rows,
         "LR = logistic regression; RF = random forest; GBT = gradient-boosted trees; SVM = support vector machine (RBF kernel). "
         "Δ = A minus B. ΔAUC and ΔAccuracy are means of fold-paired differences over 100 test folds with Nadeau–Bengio "
         "corrected resampled t-tests (df = 99). DeLong and exact McNemar tests use the pooled out-of-fold probability of each "
         "case averaged over the 10 repeats. Holm adjustment within each family of 10 comparisons.", landscape=True)

    # ------------------------------------------------------------------------- Table 5
    rk = store.load_table("rankings_full")
    ag = store.load_table("ranking_agreement")
    rows = []
    for r in rk.head(12).itertuples():
        rows.append([r.label, {"mean": "Mean", "error": "SE", "worst": "Worst"}[r.family],
                     f"{lz(r.Correlation_score)} ({r.Correlation_rank})", f"{f(r.InformationGain_score)} ({r.InformationGain_rank})",
                     f"{f(r.ChiSquare_score, 2)} ({r.ChiSquare_rank})", f(r.mean_rank, 2)])
    rr = est["rankings"]
    agtxt = "; ".join(f"{SL[a.a]}–{SL[a.b]} ρ = {lz(a.spearman)}, top-5 Jaccard = {lz(a.jaccard_top5, 2)}"
                      for a in ag.itertuples())
    emit("5", "Feature Relevance Under the Three Filter Criteria (Full Sample, Top 12 by Mean Rank)",
         ["Feature", "Family", "Correlation |r| (rank)", "Information gain, nats (rank)", "Chi-square (rank)", "Mean rank"], rows,
         f"Ranks are 1 = most relevant among 30. Full-sample rankings are descriptive; every subset performance estimate used "
         f"rankings recomputed inside each training fold. Agreement across all 30 features: Kendall's W = {lz(rr['kendall_W'])}, "
         f"χ²({rr['kendall_W_df']}) = {f(rr['kendall_W_chi2'], 2)}, p {pv(rr['kendall_W_p']) if pv(rr['kendall_W_p']).startswith('<') else '= ' + pv(rr['kendall_W_p'])}; "
         f"{agtxt}. Features common to all three top-5 lists: {', '.join(data.pretty(x) for x in rr['common_top5'])}. "
         f"The complete ranking is given in Table D1.",
         widths=[1.7, 0.6, 1.3, 1.4, 1.2, 0.8])

    # ------------------------------------------------------------------------- Table 6 (RQ1)
    g = store.load_table("subset_summary")
    sc = store.load_table("selector_compare")
    auk = store.load_table("selector_auk")
    rows = []
    for m in SUBM:
        for k in (3, 5, 10):
            cells = []
            vals = {s: g[(g.model == m) & (g.selector == s) & (g.k == k)].iloc[0] for s in SELS}
            best = max(SELS, key=lambda s: vals[s]["AUC"])
            for s in SELS:
                v = vals[s]
                cells.append(f"{f(v['AUC'])} / {f(v['Accuracy'])}\n{f(v['Sensitivity'])} / {f(v['Specificity'])}")
            sub = sc[(sc.model == m) & (sc.k == k)]
            sig = int((sub["p_holm"] < 0.05).sum())
            rng = f"{f(sub['dAUC'].abs().max(), 4)}"
            rows.append([mlabel(m), str(k)] + cells + [best.replace("InformationGain", "Info. gain").replace("ChiSquare", "Chi-square"),
                                                      f"{rng} ({sig}/3)"])
    for m in SUBM:
        a = auk[auk.model == m].set_index("selector")["AUC_k1_10"]
        rows.append([mlabel(m), "1–10 (mean)"] + [f(a[s]) for s in SELS] + [SL[a.idxmax()].replace("Information gain", "Info. gain"), "–"])
    emit("6", "Comparison of the Three Filter Criteria at Fixed Subset Sizes (RQ1; Leakage-Free Selection)",
         ["Classifier", "k", "Correlation", "Information gain", "Chi-square", "Highest AUC", "Max |ΔAUC| (Holm-sig. pairs)"], rows,
         "Upper cells: AUC / accuracy; lower cells: sensitivity / specificity (means over 100 test folds; features ranked within "
         "each training fold). Max |ΔAUC| is the largest fold-paired AUC difference between any two criteria at that k, with the "
         "number of the three criterion pairs significant after Holm adjustment across all 27 comparisons. The final rows give "
         "the mean AUC over k = 1–10 (area under the low-k curve). Full grids: Table D4; pairwise tests: Table D2.",
         landscape=True)

    # ------------------------------------------------------------------------- Table 7 (RQ2)
    ks = store.load_table("kstar")
    ks["_m"] = [SUBM.index(m) for m in ks["model"]]
    ks["_s"] = [SELS.index(x) for x in ks["selector"]]
    ks = ks.sort_values(["_m", "_s"]).reset_index(drop=True)
    rows = []
    for r in ks.itertuples():
        rows.append([mlabel(r.model), SL[r.selector], f(r.AUC_full), str(r.k_point), f"{f(r.dAUC_point, 5)}",
                     str(r.k_ni), f"{f(r.AUC_ni)} {ci(r.AUC_ni_lo, r.AUC_ni_hi)}", f"{f(r.dAUC_ni, 4)} {ci(r.dAUC_ni_lo, r.dAUC_ni_hi, 4)}",
                     f"{f(r.Sensitivity_ni)} / {f(r.Specificity_ni)}"])
    emit("7", "Smallest Feature Subsets Retaining the 30-Feature AUC (RQ2; Non-Inferiority Margin 0.01)",
         ["Classifier", "Criterion", "AUC (k = 30)", "k (point rule)", "ΔAUC at k (point)", "k (CI rule)", "AUC at k (CI) [95% CI]",
          "ΔAUC at k (CI) [95% CI]", "Sens. / Spec. at k (CI)"], rows,
         f"ΔAUC = AUC(k) − AUC(30) on the same 100 test folds. Point rule (antecedent definition): smallest k whose mean ΔAUC ≥ "
         f"−{CFG['selection']['margin']}. CI rule (non-inferiority): smallest k whose corrected 95% lower confidence limit of ΔAUC ≥ "
         f"−{CFG['selection']['margin']}. Candidate k ∈ {{{', '.join(str(k) for k in CFG['selection']['k_grid'])}}}. Sens. = "
         f"sensitivity; Spec. = specificity (threshold 0.5).", landscape=True)

    # ------------------------------------------------------------------------- Table 8 (RQ3)
    rs = store.load_table("rfe_summary")
    st = store.load_table("stability")
    rows = []
    for r in rs.itertuples():
        mod = ", ".join(data.pretty(x) for x in r.modal_subset.split("|"))
        kn = {s: int(ks[(ks.model == r.model) & (ks.selector == s)]["k_ni"].iloc[0]) for s in SELS}
        rows.append([mlabel(r.model), mod, f"{pct(r.modal_freq)}% ({r.n_distinct})", lz(r.nogueira),
                     f"{f(r.AUC)} {ci(r.AUC_lo, r.AUC_hi)}",
                     f"{f(r.dAUC_vs_filter, 4)} {ci(r.dAUC_vs_filter_lo, r.dAUC_vs_filter_hi, 4)}; p = {pv(r.dAUC_vs_filter_p).lstrip('= ')}",
                     " / ".join(str(kn[s]) for s in SELS)])
    jj = est["subsets"]["rfe_modal_jaccard"]
    emit("8", "Model Dependence of the Optimal Feature Subset (RQ3)",
         ["Classifier", "Modal RFE subset (k = 5)", "Modal frequency (distinct subsets)", "Nogueira index", "AUC [95% CI]",
          "ΔAUC vs best filter at k = 5 [95% CI]", "Smallest non-inferior k (Corr. / IG / χ²)"], rows,
         f"RFE = recursive feature elimination inside each training fold ({CFG['selection']['rfe_repeats']} × 10 = "
         f"{CFG['selection']['rfe_repeats'] * 10} folds) using the classifier's own importance. Jaccard similarity of the modal "
         f"subsets: " + "; ".join(f"{a.replace('-', ' vs ')} = {lz(v, 2)}" for a, v in jj.items()) +
         ". The best filter is the criterion with the highest mean AUC at k = 5 for that classifier on the same folds; the "
         "last column repeats the CI-rule k from Table 7.", landscape=True)

    # ------------------------------------------------------------------------- Table 9 calibration + utility
    cal = store.load_table("calibration").set_index("model")
    rep = store.load_table("dca_report")
    order = MODEL_ORDER + ["LR5", "LRc"]
    rows = []
    for m in order:
        c = cal.loc[m]
        r10 = rep[(rep.model == m) & (rep.threshold == 0.10)].iloc[0]
        r30 = rep[(rep.model == m) & (rep.threshold == 0.30)].iloc[0]
        rows.append([mlabel(m), f"{f(c.Brier, 4)} {ci(c.Brier_lo, c.Brier_hi, 4)}", f"{f(c.ScaledBrier)} {ci(c.ScaledBrier_lo, c.ScaledBrier_hi)}",
                     f"{f(c.CITL, 2)} {ci(c.CITL_lo, c.CITL_hi, 2)}", f"{f(c.Slope, 2)} {ci(c.Slope_lo, c.Slope_hi, 2)}",
                     f"{f(c.ECE)} {ci(c.ECE_lo, c.ECE_hi)}", f"{f(r10.dnb)} {ci(r10.dnb_lo, r10.dnb_hi)}", f(r10.avoided_per100, 1),
                     f"{f(r30.dnb)} {ci(r30.dnb_lo, r30.dnb_hi)}", f(r30.avoided_per100, 1)])
    emit("9", "Calibration and Clinical Utility of Out-of-Fold Predictions",
         ["Classifier", "Brier [95% CI]", "Scaled Brier", "Calibration intercept", "Calibration slope", "ECE",
          "ΔNB at 10% [95% CI]", "Biopsies avoided /100 (10%)", "ΔNB at 30% [95% CI]", "Biopsies avoided /100 (30%)"], rows,
         f"Pooled analysis of each case's out-of-fold probability averaged over the 10 repeats; 95% percentile bootstrap intervals "
         f"({CFG['evaluation']['bootstrap']} resamples). Calibration intercept = calibration-in-the-large (ideal 0); slope ideal 1. "
         f"ECE = expected calibration error, 10 equal-frequency bins. ΔNB = net benefit minus that of biopsying all; biopsies "
         f"avoided per 100 = ΔNB / [t/(1 − t)] x 100 at threshold t. Compact LR ({five['k']}) and Compact LR ({comp['k']}) = "
         f"logistic regression on the {five['k']} ({SL[five['selector']].lower()}) or {comp['k']} ({SL[comp['selector']].lower()}) "
         f"features ranked inside each training fold, with their own leakage-free out-of-fold predictions. AdaBoost probabilities "
         f"are compressed towards 0.5 (slope far above 1), so at thresholds of 10% or lower it refers every case and its net "
         f"benefit equals that of biopsying all. Net benefit at further thresholds: Table E1.",
         landscape=True)

    # ------------------------------------------------------------------------- Tables 10 and E2 compact models
    ob = store.load_table("optimism_bootstrap")
    opt = []
    for mname in ob["model"].unique():
        d = ob[ob.model == mname].set_index("metric")
        nm = ML.get(mname, mname)
        opt.append(f"{nm}: AUC {f(d.loc['AUC', 'apparent'])} → {f(d.loc['AUC', 'corrected'])}, Brier "
                   f"{f(d.loc['Brier', 'apparent'], 4)} → {f(d.loc['Brier', 'corrected'], 4)}")
    for tid, tag, sp, part in (("10", "LR5", five, "main"), ("E2", "LRc", comp, "appendix")):
        coef = store.load_table(f"compact_coefficients_{tag}")
        rows = []
        for r in coef.itertuples():
            if r.term == "(Intercept)":
                rows.append(["Intercept", "–", "–", f"{f(r.beta_std)} {ci(r.lo, r.hi)}", "–", "–", f(r.beta_raw, 4)])
            else:
                rows.append([r.label, f"{r.mean:.4g}", f"{r.sd:.4g}", f"{f(r.beta_std)} {ci(r.lo, r.hi)}",
                             f"{f(r.OR_per_SD, 2)} {ci(r.OR_lo, r.OR_hi, 2)}", f(r.vif, 1), f"{r.beta_raw:.4g}"])
        why = ("the subset size reported by the antecedent study, with the criterion whose fold-internal top-5 subset was most "
               "stable" if tag == "LR5" else "the smallest subset meeting the non-inferiority (CI) rule of Table 7")
        emit(tid, f"{ML[tag]}: Logistic Model on {sp['k']} Features Fitted to All {len(y)} Cases",
             ["Term", "Mean", "SD", "β (standardised) [95% CI]", "OR per SD [95% CI]", "VIF", "β (raw scale)"], rows,
             f"Features: the top {sp['k']} by full-sample {SL[sp['selector']].lower()} ranking ({why}). L2-penalised logistic "
             f"regression (C = {CFG['models']['LR']['C']}) on z-standardised features; 95% percentile bootstrap intervals "
             f"({CFG['evaluation']['bootstrap']} resamples). Raw-scale coefficients give logit(p) = β₀ + Σ βⱼxⱼ in the original "
             f"units. OR = odds ratio of malignancy per SD increase; VIF = variance inflation factor within the model. Harrell "
             f"bootstrap optimism correction ({CFG['evaluation']['optimism_bootstrap']} resamples, feature selection repeated in "
             f"each), apparent → corrected: " + "; ".join(opt) + "." +
             (f" The {comp['k']}-feature model is reported in Table E2." if tag == "LR5" else ""),
             part=part, widths=[1.8, 0.8, 0.7, 1.5, 1.4, 0.5, 0.9])

    # ------------------------------------------------------------------------- Table F1 optimism
    op = store.load_table("optimism")
    rows = []
    for m in SUBM:
        for k in sorted(op["k"].unique()):
            cells = [mlabel(m), str(k)]
            for s in SELS:
                r = op[(op.model == m) & (op.selector == s) & (op.k == k)].iloc[0]
                cells.append(f"{f(r.AUC_leaky)} vs {f(r.AUC_free)}\n{f(r.optimism, 4)} {ci(r.opt_lo, r.opt_hi, 4)}")
            rows.append(cells)
    emit("F1", "Optimism Introduced by Ranking Features on the Full Sample Before Cross-Validation",
         ["Classifier", "k", "Correlation", "Information gain", "Chi-square"], rows,
         "Upper line: mean test-fold AUC when features are ranked once on all 569 cases (antecedent protocol) vs ranked inside "
         "each training fold (leakage-free). Lower line: fold-paired optimism (leaky − leakage-free) with corrected 95% CI. "
         "Same 100 test folds and model seeds in both protocols.", landscape=True)

    # ========================================================================= Appendix
    desc = store.load_table("feature_descriptives")
    rows = []
    for r in desc.itertuples():
        rows.append([r.label, f"{r.mean_benign:.4g} ({r.sd_benign:.3g})", f"{r.mean_malignant:.4g} ({r.sd_malignant:.3g})",
                     f(r.hedges_g, 2), f"{f(r.auc)} {ci(r.auc_lo, r.auc_hi)}", pv(r.mw_q), f(r.skewness, 2), f(r.vif, 1)])
    emit("A1", "Descriptive Statistics of the 30 Features by Diagnosis",
         ["Feature", "Benign mean (SD)", "Malignant mean (SD)", "Hedges g", "AUC [95% CI]", "q (BH)", "Skewness", "VIF"], rows,
         "AUC is the probability that a malignant case has a higher value than a benign case (values below .5 indicate lower "
         "values in malignancy); DeLong 95% CI. q = Benjamini–Hochberg adjusted Mann–Whitney p. VIF from all 30 standardised "
         "features. SE = standard error of the property within the image.", part="appendix", landscape=True)

    rows = []
    for r in rk.itertuples():
        rows.append([r.label, f"{lz(r.Correlation_score)}", str(r.Correlation_rank), f(r.InformationGain_score), str(r.InformationGain_rank),
                     f(r.ChiSquare_score, 2), str(r.ChiSquare_rank), f(r.mean_rank, 2)])
    emit("D1", "Complete Full-Sample Ranking of the 30 Features",
         ["Feature", "|r|", "Rank", "Information gain", "Rank", "Chi-square", "Rank", "Mean rank"], rows,
         "Information gain = k-nearest-neighbour mutual information in nats (k = 3, seed 2026); chi-square on min–max scaled "
         "features. Ordered by mean rank; ties keep feature order.", part="appendix",
         widths=[2.0, 0.6, 0.5, 1.0, 0.5, 0.8, 0.5, 0.8])

    rows = []
    for m in SUBM:
        for k in CFG["selection"]["k_grid"]:
            cells = [mlabel(m), str(k)]
            for s in SELS:
                v = g[(g.model == m) & (g.selector == s) & (g.k == k)].iloc[0]
                cells.append(f"{f(v['AUC'])} ± {f(v['AUC_sd'])}")
                cells.append(f"{f(v['Accuracy'])}")
            rows.append(cells)
    emit("D4", "Leakage-Free Subset Performance Across All Subset Sizes",
         ["Classifier", "k", "Corr. AUC", "Corr. Acc.", "IG AUC", "IG Acc.", "χ² AUC", "χ² Acc."], rows,
         "Mean ± SD over 100 test folds for AUC; mean accuracy. Corr. = correlation; IG = information gain; χ² = chi-square. "
         "At k = 30 all three criteria retain every feature, so the three columns coincide and equal the Table 3 values.",
         part="appendix", landscape=True)

    rows = []
    for s in SELS:
        for r in st[st.selector == s].sort_values("k").itertuples():
            rows.append([SL[s], str(r.k), lz(r.nogueira), lz(r.jaccard), str(r.n_distinct), f"{pct(r.modal_freq)}%",
                         ", ".join(data.pretty(x) for x in r.modal_subset.split("|")) if r.k <= 5 else "–"])
    emit("D3", "Stability of Fold-Internal Feature Selection",
         ["Criterion", "k", "Nogueira index", "Mean pairwise Jaccard", "Distinct subsets (of 100)", "Modal subset frequency", "Modal subset (k ≤ 5)"],
         rows, "Computed over the 100 training folds. Nogueira index: 1 = identical subsets in every fold; > .75 excellent, "
               ".40–.75 intermediate agreement (Nogueira et al.).", part="appendix", landscape=True)

    rows = []
    for r in sc.itertuples():
        rows.append([mlabel(r.model), str(r.k), f"{SL[r.a]} vs {SL[r.b]}", f"{f(r.dAUC, 4)} {ci(r.dAUC_lo, r.dAUC_hi, 4)}",
                     pv(r.p), pv(r.p_holm), f(r.dAcc, 4), pv(r.dAcc_p_holm)])
    emit("D2", "Fold-Paired Comparisons Between Filter Criteria",
         ["Classifier", "k", "Comparison", "ΔAUC [95% CI]", "p", "p (Holm)", "ΔAccuracy", "p (Holm)"], rows,
         "Nadeau–Bengio corrected resampled t-tests on 100 fold-paired differences (first criterion minus second); Holm "
         "adjustment across all 27 comparisons for each metric.", part="appendix", landscape=True)

    po = store.load_table("pooled_operating")
    rows = []
    for r in po.itertuples():
        rows.append([mlabel(r.model), f"{r.TP} / {r.FN} / {r.FP} / {r.TN}", f"{f(r.AUC)} {ci(r.AUC_lo, r.AUC_hi)}",
                     f"{f(r.Sensitivity)} {ci(r.Sensitivity_lo, r.Sensitivity_hi)}", f"{f(r.Specificity)} {ci(r.Specificity_lo, r.Specificity_hi)}",
                     f"{f(r.PPV)} {ci(r.PPV_lo, r.PPV_hi)}", f"{f(r.NPV)} {ci(r.NPV_lo, r.NPV_hi)}", f"{f(r.Accuracy)} {ci(r.Accuracy_lo, r.Accuracy_hi)}"])
    emit("C1", "Pooled Out-of-Fold Operating Characteristics at Threshold 0.5",
         ["Classifier", "TP / FN / FP / TN", "AUC [95% CI]", "Sensitivity", "Specificity", "PPV", "NPV", "Accuracy"], rows,
         "Each case contributes one prediction: its out-of-fold probability averaged over the 10 repeats. AUC CI by DeLong "
         "(logit-transformed); proportion CIs by the Wilson method. TP = true positives (malignant correctly flagged); "
         "FN = missed malignancies; FP = false alarms; TN = true negatives.", part="appendix", landscape=True)

    rows = []
    for t in CFG["evaluation"]["dca_report"]:
        for m in order:
            r = rep[(rep.model == m) & (rep.threshold == t)].iloc[0]
            rows.append([f"{int(round(100 * t))}%", mlabel(m), f(r.nb, 4), f(r.nb_all, 4), f"{f(r.dnb, 4)} {ci(r.dnb_lo, r.dnb_hi, 4)}",
                         f(r.avoided_per100, 1), f"{r.TP} / {r.FP}"])
    emit("E1", "Net Benefit Across Clinically Plausible Biopsy Thresholds",
         ["Threshold", "Classifier", "Net benefit", "NB biopsy all", "ΔNB [95% CI]", "Biopsies avoided /100", "TP / FP at threshold"], rows,
         "Net benefit = TP/n − FP/n x t/(1 − t). Biopsy none has net benefit 0. Bootstrap percentile intervals "
         f"({CFG['evaluation']['bootstrap']} resamples).", part="appendix")

    sens = store.load_table("sensitivity")
    sens["_id"] = sens["analysis"].str.split(" ").str[0]
    sens["_m"] = [["LR", "RF", "GBT"].index(m) for m in sens["model"]]
    sens = sens.sort_values(["_id"], kind="mergesort").reset_index(drop=True)

    def grid_txt(g):
        import ast
        d = ast.literal_eval(g)
        nm = {"C": "C", "max_features": "max features", "min_samples_leaf": "min. leaf",
              "learning_rate": "learning rate", "max_depth": "depth"}
        return ", ".join(f"{nm[k]} = {v}" for k, v in d.items())
    rows = []
    for r in sens.itertuples():
        d = "–" if (isinstance(r.dAUC, float) and np.isnan(r.dAUC)) else f"{f(r.dAUC, 4)} {ci(r.dAUC_lo, r.dAUC_hi, 4)}"
        extra = (f" (modal choice: {grid_txt(r.modal_best)}, {pct(r.modal_best_freq, 0)}% of folds)"
                 if isinstance(getattr(r, "modal_best", np.nan), str) else "")
        rows.append([r.analysis.split(" ", 1)[0], r.analysis.split(" ", 1)[1] + extra, mlabel(r.model), str(r.n_folds),
                     f"{f(r.AUC)} {ci(r.AUC_lo, r.AUC_hi)}", f"{f(r.Accuracy)} {ci(r.Acc_lo, r.Acc_hi)}",
                     f"{f(r.Sensitivity)} / {f(r.Specificity)}", d])
    emit("F2", "Sensitivity Analyses",
         ["ID", "Analysis", "Classifier", "Folds", "AUC [95% CI]", "Accuracy [95% CI]", "Sens. / Spec.", "ΔAUC vs primary [95% CI]"],
         rows, "ΔAUC is the fold-paired difference from the primary analysis (same folds); not defined for S2, which uses "
               "different (5-fold) partitions. S6 restricts the input to one feature family (10 features) or to the mean and "
               "worst families (20 features).", part="appendix", landscape=True)

    rec = store.load_table("reconciliation")
    rows = []
    for r in rec.itertuples():
        def g_(x, d=3):
            v = getattr(r, x)
            return "–" if pd.isna(v) else f(v, d)
        sd = lambda x: "" if pd.isna(getattr(r, x + "_sd", np.nan)) else f" ± {f(getattr(r, x + '_sd'))}"
        cm = "–" if pd.isna(r.TP) else f"{int(r.TP)} / {int(r.FN)} / {int(r.FP)} / {int(r.TN)}"
        rep_pr = "–" if pd.isna(r.Precision_reported) else f"{f(r.Precision_reported)} / {f(r.Recall_reported)}"
        rows.append([r.source, mlabel(r.model) if r.model != "ADA" else "AdaBoost", r.positive_class,
                     g_("Accuracy") + sd("Accuracy"), g_("AUC") + sd("AUC"), rep_pr, g_("Sensitivity"), g_("Specificity"), cm])
    rcn = est["reconciliation"]
    emit("F3", "Reconciliation With the Antecedent Outputs",
         ["Source", "Classifier", "Positive class", "Accuracy", "AUC", "Reported precision / recall", "Sensitivity (malignant)",
          "Specificity (malignant)", "TP / FN / FP / TN"], rows,
         f"RapidMiner 7.1 rows are parsed from the deposited .per performance vectors (mean ± population SD over 10 folds) and "
         f"their accumulated confusion matrices. Their positive class was benign, so the reported precision and recall describe "
         f"the benign class (e.g., LR recall {f(rcn['rm_lr_recall_reported'])} = benign recall); re-deriving with malignancy as "
         f"the positive class gives LR sensitivity {f(rcn['rm_lr_sens_malignant'])}. results_summary.xlsx is the Python output "
         f"quoted in the antecedent README (gradient-boosted trees in place of AdaBoost). The Python analogue reruns the "
         f"antecedent settings (single 10-fold CV, seed 2026, no standardisation, depth-10 trees). This-study counts are pooled "
         f"(repeat-averaged probabilities).", part="appendix", landscape=True)

    mis = store.load_table("misclassification_overlap")
    prof = store.load_table("misclassification_profile")
    rows = [[str(r.n_models_wrong), str(r.n_cases), str(r.n_malignant), str(r.n_benign)] for r in mis.itertuples()]
    emit("C2", "Agreement of Errors Across the Five Full-Feature Classifiers",
         ["Classifiers misclassifying the case", "Cases", "Malignant", "Benign"], rows,
         f"Pooled out-of-fold classification at 0.5. {rcn['n_any_wrong']} cases were misclassified by at least one classifier "
         f"and {rcn['n_all_wrong']} by all five; {rcn['n_hard_malignant']} of the {rcn['n_hard']} cases misclassified by three or "
         f"more classifiers were malignant. Case-level listing: results/tables/misclassified_cases.csv.",
         part="appendix", widths=[2.4, 1.0, 1.0, 1.0])

    rows = []
    for r in prof.itertuples():
        rows.append([data.pretty(r.feature), r._2, f"{r.hard_mean:.4g} (n = {r.n_hard})" if not np.isnan(r.hard_mean) else f"– (n = {r.n_hard})",
                     f"{r.easy_mean:.4g} (n = {r.n_easy})"])
    emit("C3", "Feature Profile of Persistently Misclassified Cases",
         ["Feature", "True class", "Mean, misclassified by ≥ 3 classifiers", "Mean, correctly classified by all"], rows,
         "The six features with the best mean full-sample rank. Persistently missed malignancies sit at benign-like values of "
         "the size and concavity features, and the reverse holds for persistent false alarms.", part="appendix")

    cost = summ[summ.metric.isin(["fit_s", "predict_ms_per_case"])]
    rows = []
    for m in MODEL_ORDER:
        a = cost[(cost.model == m) & (cost.metric == "fit_s")].iloc[0]
        b = cost[(cost.model == m) & (cost.metric == "predict_ms_per_case")].iloc[0]
        rows.append([mlabel(m), f"{a['mean']:.3f} [{a['lo']:.3f}, {a['hi']:.3f}]", f"{b['mean']:.4f} [{b['lo']:.4f}, {b['hi']:.4f}]"])
    emit("F4", "Computational Cost per Training Fold (Full Feature Set)",
         ["Classifier", "Fit time, s: median [IQR]", "Prediction time per case, ms: median [IQR]"], rows,
         "Wall-clock times over 100 training folds of about 512 cases, single CPU thread per fit (two folds in parallel), "
         "Python 3.13, scikit-learn 1.9. Absolute times are hardware-dependent; the ratios between classifiers are the "
         "transferable result.", part="appendix", widths=[2.0, 2.3, 2.5])

    lc = store.load_table("learning_curve")
    rows = []
    for fr in sorted(lc["fraction"].unique()):
        d = lc[lc.fraction == fr].set_index("model")
        rows.append([f"{int(round(100 * fr))}%", f"{d['n_train'].iloc[0]:.0f}"] +
                     [f"{f(d.loc[m, 'AUC'])} ± {f(d.loc[m, 'AUC_sd'])}" for m in ["LR", "RF", "GBT", "LR5", "LRc"]])
    emit("E3", "Learning Curves: Test-Fold AUC Against Training-Set Size",
         ["Training fraction", "Training cases", "LR", "RF", "GBT", ML["LR5"], ML["LRc"]], rows,
         f"Mean ± SD over {CFG['evaluation']['learning_repeats']} × 10 test folds; the training fold is stratified-subsampled "
         f"and the test fold is unchanged. The compact models repeat their feature selection on each subsample. At 100% the "
         f"values differ slightly from Table 3 because only the first {CFG['evaluation']['learning_repeats']} repeats are used.",
         part="appendix")

    (OUT / "_index.json").write_text(json.dumps(REG, indent=1), encoding="utf-8")
    print(len(REG), "tables:", REG)
