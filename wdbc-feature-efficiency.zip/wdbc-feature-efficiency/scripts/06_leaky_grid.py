"""Stage 06 — the antecedent (leaky) protocol, reproduced to measure its optimism.

Features are ranked once on all 569 cases — as in the antecedent analysis — and the
fixed top-k subset is then cross-validated on the same folds and model seeds as
stage 05. The paired difference (leaky minus leakage-free) is the selection optimism.
"""
import numpy as np
import pandas as pd

from _common import CFG, SEED, Timer
from wdbcfs import cv, data, metrics, store
from wdbcfs.models import make_pipeline
from wdbcfs.selectors import TopK, rank_from_scores, score_features

X, y, feats = data.load(CFG)
Xn = X.to_numpy()
K, R = CFG["cv"]["folds"], CFG["cv"]["repeats"]
SPLITS = cv.splits(y, K, R, SEED)
SELS = CFG["selection"]["selectors"]
MODELS = CFG["selection"]["subset_models"]
KGRID = [k for k in CFG["selection"]["leaky_k_grid"] if k < len(feats)]
THR = CFG["evaluation"]["threshold"]
ORDERS = {s: rank_from_scores(score_features(Xn, y, s, SEED, CFG["selection"]["mi_neighbors"])) for s in SELS}


def one(r, f, tr, te):
    fs = cv.fold_seed(SEED, r, f)
    rows = []
    for model in MODELS:
        for s in SELS:
            for k in KGRID:
                pipe = make_pipeline(model, CFG, fs, selector=TopK(s, k, order=ORDERS[s]))
                pipe.fit(Xn[tr], y[tr])
                p = pipe.predict_proba(Xn[te])[:, 1]
                m = metrics.classification_metrics(y[te], p, THR)
                m.update(model=model, selector=s, k=k, repeat=r, fold=f, n_train=len(tr), n_test=len(te))
                rows.append(m)
    return rows


if __name__ == "__main__":
    with Timer("06 leaky grid"):
        res = cv.run(one, SPLITS)
        folds = pd.DataFrame([row for rr in res for row in rr])
        store.save_table("leaky_folds", folds)
        print(folds.groupby(["model", "selector", "k"])["AUC"].mean().unstack(0).round(4).to_string())
