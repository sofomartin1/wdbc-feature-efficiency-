"""Stage 05 — leakage-free top-k feature subsets (RQ1, RQ2, RQ3).

Within every one of the 100 training folds, each filter criterion ranks the 30
features using the training cases only; the top-k features are then standardised
and passed to the classifier, and the untouched test fold is scored. The test folds
and model seeds are identical to stage 02, so k = 30 reproduces the full-feature
results exactly and every k < 30 is compared with k = 30 on the same folds.
"""
import numpy as np
import pandas as pd

from _common import CFG, SEED, Timer
from wdbcfs import cv, data, metrics, store
from wdbcfs.models import make_pipeline
from wdbcfs.selectors import TopK, rank_from_scores, score_features

X, y, feats = data.load(CFG)
Xn = X.to_numpy()
K, R = CFG["cv"]["folds"], CFG["cv"]["repeats"]
SPLITS = cv.splits(y, K, R, SEED)
SELS = CFG["selection"]["selectors"]
MODELS = CFG["selection"]["subset_models"]
KGRID = CFG["selection"]["k_grid"]
D = len(feats)
THR = CFG["evaluation"]["threshold"]


def one(r, f, tr, te):
    fs = cv.fold_seed(SEED, r, f)
    orders = {s: rank_from_scores(score_features(Xn[tr], y[tr], s, fs, CFG["selection"]["mi_neighbors"]))
              for s in SELS}
    rows, probs = [], {}
    for model in MODELS:
        full = None
        for s in SELS:
            for k in KGRID:
                if k == D and full is not None:
                    p = full
                else:
                    pipe = make_pipeline(model, CFG, fs, selector=TopK(s, k, order=orders[s]))
                    pipe.fit(Xn[tr], y[tr])
                    p = pipe.predict_proba(Xn[te])[:, 1]
                    if k == D:
                        full = p
                m = metrics.classification_metrics(y[te], p, THR)
                m.update(model=model, selector=s, k=k, repeat=r, fold=f, n_train=len(tr), n_test=len(te))
                rows.append(m)
                probs[(model, s, k)] = p
    return rows, probs, te, np.vstack([orders[s] for s in SELS])


if __name__ == "__main__":
    with Timer("05 subset grid"):
        res = cv.run(one, SPLITS)
        rows = [row for rr, _, _, _ in res for row in rr]
        folds = pd.DataFrame(rows)
        store.save_table("subset_folds", folds)

        P = {f"{m}|{s}": np.full((len(KGRID), R, len(y)), np.nan) for m in MODELS for s in SELS}
        orders = np.zeros((len(SPLITS), len(SELS), D), dtype=int)
        for i, ((_, probs, te, ords), (r, f, _, _)) in enumerate(zip(res, SPLITS)):
            orders[i] = ords
            for (m, s, k), p in probs.items():
                P[f"{m}|{s}"][KGRID.index(k), r, te] = p
        assert not any(np.isnan(v).any() for v in P.values())
        store.save_arrays("oof_subset", y=y, k_grid=np.array(KGRID), **P)
        store.save_arrays("fold_rankings", orders=orders, selectors=np.array(SELS), feats=np.array(feats))
        print(folds.groupby(["model", "selector", "k"])["AUC"].mean().unstack(0).round(4).to_string())
