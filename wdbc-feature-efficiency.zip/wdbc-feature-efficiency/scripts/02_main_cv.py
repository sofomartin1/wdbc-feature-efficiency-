"""Stage 02 — full-feature comparison of five classifiers under 10 × 10 repeated stratified CV.

Outputs
  tables/main_folds.csv          one row per model x test fold (metrics, fit/predict time)
  tables/main_summary.csv        mean, SD and Nadeau-Bengio corrected 95% CI per metric
  tables/main_pooled.csv         pooled out-of-fold metrics (repeat-averaged probabilities)
  arrays/oof_main.npz            out-of-fold probability, shape (repeats, n), per model
"""
import time

import numpy as np
import pandas as pd

from _common import CFG, SEED, Timer
from wdbcfs import cv, data, metrics, store
from wdbcfs.models import MODEL_ORDER, make_pipeline

X, y, feats = data.load(CFG)
Xn = X.to_numpy()
K, R = CFG["cv"]["folds"], CFG["cv"]["repeats"]
SPLITS = cv.splits(y, K, R, SEED)
THR = CFG["evaluation"]["threshold"]


def one(model, r, f, tr, te):
    pipe = make_pipeline(model, CFG, cv.fold_seed(SEED, r, f))
    t0 = time.perf_counter()
    pipe.fit(Xn[tr], y[tr])
    t1 = time.perf_counter()
    p = pipe.predict_proba(Xn[te])[:, 1]
    t2 = time.perf_counter()
    m = metrics.classification_metrics(y[te], p, THR)
    m.update(model=model, repeat=r, fold=f, n_train=len(tr), n_test=len(te),
             fit_s=t1 - t0, predict_ms_per_case=1000 * (t2 - t1) / len(te))
    return m, te, p


with Timer("02 main CV"):
    rows, oof = [], {}
    for model in MODEL_ORDER:
        res = cv.run(lambda r, f, tr, te, _m=model: one(_m, r, f, tr, te), SPLITS)
        P = np.full((R, len(y)), np.nan)
        for (m, te, p), (r, f, _, _) in zip(res, SPLITS):
            rows.append(m)
            P[r, te] = p
        assert not np.isnan(P).any()
        oof[model] = P
        print(model, "mean AUC", np.mean([m["AUC"] for m, _, _ in res]), flush=True)

    folds = pd.DataFrame(rows)
    store.save_table("main_folds", folds)
    store.save_arrays("oof_main", y=y, **oof)

    n_tr, n_te = folds["n_train"].mean(), folds["n_test"].mean()
    summ = []
    for model in MODEL_ORDER:
        d = folds[folds.model == model]
        for met in metrics.METRICS:
            ci = metrics.corrected_t(d[met].to_numpy(), n_tr, n_te,
                                    bounds=(-1.0, 1.0) if met in ("MCC", "Kappa") else (0.0, 1.0))
            summ.append({"model": model, "metric": met, "mean": ci["mean"], "sd": ci["sd"],
                         "lo": ci["lo"], "hi": ci["hi"]})
        summ.append({"model": model, "metric": "fit_s", "mean": d["fit_s"].median(), "sd": np.nan,
                     "lo": d["fit_s"].quantile(.25), "hi": d["fit_s"].quantile(.75)})
        summ.append({"model": model, "metric": "predict_ms_per_case", "mean": d["predict_ms_per_case"].median(),
                     "sd": np.nan, "lo": d["predict_ms_per_case"].quantile(.25),
                     "hi": d["predict_ms_per_case"].quantile(.75)})
    summ = pd.DataFrame(summ)
    store.save_table("main_summary", summ)

    # pooled analyses on the case-level probability averaged over the R repeats
    pooled = []
    for model in MODEL_ORDER:
        pbar = oof[model].mean(0)
        m = metrics.classification_metrics(y, pbar, THR)
        auc, lo, hi = metrics.delong_ci(y, pbar)
        rep_auc = [metrics.classification_metrics(y, oof[model][r], THR)["AUC"] for r in range(R)]
        m.update(model=model, AUC_lo=lo, AUC_hi=hi, rep_auc_min=min(rep_auc), rep_auc_max=max(rep_auc))
        pooled.append(m)
    pooled = pd.DataFrame(pooled)
    store.save_table("main_pooled", pooled)

    best = summ[summ.metric == "AUC"].sort_values("mean", ascending=False).iloc[0]
    store.put("main", {
        "folds": K, "repeats": R, "n_test_folds": K * R, "mean_n_train": n_tr, "mean_n_test": n_te,
        "best_model_auc": best["model"], "best_auc": best["mean"],
        "auc": {mm: float(summ[(summ.model == mm) & (summ.metric == "AUC")]["mean"].iloc[0]) for mm in MODEL_ORDER},
        "accuracy": {mm: float(summ[(summ.model == mm) & (summ.metric == "Accuracy")]["mean"].iloc[0]) for mm in MODEL_ORDER},
        "sensitivity": {mm: float(summ[(summ.model == mm) & (summ.metric == "Sensitivity")]["mean"].iloc[0]) for mm in MODEL_ORDER},
        "specificity": {mm: float(summ[(summ.model == mm) & (summ.metric == "Specificity")]["mean"].iloc[0]) for mm in MODEL_ORDER},
    })
    print(summ[summ.metric.isin(["AUC", "Accuracy", "Sensitivity", "Specificity"])].round(4).to_string())
