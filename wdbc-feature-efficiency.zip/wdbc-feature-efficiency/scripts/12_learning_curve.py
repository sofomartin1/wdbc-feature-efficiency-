"""Stage 12 — learning curves: test-fold AUC against the number of training cases.

For each of the first 5 repeats (50 folds) the training fold is sub-sampled
(stratified) to each fraction; the test fold is unchanged. The two compact logistic
models repeat their feature selection on each sub-sample.
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from _common import CFG, SEED, Timer
from wdbcfs import cv, data, metrics, store
from wdbcfs.models import make_pipeline
from wdbcfs.selectors import TopK

X, y, feats = data.load(CFG)
Xn = X.to_numpy()
K, R = CFG["cv"]["folds"], CFG["cv"]["repeats"]
NR = CFG["evaluation"]["learning_repeats"]
SPLITS = [s for s in cv.splits(y, K, R, SEED) if s[0] < NR]
FR = CFG["evaluation"]["learning_fractions"]


def one(r, f, tr, te):
    comp = store.get("subsets")["compact"]
    five = store.get("subsets")["five"]
    fs = cv.fold_seed(SEED, r, f)
    rows = []
    for fr in FR:
        if fr < 1:
            sub, _ = train_test_split(tr, train_size=fr, stratify=y[tr], random_state=fs)
        else:
            sub = tr
        mi = CFG["selection"]["mi_neighbors"]
        specs = [("LR", None), ("RF", None), ("GBT", None),
                 ("LR5", TopK(five["selector"], five["k"], seed=fs, mi_neighbors=mi)),
                 ("LRc", TopK(comp["selector"], comp["k"], seed=fs, mi_neighbors=mi))]
        for name, sel in specs:
            pipe = make_pipeline("LR" if name.startswith("LR") else name, CFG, fs, selector=sel)
            pipe.fit(Xn[sub], y[sub])
            p = pipe.predict_proba(Xn[te])[:, 1]
            m = metrics.classification_metrics(y[te], p)
            rows.append({"model": name, "fraction": fr, "n_train": len(sub), "repeat": r, "fold": f,
                         "AUC": m["AUC"], "Accuracy": m["Accuracy"], "Brier": m["Brier"]})
    return rows


if __name__ == "__main__":
    with Timer("12 learning curve"):
        res = cv.run(one, SPLITS)
        lc = pd.DataFrame([row for rr in res for row in rr])
        store.save_table("learning_folds", lc)
        summ = lc.groupby(["model", "fraction"]).agg(n_train=("n_train", "mean"), AUC=("AUC", "mean"),
                                                      AUC_sd=("AUC", "std"), Accuracy=("Accuracy", "mean"),
                                                      Brier=("Brier", "mean")).reset_index()
        store.save_table("learning_curve", summ)
        print(summ.round(4).to_string())
