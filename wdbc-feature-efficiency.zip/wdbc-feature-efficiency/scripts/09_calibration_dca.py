"""Stage 09 — calibration and clinical utility of out-of-fold predictions.

Pooled analyses use each case's out-of-fold probability averaged over the 10 repeats
(every case is a test case once per repeat). Percentile bootstrap (2,000 resamples of
cases) gives 95% intervals. The compact logistic model is the specification fixed in
stage 07, evaluated on its own leakage-free out-of-fold predictions from stage 05.
"""
import numpy as np
import pandas as pd

from _common import CFG, SEED, Timer
from wdbcfs import metrics, store
from wdbcfs.models import MODEL_ORDER

with Timer("09 calibration + DCA"):
    oof = store.load_arrays("oof_main")
    y = oof["y"]
    sub = store.load_arrays("oof_subset")
    comp = store.get("subsets")["compact"]
    five = store.get("subsets")["five"]
    kgrid = list(sub["k_grid"])
    preds = {m: oof[m].mean(0) for m in MODEL_ORDER}
    preds["LR5"] = sub[f"LR|{five['selector']}"][kgrid.index(five["k"])].mean(0)
    preds["LRc"] = sub[f"LR|{comp['selector']}"][kgrid.index(comp["k"])].mean(0)
    order = MODEL_ORDER + ["LR5", "LRc"]

    ev = CFG["evaluation"]
    rng = np.random.default_rng(SEED)
    B = ev["bootstrap"]
    boot_idx = [rng.integers(0, len(y), len(y)) for _ in range(B)]
    a, b, c = ev["dca_thresholds"]
    ts = np.round(np.arange(a, b + c / 2, c), 4)

    rows, curves, dca = [], {}, []
    for m in order:
        p = preds[m]
        citl, slope = metrics.calibration_slope_intercept(y, p)
        bs = []
        for idx in boot_idx:
            yy, pp = y[idx], p[idx]
            ci_, sl_ = metrics.calibration_slope_intercept(yy, pp)
            bs.append([np.mean((pp - yy) ** 2),
                       metrics.scaled_brier(yy, pp), ci_, sl_, metrics.ece(yy, pp, ev["calibration_bins"])])
        bs = np.array(bs)
        lo, hi = np.percentile(bs, [2.5, 97.5], axis=0)
        point = [np.mean((p - y) ** 2), metrics.scaled_brier(y, p), citl, slope, metrics.ece(y, p, ev["calibration_bins"])]
        row = {"model": m}
        for i, name in enumerate(["Brier", "ScaledBrier", "CITL", "Slope", "ECE"]):
            row.update({name: point[i], f"{name}_lo": lo[i], f"{name}_hi": hi[i]})
        rows.append(row)
        mp, ob, nn = metrics.reliability_curve(y, p, ev["calibration_bins"])
        curves[m] = np.vstack([mp, ob, nn])
        for t in ts:
            dca.append({"model": m, "threshold": t, "nb": metrics.net_benefit(y, p, t)})
    for t in ts:
        dca.append({"model": "TreatAll", "threshold": t, "nb": metrics.net_benefit_all(y, t)})
        dca.append({"model": "TreatNone", "threshold": t, "nb": 0.0})
    cal = pd.DataFrame(rows)
    dca = pd.DataFrame(dca)
    store.save_table("calibration", cal)
    store.save_table("dca", dca)
    store.save_arrays("reliability", **curves)

    # net benefit at reporting thresholds with bootstrap CI of the difference vs treat-all
    rep = []
    for t in ev["dca_report"]:
        nb_all = metrics.net_benefit_all(y, t)
        for m in order:
            p = preds[m]
            nb = metrics.net_benefit(y, p, t)
            diffs = [metrics.net_benefit(y[i], p[i], t) - metrics.net_benefit_all(y[i], t) for i in boot_idx]
            lo, hi = np.percentile(diffs, [2.5, 97.5])
            tp, fp, fn, tn = metrics.confusion(y, p, t)
            # interventions avoided per 100 relative to treat-all (Vickers et al.)
            avoided = (nb - nb_all) / (t / (1 - t)) * 100
            rep.append({"model": m, "threshold": t, "nb": nb, "nb_all": nb_all, "dnb": nb - nb_all,
                        "dnb_lo": lo, "dnb_hi": hi, "avoided_per100": avoided,
                        "TP": tp, "FP": fp, "FN": fn, "TN": tn})
    rep = pd.DataFrame(rep)
    store.save_table("dca_report", rep)

    # pooled operating characteristics (incl. compact) at the 0.5 threshold, with Wilson CIs
    from statsmodels.stats.proportion import proportion_confint
    op = []
    for m in order:
        p = preds[m]
        mm = metrics.classification_metrics(y, p, ev["threshold"])
        auc, alo, ahi = metrics.delong_ci(y, p)
        row = {"model": m, "AUC": auc, "AUC_lo": alo, "AUC_hi": ahi}
        for name, num, den in [("Sensitivity", mm["TP"], mm["TP"] + mm["FN"]),
                               ("Specificity", mm["TN"], mm["TN"] + mm["FP"]),
                               ("PPV", mm["TP"], mm["TP"] + mm["FP"]), ("NPV", mm["TN"], mm["TN"] + mm["FN"]),
                               ("Accuracy", mm["TP"] + mm["TN"], len(y))]:
            lo, hi = proportion_confint(num, den, method="wilson")
            row.update({name: num / den, f"{name}_lo": lo, f"{name}_hi": hi})
        row.update(TP=mm["TP"], FP=mm["FP"], FN=mm["FN"], TN=mm["TN"])
        op.append(row)
    op = pd.DataFrame(op)
    store.save_table("pooled_operating", op)

    store.put("calibration", {
        "compact_label": f"LR ({comp['selector']}, k = {comp['k']})",
        "five_label": f"LR ({five['selector']}, k = {five['k']})",
        "slope": {r.model: r.Slope for r in cal.itertuples()},
        "citl": {r.model: r.CITL for r in cal.itertuples()},
        "brier": {r.model: r.Brier for r in cal.itertuples()},
        "best_brier_model": cal.loc[cal["Brier"].idxmin(), "model"],
        "nb10": {r.model: r.nb for r in rep[rep.threshold == 0.10].itertuples()},
        "nb_all10": float(rep[rep.threshold == 0.10]["nb_all"].iloc[0]),
    })
    print(cal.round(4).to_string())
    print(rep.round(4).to_string())
    print(op.round(4).to_string())
