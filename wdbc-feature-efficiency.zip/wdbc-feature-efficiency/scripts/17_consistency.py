"""Stage 17 — consistency gate across the results store, display tables and figures.

Exit status is non-zero if any check fails, and the Word document is built only
after this gate passes (see run_all.py). Results are written to
results/consistency_report.json. Tables B1 and B2 (the reproducibility record, which
describes this gate) are assembled after it by stage 18 and are therefore not inspected.
"""
import json
import re
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from _common import CFG, ROOT
from wdbcfs import data, metrics, store
from wdbcfs.models import MODEL_ORDER

TAB = ROOT / "results" / "display_tables"
FIG = ROOT / "results" / "figures"
X, y, feats = data.load(CFG)
D = len(feats)
SELS = CFG["selection"]["selectors"]
SUBM = CFG["selection"]["subset_models"]
EST = store.load_estimates()
sys.path.insert(0, str(ROOT / "scripts"))
from display_plan import APPENDICES, FIGURES, MAIN, RECORD_TABLES, TABLES  # noqa: E402

SPECS = {p.stem[len("table_"):]: json.loads(p.read_text(encoding="utf-8")) for p in TAB.glob("table_*.json")}
SPECS = {k: v for k, v in SPECS.items() if k not in RECORD_TABLES}
MAN = json.loads((FIG / "manifest.json").read_text(encoding="utf-8"))
RESULTS = []


def check(family, name, ok, detail=""):
    RESULTS.append({"family": family, "check": name, "pass": bool(ok), "detail": str(detail)})


def num(s):
    """First number in a formatted cell (handles '−', leading '.')."""
    m = re.search(r"-?\d*\.?\d+", str(s).replace("−", "-"))
    return float(m.group()) if m else np.nan


def nums(s):
    return [float(v) for v in re.findall(r"-?\d*\.\d+|-?\d+", str(s).replace("−", "-"))]


def close(a, b, tol):
    return abs(a - b) <= tol + 1e-12


ML = {m: CFG["models"][m]["label"] for m in MODEL_ORDER}
ML["ADA"] = "AdaBoost"
ML["LRc"] = "Compact LR"

# ============================================================== A. data and class counts
dd = EST["data"]
check("A data", "n = 569, 212 malignant", dd["n"] == 569 and dd["n_malignant"] == 212 and dd["n_benign"] == 357)
check("A data", "identical to UCI/scikit-learn copy", dd["sklearn_match"])
po = store.load_table("pooled_operating")
for r in po.itertuples():
    check("A data", f"Table C1 {r.model}: TP+FN = 212 and FP+TN = 357", r.TP + r.FN == 212 and r.FP + r.TN == 357)
    check("A data", f"Table C1 {r.model}: sensitivity = TP/(TP+FN)", close(r.Sensitivity, r.TP / (r.TP + r.FN), 1e-8))
    check("A data", f"Table C1 {r.model}: specificity = TN/(TN+FP)", close(r.Specificity, r.TN / (r.TN + r.FP), 1e-8))
    check("A data", f"Table C1 {r.model}: accuracy = (TP+TN)/n", close(r.Accuracy, (r.TP + r.TN) / 569, 1e-8))
desc = store.load_table("feature_descriptives")
check("A data", "Table A1 has 30 features", len(desc) == 30 and len(SPECS["A1"]["rows"]) == 30)
t1 = {r[0]: r[1] for r in SPECS["1"]["rows"]}
check("A data", "Table 1 class counts", "212 (37.3%)" in t1["Malignant / benign"] and "357 (62.7%)" in t1["Malignant / benign"])

# ============================================================== B. identities between analyses
main = store.load_table("main_folds")
sub = store.load_table("subset_folds")
for m in SUBM:
    a = main[main.model == m].sort_values(["repeat", "fold"])["AUC"].to_numpy()
    for s in SELS:
        b = sub[(sub.model == m) & (sub.selector == s) & (sub.k == D)].sort_values(["repeat", "fold"])["AUC"].to_numpy()
        check("B identity", f"{m}/{s}: k = 30 subset folds reproduce stage-02 folds exactly", np.array_equal(a, b))
oof = store.load_arrays("oof_main")
for m in MODEL_ORDER:
    P = oof[m]
    fold_auc = main[main.model == m]["AUC"].mean()
    check("B identity", f"{m}: OOF array complete (10 × 569)", P.shape == (10, 569) and not np.isnan(P).any())
    pooled = store.load_table("main_pooled").set_index("model").loc[m, "AUC"]
    check("B identity", f"{m}: pooled AUC recomputes from OOF", close(pooled, roc_auc_score(y, P.mean(0)), 1e-8))
    check("B identity", f"{m}: pooled vs mean fold AUC within 0.01", abs(pooled - fold_auc) < 0.01, f"{pooled:.4f} vs {fold_auc:.4f}")
osub = store.load_arrays("oof_subset")
kg = list(osub["k_grid"])
for m in SUBM:
    for s in SELS:
        check("B identity", f"{m}/{s}: subset OOF at k = 30 equals main OOF",
              np.allclose(osub[f"{m}|{s}"][kg.index(D)], oof[m], atol=0))

# ============================================================== C. tables vs store
summ = store.load_table("main_summary")
cols = SPECS["3"]["columns"]
metmap = {"AUC": "AUC", "Accuracy": "Accuracy", "Sensitivity": "Sensitivity", "Specificity": "Specificity", "PPV": "PPV",
          "NPV": "NPV", "F1": "F1", "MCC": "MCC", "κ": "Kappa", "Brier": "Brier"}
for row, m in zip(SPECS["3"]["rows"], MODEL_ORDER):
    check("C tables", f"Table 3 row label {m}", row[0] == ML[m])
    for c, cell in zip(cols[1:], row[1:]):
        g = summ[(summ.model == m) & (summ.metric == metmap[c])].iloc[0]
        v = nums(cell)
        ok = close(v[0], g["mean"], 5e-4) and close(v[1], g["sd"], 5e-4) and close(v[2], g["lo"], 5e-4) and close(v[3], g["hi"], 5e-4)
        check("C tables", f"Table 3 {m} {c} matches store", ok, cell)
        check("C tables", f"Table 3 {m} {c}: CI contains mean", g["lo"] - 1e-9 <= g["mean"] <= g["hi"] + 1e-9)
# T7 full AUC equals T3 AUC
for row in SPECS["7"]["rows"]:
    m = [k for k, v in ML.items() if v == row[0]][0]
    t3 = summ[(summ.model == m) & (summ.metric == "AUC")]["mean"].iloc[0]
    check("C tables", f"Table 7 {row[0]}/{row[1]}: AUC(k = 30) equals Table 3", close(num(row[2]), t3, 5e-4))
# A3 rows at k = 30 equal T3 AUC
for row in SPECS["D4"]["rows"]:
    if row[1] == str(D):
        m = [k for k, v in ML.items() if v == row[0]][0]
        t3 = summ[(summ.model == m) & (summ.metric == "AUC")]["mean"].iloc[0]
        check("C tables", f"Table D4 {m} k = 30: all criteria equal Table 3", all(close(num(row[i]), t3, 5e-4) for i in (2, 4, 6)))
# T4 pairwise vs store
pw = store.load_table("pairwise")
for row, r in zip(SPECS["4"]["rows"], pw.itertuples()):
    v = nums(row[1])
    check("C tables", f"Table 4 {r.a}-{r.b}: ΔAUC and CI", close(v[0], r.dAUC, 5e-5) and close(v[1], r.dAUC_lo, 5e-5) and close(v[2], r.dAUC_hi, 5e-5))
    check("C tables", f"Table 4 {r.a}-{r.b}: Holm p ≥ raw p", r.dAUC_p_holm >= r.dAUC_p - 1e-12)
    check("C tables", f"Table 4 {r.a}-{r.b}: ΔAUC equals difference of Table 3 means",
          close(r.dAUC, summ[(summ.model == r.a) & (summ.metric == "AUC")]["mean"].iloc[0]
                - summ[(summ.model == r.b) & (summ.metric == "AUC")]["mean"].iloc[0], 1e-8))
# Table 7 decision rules
ks = store.load_table("kstar")
grid = store.load_table("subset_summary")
mg = CFG["selection"]["margin"]
for r in ks.itertuples():
    g = grid[(grid.model == r.model) & (grid.selector == r.selector)].sort_values("k")
    check("C rules", f"{r.model}/{r.selector}: k(CI rule) ≥ k(point rule)", r.k_ni >= r.k_point)
    check("C rules", f"{r.model}/{r.selector}: CI rule satisfied at k*", g[g.k == r.k_ni]["dAUC_lo"].iloc[0] >= -mg)
    check("C rules", f"{r.model}/{r.selector}: CI rule fails for every smaller k", (g[g.k < r.k_ni]["dAUC_lo"] < -mg).all())
    check("C rules", f"{r.model}/{r.selector}: point rule fails for every smaller k", (g[g.k < r.k_point]["dAUC"] < -mg).all())
    check("C rules", f"{r.model}/{r.selector}: ΔAUC = AUC(k) − AUC(30)",
          close(r.dAUC_ni, r.AUC_ni - r.AUC_full, 1e-8))
comp = EST["subsets"]["compact"]
lr_ks = ks[ks.model == "LR"]
check("C rules", "compact specification uses the smallest LR CI-rule k", comp["k"] == lr_ks["k_ni"].min())
check("C rules", "compact selector attains that k", int(lr_ks[lr_ks.selector == comp["selector"]]["k_ni"].iloc[0]) == comp["k"])
five = EST["subsets"]["five"]
cm = EST["compact_model"]
st = store.load_table("stability")
check("C rules", "Compact LR (CI rule) has k features", len(cm["LRc"]["features"]) == comp["k"])
check("C rules", "Compact LR (5) has 5 features", len(cm["LR5"]["features"]) == five["k"] == 5)
check("C rules", "Compact LR (5) uses the most stable criterion at k = 5",
      st[(st.k == 5)].sort_values("nogueira", ascending=False)["nogueira"].iloc[0]
      == st[(st.k == 5) & (st.selector == five["selector"])]["nogueira"].iloc[0])
check("C rules", "Table 10 lists intercept + 5 terms", len(SPECS["10"]["rows"]) == five["k"] + 1)
check("C rules", "Table E2 lists intercept + k terms", len(SPECS["E2"]["rows"]) == comp["k"] + 1)
for tag, sp in (("LR5", five), ("LRc", comp)):
    check("C rules", f"{tag}: final-model features equal full-sample top-k of its criterion",
          sorted(cm[tag]["features"]) == sorted(sp["full_sample_subset"]))
# Table 9 vs store
cal = store.load_table("calibration").set_index("model")
CPRED = {"LR5": osub[f"LR|{EST['subsets']['five']['selector']}"][kg.index(5)].mean(0),
         "LRc": osub[f"LR|{comp['selector']}"][kg.index(comp['k'])].mean(0)}
for row, m in zip(SPECS["9"]["rows"], MODEL_ORDER + ["LR5", "LRc"]):
    check("C tables", f"Table 9 {m}: Brier", close(num(row[1]), cal.loc[m, "Brier"], 5e-5))
    check("C tables", f"Table 9 {m}: slope", close(num(row[4]), cal.loc[m, "Slope"], 5e-3))
    check("C tables", f"Table 9 {m}: slope CI contains estimate", cal.loc[m, "Slope_lo"] <= cal.loc[m, "Slope"] <= cal.loc[m, "Slope_hi"])
    check("C tables", f"Table 9 {m}: pooled Brier recomputes",
          close(cal.loc[m, "Brier"], np.mean(((CPRED[m] if m in CPRED else oof[m].mean(0)) - y) ** 2), 1e-8))
# DCA identities
dca = store.load_table("dca")
for t in (0.1, 0.2, 0.3):
    v = dca[(dca.model == "TreatAll") & (np.isclose(dca.threshold, t))]["nb"].iloc[0]
    check("C rules", f"net benefit of biopsy-all at {t}", close(v, y.mean() - (1 - y.mean()) * t / (1 - t), 1e-8))
rep = store.load_table("dca_report")
for r in rep.itertuples():
    check("C rules", f"ΔNB {r.model} at {r.threshold}: TP/FP reproduce NB",
          close(r.nb, r.TP / 569 - r.FP / 569 * r.threshold / (1 - r.threshold), 1e-8))
# Table F1 vs optimism store and Table D4
op = store.load_table("optimism")
for r in op.itertuples():
    free = grid[(grid.model == r.model) & (grid.selector == r.selector) & (grid.k == r.k)]["AUC"].iloc[0]
    check("C tables", f"Table F1 {r.model}/{r.selector}/k={r.k}: leakage-free AUC equals Table D4", close(r.AUC_free, free, 1e-8))
    check("C rules", f"Table F1 {r.model}/{r.selector}/k={r.k}: optimism = leaky − free", close(r.optimism, r.AUC_leaky - r.AUC_free, 1e-8))
# stability
st = store.load_table("stability")
check("C rules", "Nogueira indices within [−1, 1]", st["nogueira"].between(-1, 1).all())
check("C rules", "modal frequency × 100 ≥ 1 and ≤ 100", st["modal_freq"].between(0.01, 1).all())
# Table 6 cells equal grid
for row in SPECS["6"]["rows"]:
    if row[1] in ("3", "5", "10"):
        m = [k for k, v in ML.items() if v == row[0]][0]
        for i, s in enumerate(SELS):
            g = grid[(grid.model == m) & (grid.selector == s) & (grid.k == int(row[1]))].iloc[0]
            v = nums(row[2 + i])
            check("C tables", f"Table 6 {m}/{s}/k={row[1]}", close(v[0], g["AUC"], 5e-4) and close(v[1], g["Accuracy"], 5e-4)
                  and close(v[2], g["Sensitivity"], 5e-4) and close(v[3], g["Specificity"], 5e-4))
# Table 5 vs rankings store
rk = store.load_table("rankings_full")
for row, r in zip(SPECS["5"]["rows"], rk.itertuples()):
    check("C tables", f"Table 5 {r.feature}: ranks", nums(row[2])[-1] == r.Correlation_rank and nums(row[3])[-1] == r.InformationGain_rank
          and nums(row[4])[-1] == r.ChiSquare_rank)
# reconciliation logic
rec = store.load_table("reconciliation")
for r in rec[rec.source.str.startswith("RapidMiner")].itertuples():
    check("C rules", f"RapidMiner {r.model}: reported recall equals benign recall TN/(TN+FP)",
          close(r.Recall_reported, r.TN / (r.TN + r.FP), 5e-3), f"{r.Recall_reported:.4f} vs {r.TN / (r.TN + r.FP):.4f}")
    check("C rules", f"RapidMiner {r.model}: reported accuracy ≈ pooled confusion accuracy",
          close(r.Accuracy, (r.TP + r.TN) / 569, 5e-3))
    check("C rules", f"RapidMiner {r.model}: counts sum to 569 with 212 malignant", r.TP + r.FN == 212 and r.FP + r.TN == 357)
for r in rec[rec.source.str.startswith("This study")].itertuples():
    check("C tables", f"Table F3 this-study {r.model} AUC equals Table 3",
          close(r.AUC, summ[(summ.model == r.model) & (summ.metric == "AUC")]["mean"].iloc[0], 1e-8))
# misclassification
mis = store.load_table("misclassification_overlap")
check("C rules", "Table C2 cases sum to 569", mis["n_cases"].sum() == 569)
check("C rules", "Table C2 malignant sum to 212", mis["n_malignant"].sum() == 212)
check("C rules", "Table C2 'any wrong' matches estimate", mis[mis.n_models_wrong > 0]["n_cases"].sum() == EST["reconciliation"]["n_any_wrong"])
# sensitivity table
sens = store.load_table("sensitivity")
check("C tables", "Table F2 row count equals sensitivity store", len(SPECS["F2"]["rows"]) == len(sens))
for r in sens.itertuples():
    check("C rules", f"Table F2 {r.analysis}/{r.model}: CI contains AUC", r.AUC_lo - 1e-9 <= r.AUC <= r.AUC_hi + 1e-9)

# ============================================================== D. figures vs tables
for m in MODEL_ORDER:
    a6 = po.set_index("model").loc[m, "AUC"]
    check("D figures", f"Figure 3 {m}: legend AUC equals Table C1", close(MAN["fig_3"][m]["auc"], round(a6, 3), 1e-9))
for b, v in MAN["fig_C1"].items():
    r = pw[(pw.a == "LR") & (pw.b == b)].iloc[0]
    check("D figures", f"Figure C1 LR−{b}: forest point equals Table 4", close(v["dAUC"], round(r.dAUC, 4), 1e-9))
for key, v in MAN["fig_5"].items():
    m, s = key.split("|")
    r = ks[(ks.model == m) & (ks.selector == s)].iloc[0]
    check("D figures", f"Figure 5 {key}: star at Table 7 k (CI rule)", v["k_ni"] == r.k_ni and close(v["auc_k_ni"], round(r.AUC_ni, 4), 1e-9))
for s in SELS:
    for k, v in MAN["fig_4"]["nogueira"][s].items():
        sv = st[(st.selector == s) & (st.k == int(k))]["nogueira"].iloc[0]
        check("D figures", f"Figure 4 {s} k={k}: stability equals Table D3", close(v, round(sv, 3), 1e-9))
for m, v in MAN["fig_6"].items():
    check("D figures", f"Figure 6 {m}: legend slope equals Table 9", close(v, round(cal.loc[m, "Slope"], 2), 1e-9))
for tag, d in MAN["fig_7"].items():
    coef = store.load_table(f"compact_coefficients_{tag}").set_index("term")
    for t, v in d.items():
        check("D figures", f"Figure 7 {tag}/{t}: OR equals Table {'10' if tag == 'LR5' else 'E2'}",
              close(v, round(coef.loc[t, "OR_per_SD"], 3), 1e-9))
for key, d in MAN["fig_8"].items():
    m, s = key.split("|")
    for k, v in d.items():
        r = op[(op.model == m) & (op.selector == s) & (op.k == int(k))].iloc[0]
        check("D figures", f"Figure 8 {key} k={k}: optimism equals Table F1", close(v, round(r.optimism, 4), 1e-9))
for m, M in MAN["fig_C2"].items():
    r = po.set_index("model").loc[m]
    check("D figures", f"Figure C2 {m}: confusion equals Table C1", M == [[r.TP, r.FN], [r.FP, r.TN]])
lc = store.load_table("learning_curve")
for m, d in MAN["fig_E1"].items():
    full = lc[(lc.model == m) & (lc.fraction == 1.0)]["AUC"].iloc[0]
    check("D figures", f"Figure E1 {m}: final point equals Table E3", close(max(d.items())[1], round(full, 4), 1e-9))
for key, v in MAN["fig_F1"].items():
    a, m = key.split("|")
    if a == "Primary analysis":
        ref = summ[(summ.model == m) & (summ.metric == "AUC")]["mean"].iloc[0]
    else:
        ref = sens[(sens.analysis.str.split(" ", n=1).str[1] == a) & (sens.model == m)]["AUC"].iloc[0]
    check("D figures", f"Figure F1 {key}: equals Tables 3/F2", close(v, round(ref, 4), 1e-9))
check("D figures", "Figure C3 counts equal Table C2", MAN["fig_C3"]["n_cases"] == mis["n_cases"].tolist())
for key, d in MAN["fig_F2"].items():
    src, met = key.split("|")
    for m, v in d.items():
        ref = rec[(rec.source == src) & (rec.model == m)][met].iloc[0]
        check("D figures", f"Figure F2 {src}/{m}/{met}: equals Table F3", close(v, round(ref, 4), 1e-9))
rf = store.load_table("rfe_frequency")
for m, d in MAN["fig_D2"].items():
    for ftr, v in d.items():
        ref = rf[(rf.model == m) & (rf.feature == ftr)]["freq"].iloc[0]
        check("D figures", f"Figure D2 {m}/{ftr}", close(v, round(ref, 2), 1e-9))
fr = store.load_table("selection_frequency")
for s, d in MAN["fig_4"]["freq_k5"].items():
    for ftr, v in d.items():
        ref = fr[(fr.selector == s) & (fr.k == 5) & (fr.feature == ftr)]["freq"].iloc[0]
        check("D figures", f"Figure 4b {s}/{ftr}", close(v, round(ref, 2), 1e-9))
for s, d in MAN["fig_D1"].items():
    for ftr, v in d.items():
        check("D figures", f"Figure D1 {s}/{ftr}: rank equals Table D1", v == int(rk.set_index("feature").loc[ftr, f"{s}_rank"]))

# ============================================================== E. formatting and inventory
for tid, sp in SPECS.items():
    txt = json.dumps(sp, ensure_ascii=False)
    check("E format", f"{tid}: no missing-value strings", not re.search(r"\b(nan|NaN|None|inf)\b", txt.replace("Biopsy none", "")))
    check("E format", f"{tid}: has note", len(sp["note"]) > 20)
    check("E format", f"{tid}: no process labels", not re.search(r"hypothetical|edited|modified|simulated|watermark", txt, re.I))
    widths = {len(r) for r in sp["rows"]}
    check("E format", f"{tid}: rectangular", widths == {len(sp["columns"])})
pngs = sorted(p.name for p in FIG.glob("*.png"))
check("E format", "19 figure files present", len(pngs) == 19, pngs)
from PIL import Image
for p in FIG.glob("*.png"):
    im = Image.open(p).convert("L")
    arr = np.asarray(im)
    check("E format", f"{p.name}: non-blank and ≥ 300 dpi width", arr.std() > 5 and im.size[0] >= 1200)

# ============================================================== F. numbering and cross-references
APP_ORDER = [d for _, _, ds in APPENDICES for d in ds]
for part, seq in (("main", MAIN), ("appendix", APP_ORDER)):
    for kind in ("T", "F"):
        got = [n for k, n in seq if k == kind]
        if part == "main":
            expect = [str(i) for i in range(1, len(got) + 1)]
        else:   # sequential within each appendix letter, letters in alphabetical order
            expect = []
            for letter, _, ds in APPENDICES:
                cnt = sum(1 for k, _ in ds if k == kind)
                expect += [f"{letter}{i}" for i in range(1, cnt + 1)]
        check("F numbering", f"{part} {kind}: numbered sequentially in order of appearance", got == expect, got)
check("F numbering", "every display table is placed in the document", set(TABLES) - RECORD_TABLES == set(SPECS),
      set(SPECS) ^ (set(TABLES) - RECORD_TABLES))
check("F numbering", "every figure is placed in the document",
      {n for k, n in MAIN + APP_ORDER if k == "F"} == set(FIGURES))
expected_refs = {("5", "D1"): "rankings_full", ("6", "D4"): "grid", ("6", "D2"): "selector", ("9", "E1"): "net benefit",
                 ("10", "E2"): "compact 15"}
target_title = {"rankings_full": "Complete Full-Sample Ranking", "grid": "Across All Subset Sizes",
                "selector": "Between Filter Criteria", "net benefit": "Net Benefit", "compact 15": f"{comp['k']} Features"}
for (src, ref), what in expected_refs.items():
    txt = SPECS[src]["note"]
    check("F numbering", f"Table {src} note cites Table {ref}", f"Table {ref}" in txt)
    check("F numbering", f"Table {ref} is the intended display ({what})", target_title[what] in SPECS[ref]["title"])
for tid, sp in SPECS.items():
    for ref in re.findall(r"Table ([A-F]?\d+)", sp["note"]):
        check("F numbering", f"Table {tid}: cited Table {ref} exists", ref in TABLES)
for key, fg in FIGURES.items():
    for ref in re.findall(r"Table ([A-F]?\d+)", fg["title"] + fg.get("note", "")):
        check("F numbering", f"Figure {key}: cited Table {ref} exists", ref in TABLES)

# ============================================================== report
df = pd.DataFrame(RESULTS)
out = {"n_checks": len(df), "n_pass": int(df["pass"].sum()), "n_fail": int((~df["pass"]).sum()),
       "by_family": df.groupby("family")["pass"].agg(["count", "sum"]).astype(int).to_dict(orient="index"),
       "failures": df[~df["pass"]].to_dict(orient="records")}
(ROOT / "results" / "consistency_report.json").write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
print(json.dumps({k: v for k, v in out.items() if k != "failures"}, indent=1, ensure_ascii=False))
for f_ in out["failures"][:40]:
    print("FAIL", f_)
sys.exit(1 if out["n_fail"] else 0)
