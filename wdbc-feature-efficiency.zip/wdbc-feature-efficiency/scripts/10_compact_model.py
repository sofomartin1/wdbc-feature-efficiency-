"""Stage 10 — the compact logistic model fitted on all 569 cases, with bootstrap
coefficient intervals and Harrell optimism correction (selection repeated in every
bootstrap sample), compared with the 30-feature logistic model."""
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from statsmodels.stats.outliers_influence import variance_inflation_factor

from _common import CFG, SEED, Timer
from wdbcfs import data, metrics, store
from wdbcfs.selectors import rank_from_scores, score_features

X, y, feats = data.load(CFG)
Xn = X.to_numpy()
SPECS = {"LR5": store.get("subsets")["five"], "LRc": store.get("subsets")["compact"]}
C = CFG["models"]["LR"]["C"]
MAXIT = CFG["models"]["LR"]["max_iter"]


def fit_lr(Xs, ys):
    sc = StandardScaler().fit(Xs)
    lr = LogisticRegression(C=C, max_iter=MAXIT).fit(sc.transform(Xs), ys)
    return sc, lr


def perf(sc, lr, Xs, ys):
    # AUC and Brier only: in-sample calibration slopes are unidentified under the
    # (quasi-)separation that occurs in bootstrap resamples, so slopes come from the
    # cross-validated calibration analysis instead (stage 09).
    p = lr.predict_proba(sc.transform(Xs))[:, 1]
    return np.array([roc_auc_score(ys, p), np.mean((p - ys) ** 2)])


def subset_cols(Xs, ys, seed, sel, k):
    return np.sort(rank_from_scores(score_features(Xs, ys, sel, seed, CFG["selection"]["mi_neighbors"]))[:k])


with Timer("10 compact models"):
    nb = CFG["evaluation"]["optimism_bootstrap"]
    rng2 = np.random.default_rng(SEED + 1)
    boot_samples = [rng2.integers(0, len(y), len(y)) for _ in range(nb)]
    app_full = perf(*fit_lr(Xn, y), Xn, y)
    opt_full = np.mean([perf(*fit_lr(Xn[i], y[i]), Xn[i], y[i]) - perf(*fit_lr(Xn[i], y[i]), Xn, y)
                        for i in boot_samples], 0)
    rows = [{"model": "LR (30 features)", "metric": met, "apparent": app_full[j], "optimism": opt_full[j],
             "corrected": app_full[j] - opt_full[j]} for j, met in enumerate(["AUC", "Brier"])]
    bf_all, est = [], {"auc_corrected_full": float(app_full[0] - opt_full[0])}
    for tag, comp in SPECS.items():
        SEL, K = comp["selector"], comp["k"]
        cols_sorted = np.sort(np.array([feats.index(f) for f in comp["full_sample_subset"]]))
        sc, lr = fit_lr(Xn[:, cols_sorted], y)
        beta = lr.coef_[0]
        rng = np.random.default_rng(SEED)
        boots = []
        for _ in range(CFG["evaluation"]["bootstrap"]):
            idx = rng.integers(0, len(y), len(y))
            _, l_b = fit_lr(Xn[idx][:, cols_sorted], y[idx])
            boots.append(np.r_[l_b.intercept_, l_b.coef_[0]])
        lo, hi = np.percentile(np.array(boots), [2.5, 97.5], axis=0)
        Z = sc.transform(Xn[:, cols_sorted])
        vif = [variance_inflation_factor(Z, j) for j in range(Z.shape[1])]
        coef = pd.DataFrame({
            "term": ["(Intercept)"] + [feats[j] for j in cols_sorted],
            "label": ["Intercept"] + [data.pretty(feats[j]) for j in cols_sorted],
            "beta_std": np.r_[lr.intercept_, beta], "lo": lo, "hi": hi,
            "OR_per_SD": np.exp(np.r_[lr.intercept_, beta]), "OR_lo": np.exp(lo), "OR_hi": np.exp(hi),
            "mean": np.r_[np.nan, sc.mean_], "sd": np.r_[np.nan, sc.scale_], "vif": np.r_[np.nan, vif],
        })
        b_raw = beta / sc.scale_
        coef["beta_raw"] = np.r_[lr.intercept_[0] - np.sum(beta * sc.mean_ / sc.scale_), b_raw]
        store.save_table(f"compact_coefficients_{tag}", coef)

        app = perf(sc, lr, Xn[:, cols_sorted], y)
        opt, cnt = [], np.zeros(len(feats))
        for b, idx in enumerate(boot_samples):
            Xb, yb = Xn[idx], y[idx]
            cb = subset_cols(Xb, yb, SEED + b, SEL, K)
            cnt[cb] += 1
            c_sc, c_lr = fit_lr(Xb[:, cb], yb)
            opt.append(perf(c_sc, c_lr, Xb[:, cb], yb) - perf(c_sc, c_lr, Xn[:, cb], y))
        opt = np.mean(opt, 0)
        rows += [{"model": tag, "metric": met, "apparent": app[j], "optimism": opt[j], "corrected": app[j] - opt[j]}
                 for j, met in enumerate(["AUC", "Brier"])]
        bf_all.append(pd.DataFrame({"spec": tag, "feature": feats, "freq": cnt / nb}))
        est[tag] = {"selector": SEL, "k": K, "features": [feats[j] for j in cols_sorted],
                    "n_vif_gt10": int(np.sum(np.array(vif) > 10)), "vif_max": float(np.max(vif)),
                    "auc_corrected": float(app[0] - opt[0]),
                    "n_or_ci_excl1": int(((coef["OR_lo"] > 1) | (coef["OR_hi"] < 1)).iloc[1:].sum()),
                    "bootstrap_features_ge80": [f for f, v in zip(feats, cnt / nb) if v >= 0.8]}
        print(tag, coef.round(3).to_string())
    optab = pd.DataFrame(rows)
    store.save_table("optimism_bootstrap", optab)
    store.save_table("bootstrap_selection_frequency", pd.concat(bf_all, ignore_index=True))
    store.put("compact_model", est)
    print(optab.round(4).to_string())
