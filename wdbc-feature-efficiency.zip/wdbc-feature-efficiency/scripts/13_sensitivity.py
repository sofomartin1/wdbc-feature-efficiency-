"""Stage 13 — sensitivity analyses around the primary protocol.

S1  Nested hyperparameter tuning (inner 5-fold grid search, 3 × 10 outer folds)
S2  5-fold instead of 10-fold cross-validation (10 × 5)
S3  Class-weighted training (balanced weights; LR and RF)
S4  Logistic regression without standardisation
S5  Logistic regression on log-transformed features
S6  Feature-family ablation (mean, standard-error, worst, mean + worst) for LR, RF, GBT
Every analysis reports mean test-fold AUC and accuracy with the corrected 95% CI and
the paired difference from the primary analysis where the folds coincide.
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, StandardScaler

from _common import CFG, SEED, Timer
from wdbcfs import cv, data, metrics, store
from wdbcfs.models import make_classifier, make_pipeline
from wdbcfs.selectors import TopK

X, y, feats = data.load(CFG)
Xn = X.to_numpy()
K, R = CFG["cv"]["folds"], CFG["cv"]["repeats"]
SPLITS = cv.splits(y, K, R, SEED)
FAM = {"Mean": [i for i, f in enumerate(feats) if f.startswith("mean_")],
       "Standard error": [i for i, f in enumerate(feats) if f.endswith("_error")],
       "Worst": [i for i, f in enumerate(feats) if f.startswith("worst_")]}
FAM["Mean + worst"] = sorted(FAM["Mean"] + FAM["Worst"])


def score(pipe, tr, te):
    pipe.fit(Xn[tr], y[tr])
    p = pipe.predict_proba(Xn[te])[:, 1]
    m = metrics.classification_metrics(y[te], p)
    return {"AUC": m["AUC"], "Accuracy": m["Accuracy"], "Sensitivity": m["Sensitivity"],
            "Specificity": m["Specificity"], "n_train": len(tr), "n_test": len(te)}


def primary_like(r, f, tr, te):
    fs = cv.fold_seed(SEED, r, f)
    rows = []
    for m in ("LR", "RF"):
        rows.append(dict(analysis="S3 Class-weighted", model=m, repeat=r, fold=f,
                         **score(make_pipeline(m, CFG, fs, override={"class_weight": "balanced"}), tr, te)))
    rows.append(dict(analysis="S4 No standardisation", model="LR", repeat=r, fold=f,
                     **score(make_pipeline("LR", CFG, fs, scale=False), tr, te)))
    logp = Pipeline([("log", FunctionTransformer(np.log1p)), ("scale", StandardScaler()),
                     ("clf", make_classifier("LR", CFG, fs))])
    rows.append(dict(analysis="S5 Log-transformed", model="LR", repeat=r, fold=f, **score(logp, tr, te)))
    for fam, idx in FAM.items():
        for m in ("LR", "RF", "GBT"):
            rows.append(dict(analysis=f"S6 Family: {fam}", model=m, repeat=r, fold=f,
                             **score(make_pipeline(m, CFG, fs, selector=TopK(k=len(idx), order=np.array(idx))),
                                     tr, te)))
    return rows


def nested(r, f, tr, te):
    fs = cv.fold_seed(SEED, r, f)
    rows = []
    for m, grid in CFG["tuning_grids"].items():
        pipe = make_pipeline(m, CFG, fs)
        gs = GridSearchCV(pipe, {f"clf__{k}": v for k, v in grid.items()}, scoring="roc_auc",
                          cv=StratifiedKFold(CFG["cv"]["inner_folds"], shuffle=True, random_state=fs), n_jobs=1)
        res = score(gs, tr, te)
        res["best"] = str({k.replace("clf__", ""): v for k, v in gs.best_params_.items()})
        rows.append(dict(analysis="S1 Nested tuning", model=m, repeat=r, fold=f, **res))
    return rows


def fivefold(r, f, tr, te):
    fs = cv.fold_seed(SEED, r, f)
    return [dict(analysis="S2 5-fold CV", model=m, repeat=r, fold=f, **score(make_pipeline(m, CFG, fs), tr, te))
            for m in ("LR", "RF", "GBT")]


if __name__ == "__main__":
    with Timer("13 sensitivity"):
        rows = [x for rr in cv.run(primary_like, SPLITS) for x in rr]
        nsp = [s for s in SPLITS if s[0] < CFG["cv"]["nested_repeats"]]
        rows += [x for rr in cv.run(nested, nsp) for x in rr]
        rows += [x for rr in cv.run(fivefold, cv.splits(y, 5, R, SEED)) for x in rr]
        sf = pd.DataFrame(rows)
        store.save_table("sensitivity_folds", sf)

        main = store.load_table("main_folds")
        out = []
        for (an, m), d in sf.groupby(["analysis", "model"], sort=False):
            n_tr, n_te = d["n_train"].mean(), d["n_test"].mean()
            a = metrics.corrected_t(d["AUC"].to_numpy(), n_tr, n_te, bounds=(0, 1))
            c = metrics.corrected_t(d["Accuracy"].to_numpy(), n_tr, n_te, bounds=(0, 1))
            row = {"analysis": an, "model": m, "n_folds": len(d), "AUC": a["mean"], "AUC_lo": a["lo"], "AUC_hi": a["hi"],
                   "Accuracy": c["mean"], "Acc_lo": c["lo"], "Acc_hi": c["hi"],
                   "Sensitivity": d["Sensitivity"].mean(), "Specificity": d["Specificity"].mean()}
            if not an.startswith("S2"):     # same folds as the primary analysis -> paired difference
                ref = main[(main.model == m)].set_index(["repeat", "fold"]).loc[
                    list(zip(d["repeat"], d["fold"]))]
                dd = metrics.corrected_t(d["AUC"].to_numpy() - ref["AUC"].to_numpy(), n_tr, n_te)
                row.update(dAUC=dd["mean"], dAUC_lo=dd["lo"], dAUC_hi=dd["hi"], dAUC_p=dd["p"])
            if an.startswith("S1"):
                row["modal_best"] = d["best"].value_counts().index[0]
                row["modal_best_freq"] = d["best"].value_counts().iloc[0] / len(d)
            out.append(row)
        sens = pd.DataFrame(out)
        store.save_table("sensitivity", sens)
        fam = sens[sens.analysis.str.startswith("S6")]
        store.put("sensitivity", {
            "max_abs_dAUC_S1_S5": float(sens[~sens.analysis.str.startswith(("S2", "S6"))]["dAUC"].abs().max()),
            "family_best": fam.loc[fam["AUC"].idxmax(), ["analysis", "model"]].tolist(),
            "family_se_auc": {r.model: r.AUC for r in fam[fam.analysis.str.contains("Standard error")].itertuples()},
            "family_worst_auc": {r.model: r.AUC for r in fam[fam.analysis.str.contains("Family: Worst")].itertuples()},
        })
        print(sens.round(4).to_string())
