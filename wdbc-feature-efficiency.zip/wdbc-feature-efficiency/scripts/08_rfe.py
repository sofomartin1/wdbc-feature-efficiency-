"""Stage 08 — model-specific (wrapper/embedded) selection for RQ3.

Recursive feature elimination (step 1) inside each training fold, driven by each
classifier's own importance: |standardised coefficient| for logistic regression and
impurity importance for the two tree ensembles. Uses the first 5 repeats (50 folds)
of the same split list as stages 02 and 05.
"""
import numpy as np
import pandas as pd
from sklearn.feature_selection import RFE
from sklearn.preprocessing import StandardScaler

from _common import CFG, SEED, Timer
from wdbcfs import cv, data, metrics, store
from wdbcfs.models import make_classifier, make_pipeline
from wdbcfs.selectors import TopK

X, y, feats = data.load(CFG)
Xn = X.to_numpy()
K, R = CFG["cv"]["folds"], CFG["cv"]["repeats"]
NR = CFG["selection"]["rfe_repeats"]
SPLITS = [s for s in cv.splits(y, K, R, SEED) if s[0] < NR]
MODELS = CFG["selection"]["subset_models"]
SIZES = CFG["selection"]["rfe_sizes"]
THR = CFG["evaluation"]["threshold"]


def one(r, f, tr, te):
    fs = cv.fold_seed(SEED, r, f)
    sc = StandardScaler().fit(Xn[tr])
    Ztr = sc.transform(Xn[tr])
    rows = []
    for model in MODELS:
        for k in SIZES:
            rfe = RFE(make_classifier(model, CFG, fs), n_features_to_select=k, step=1).fit(Ztr, y[tr])
            support = np.where(rfe.support_)[0]
            # refit the classifier on the selected features through the standard pipeline
            pipe = make_pipeline(model, CFG, fs, selector=TopK("Correlation", k, order=support))
            pipe.fit(Xn[tr], y[tr])
            p = pipe.predict_proba(Xn[te])[:, 1]
            m = metrics.classification_metrics(y[te], p, THR)
            m.update(model=model, k=k, repeat=r, fold=f, n_train=len(tr), n_test=len(te), subset="|".join(feats[i] for i in support))
            rows.append(m)
    return rows


if __name__ == "__main__":
    with Timer("08 RFE"):
        res = cv.run(one, SPLITS)
        folds = pd.DataFrame([row for rr in res for row in rr])
        store.save_table("rfe_folds", folds)
        print(folds.groupby(["model", "k"])["AUC"].mean())
        for m in MODELS:
            print(m, folds[folds.model == m]["subset"].value_counts().head(3))
