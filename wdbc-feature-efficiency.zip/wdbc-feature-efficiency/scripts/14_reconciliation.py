"""Stage 14 — reconciliation with the antecedent outputs and misclassification analysis.

(a) Parses the RapidMiner 7.1 performance vectors (.per) shipped in antecedent/,
    re-derives malignant-positive metrics from their accumulated confusion matrices,
    and reads the Python results_summary.xlsx reported in the antecedent README.
(b) Re-runs a Python analogue of the antecedent configuration (single 10-fold CV,
    seed 2026, no standardisation, RapidMiner-like tree settings).
(c) Profiles cases misclassified by the full-feature models (pooled, 0.5 threshold).
"""
import re

import numpy as np
import pandas as pd
from sklearn.ensemble import AdaBoostClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.tree import DecisionTreeClassifier

from _common import CFG, ROOT, SEED, Timer
from wdbcfs import data, metrics, store
from wdbcfs.models import MODEL_ORDER

ANT = ROOT / "antecedent"
CRIT = ["accuracy", "classification_error", "kappa", "AUC", "precision", "recall", "f_measure"]
FILES = {"LR": "performance_Logistic_Regression.per", "RF": "performance_Random_Forest.per",
         "ADA": "performance_Boosted_Trees_AdaBoost.per"}


def parse_per(path):
    s = path.read_text(encoding="latin1")
    blocks = re.findall(r"<averageCount>(\d+)</averageCount>\s*<meanSquaredSum>([^<]+)</meanSquaredSum>\s*"
                        r"<meanSum>([^<]+)</meanSum>", s)
    vals = {}
    for name, (n, sq, su) in zip(CRIT, blocks):
        n, sq, su = int(n), float(sq), float(su)
        mean = su / n
        vals[name] = mean
        vals[name + "_sd"] = np.sqrt(max(sq / n - mean ** 2, 0))  # RapidMiner reports the population SD
    cm = re.search(r"<counter id=\"\d+\">\s*<double-array id=\"\d+\">\s*<double>([\d.]+)</double>\s*"
                   r"<double>([\d.]+)</double>\s*</double-array>\s*<double-array id=\"\d+\">\s*"
                   r"<double>([\d.]+)</double>\s*<double>([\d.]+)</double>", s)
    names = re.search(r"<classNames id=\"\d+\">\s*<string>(\w+)</string>\s*<string>(\w+)</string>", s).groups()
    pos = re.search(r"<positiveClassName>(\w+)</positiveClassName>", s).group(1)
    c = [float(v) for v in cm.groups()]
    # counter[true][pred] with classes in `names` order
    M = {(names[0], names[0]): c[0], (names[0], names[1]): c[1], (names[1], names[0]): c[2], (names[1], names[1]): c[3]}
    TP, FN = M[("Malignant", "Malignant")], M[("Malignant", "Benign")]
    FP, TN = M[("Benign", "Malignant")], M[("Benign", "Benign")]
    vals.update(positive_class=pos, TP=TP, FN=FN, FP=FP, TN=TN,
                sens_malignant=TP / (TP + FN), spec_malignant=TN / (TN + FP),
                ppv_malignant=TP / (TP + FP), recall_benign=TN / (TN + FP), precision_benign=TN / (TN + FN))
    return vals


with Timer("14 reconciliation"):
    X, y, feats = data.load(CFG)
    Xn = X.to_numpy()
    rows = []
    for m, fn in FILES.items():
        v = parse_per(ANT / fn)
        rows.append({"source": "RapidMiner 7.1 (.per)", "model": m, "positive_class": v["positive_class"],
                     "Accuracy": v["accuracy"], "Accuracy_sd": v["accuracy_sd"], "AUC": v["AUC"], "AUC_sd": v["AUC_sd"],
                     "Kappa": v["kappa"], "Precision_reported": v["precision"], "Recall_reported": v["recall"],
                     "F1_reported": v["f_measure"], "Sensitivity": v["sens_malignant"],
                     "Specificity": v["spec_malignant"], "PPV": v["ppv_malignant"],
                     "TP": v["TP"], "FN": v["FN"], "FP": v["FP"], "TN": v["TN"]})
    rs = pd.read_excel(ANT / "results_summary.xlsx", sheet_name="Perf_Full30")
    mp = {"Logistic Regression": "LR", "Random Forest": "RF", "Gradient Boosted Trees": "GBT"}
    for r in rs.itertuples():
        rows.append({"source": "results_summary.xlsx", "model": mp[r.Model], "positive_class": "Malignant",
                     "Accuracy": r.Accuracy, "AUC": r.AUC, "Kappa": r.Kappa, "Sensitivity": r.Recall_Sensitivity,
                     "Specificity": r.Specificity, "PPV": r.Precision, "F1_reported": r.F_measure})

    # Python analogue of the antecedent RapidMiner configuration
    skf = StratifiedKFold(10, shuffle=True, random_state=SEED)
    analog = {
        "LR": lambda: LogisticRegression(C=1.0, max_iter=100000),
        "RF": lambda: RandomForestClassifier(n_estimators=100, max_depth=10, criterion="entropy", random_state=SEED),
        "ADA": lambda: AdaBoostClassifier(DecisionTreeClassifier(max_depth=10, min_samples_leaf=2, min_samples_split=4,
                                                                 criterion="entropy", random_state=SEED),
                                          n_estimators=30, random_state=SEED),
    }
    for m, mk in analog.items():
        fm, tot = [], np.zeros(4)
        for tr, te in skf.split(Xn, y):
            p = mk().fit(Xn[tr], y[tr]).predict_proba(Xn[te])[:, 1]
            mm = metrics.classification_metrics(y[te], p)
            fm.append(mm)
            tot += [mm["TP"], mm["FN"], mm["FP"], mm["TN"]]
        d = pd.DataFrame(fm)
        rows.append({"source": "Python analogue of antecedent configuration", "model": m, "positive_class": "Malignant",
                     "Accuracy": d["Accuracy"].mean(), "Accuracy_sd": d["Accuracy"].std(ddof=1),
                     "AUC": d["AUC"].mean(), "AUC_sd": d["AUC"].std(ddof=1), "Kappa": d["Kappa"].mean(),
                     "Sensitivity": tot[0] / (tot[0] + tot[1]), "Specificity": tot[3] / (tot[2] + tot[3]),
                     "PPV": tot[0] / (tot[0] + tot[2]), "TP": tot[0], "FN": tot[1], "FP": tot[2], "TN": tot[3]})

    summ = store.load_table("main_summary")
    pooled = store.load_table("main_pooled").set_index("model")
    for m in ("LR", "RF", "GBT", "ADA"):
        g = summ[summ.model == m].set_index("metric")
        rows.append({"source": "This study (10 × 10 CV)", "model": m, "positive_class": "Malignant",
                     "Accuracy": g.loc["Accuracy", "mean"], "Accuracy_sd": g.loc["Accuracy", "sd"],
                     "AUC": g.loc["AUC", "mean"], "AUC_sd": g.loc["AUC", "sd"], "Kappa": g.loc["Kappa", "mean"],
                     "Sensitivity": g.loc["Sensitivity", "mean"], "Specificity": g.loc["Specificity", "mean"],
                     "PPV": g.loc["PPV", "mean"],
                     "TP": pooled.loc[m, "TP"], "FN": pooled.loc[m, "FN"], "FP": pooled.loc[m, "FP"], "TN": pooled.loc[m, "TN"]})
    rec = pd.DataFrame(rows)
    store.save_table("reconciliation", rec)

    # ---------------------------------------------------------------- misclassification analysis
    oof = store.load_arrays("oof_main")
    wrong = pd.DataFrame({m: ((oof[m].mean(0) >= 0.5).astype(int) != y) for m in MODEL_ORDER})
    nwrong = wrong.sum(1)
    mis = pd.DataFrame({"n_models_wrong": range(len(MODEL_ORDER) + 1)})
    mis["n_cases"] = [int((nwrong == k).sum()) for k in mis["n_models_wrong"]]
    mis["n_malignant"] = [int(((nwrong == k) & (y == 1)).sum()) for k in mis["n_models_wrong"]]
    mis["n_benign"] = mis["n_cases"] - mis["n_malignant"]
    store.save_table("misclassification_overlap", mis)
    # profile of persistently misclassified cases (wrong in >= 3 of 5 models) vs correctly classified
    hard = nwrong >= 3
    easy = nwrong == 0
    top = store.load_table("rankings_full")["feature"].head(6).tolist()
    prof = []
    for f in top:
        for cls, lab in [(1, "Malignant"), (0, "Benign")]:
            prof.append({"feature": f, "class": lab,
                         "hard_mean": X.loc[hard & (y == cls), f].mean() if (hard & (y == cls)).any() else np.nan,
                         "easy_mean": X.loc[easy & (y == cls), f].mean(),
                         "n_hard": int((hard & (y == cls)).sum()), "n_easy": int((easy & (y == cls)).sum())})
    store.save_table("misclassification_profile", pd.DataFrame(prof))
    store.save_table("misclassified_cases", pd.DataFrame({"case": np.where(nwrong > 0)[0] + 1,
                                                          "diagnosis": np.where(y[nwrong > 0] == 1, "Malignant", "Benign"),
                                                          "n_models_wrong": nwrong[nwrong > 0].to_numpy(),
                                                          **{m: wrong.loc[nwrong > 0, m].to_numpy().astype(int)
                                                             for m in MODEL_ORDER}}))
    store.put("reconciliation", {
        "rm_positive_class": rec[rec.source.str.startswith("RapidMiner")]["positive_class"].unique().tolist(),
        "rm_lr_recall_reported": float(rec[(rec.source.str.startswith("RapidMiner")) & (rec.model == "LR")]["Recall_reported"].iloc[0]),
        "rm_lr_sens_malignant": float(rec[(rec.source.str.startswith("RapidMiner")) & (rec.model == "LR")]["Sensitivity"].iloc[0]),
        "n_any_wrong": int((nwrong > 0).sum()), "n_all_wrong": int((nwrong == len(MODEL_ORDER)).sum()),
        "n_hard": int(hard.sum()), "n_hard_malignant": int((hard & (y == 1)).sum()),
    })
    print(rec.round(4).to_string())
    print(mis.to_string())
    print(store.get("reconciliation"))
