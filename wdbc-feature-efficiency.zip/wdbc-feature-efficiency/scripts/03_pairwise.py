"""Stage 03 — pairwise classifier comparisons on the full feature set.

Three complementary tests per pair:
  * Nadeau-Bengio corrected resampled t-test on fold-paired AUC and accuracy differences;
  * DeLong test on pooled out-of-fold (repeat-averaged) probabilities;
  * exact McNemar test on pooled classifications at the 0.5 threshold.
Holm adjustment within each family of 10 pairwise comparisons.
"""
from itertools import combinations

import numpy as np
import pandas as pd

from _common import CFG, Timer
from wdbcfs import metrics, store
from wdbcfs.models import MODEL_ORDER

with Timer("03 pairwise"):
    folds = store.load_table("main_folds")
    oof = store.load_arrays("oof_main")
    y = oof["y"]
    n_tr, n_te = folds["n_train"].mean(), folds["n_test"].mean()
    rows = []
    for a, b in combinations(MODEL_ORDER, 2):
        da = folds[folds.model == a].sort_values(["repeat", "fold"])
        db = folds[folds.model == b].sort_values(["repeat", "fold"])
        assert (da[["repeat", "fold"]].to_numpy() == db[["repeat", "fold"]].to_numpy()).all()
        cauc = metrics.corrected_t(da["AUC"].to_numpy() - db["AUC"].to_numpy(), n_tr, n_te)
        cacc = metrics.corrected_t(da["Accuracy"].to_numpy() - db["Accuracy"].to_numpy(), n_tr, n_te)
        pa, pb = oof[a].mean(0), oof[b].mean(0)
        d, lo, hi, p = metrics.delong_diff(y, pa, pb)
        nb, nc, pm = metrics.mcnemar(y, pa, pb, CFG["evaluation"]["threshold"])
        wins = float((da["AUC"].to_numpy() > db["AUC"].to_numpy()).mean())
        ties = float((da["AUC"].to_numpy() == db["AUC"].to_numpy()).mean())
        rows.append({"a": a, "b": b,
                     "dAUC": cauc["mean"], "dAUC_lo": cauc["lo"], "dAUC_hi": cauc["hi"], "dAUC_t": cauc["t"],
                     "dAUC_p": cauc["p"], "dAcc": cacc["mean"], "dAcc_lo": cacc["lo"], "dAcc_hi": cacc["hi"],
                     "dAcc_p": cacc["p"], "win_frac": wins, "tie_frac": ties,
                     "delong_d": d, "delong_lo": lo, "delong_hi": hi, "delong_p": p,
                     "mcnemar_a_only": nb, "mcnemar_b_only": nc, "mcnemar_p": pm})
    pw = pd.DataFrame(rows)
    for col in ["dAUC_p", "dAcc_p", "delong_p", "mcnemar_p"]:
        pw[col + "_holm"] = metrics.holm(pw[col].to_numpy())
    store.save_table("pairwise", pw)
    lr = pw[pw.a == "LR"]
    store.put("pairwise", {
        "n_pairs": len(pw),
        "n_sig_auc_holm": int((pw["dAUC_p_holm"] < 0.05).sum()),
        "n_sig_acc_holm": int((pw["dAcc_p_holm"] < 0.05).sum()),
        "n_sig_delong_holm": int((pw["delong_p_holm"] < 0.05).sum()),
        "n_sig_mcnemar_holm": int((pw["mcnemar_p_holm"] < 0.05).sum()),
        "lr_vs": {r.b: {"dAUC": r.dAUC, "lo": r.dAUC_lo, "hi": r.dAUC_hi, "p_holm": r.dAUC_p_holm,
                        "dAcc": r.dAcc, "dAcc_p_holm": r.dAcc_p_holm} for r in lr.itertuples()},
    })
    print(pw.round(4).to_string())
