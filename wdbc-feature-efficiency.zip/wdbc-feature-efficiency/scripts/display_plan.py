"""Display plan: numbering, order of appearance and captions of every table and figure.

Display numbers are identical to those of the article: Tables 1-10 and Figures 1-8 in the
main text, and Tables/Figures A1-F4 in Appendices A-F of the Supplementary Information.
The number of a display is also its identifier in the results store:

    results/display_tables/table_<number>.json      e.g. table_7.json, table_D3.json
    results/figures/fig_<number>_<name>.png         e.g. fig_5_auc_vs_k.png

Figure captions are the captions printed in the article. Figure notes are kept here as
documentation of what each panel shows; they are not printed in the assembled document.
"""
from _common import CFG

_m = CFG["selection"]["margin"]

# Main text, in order of first appearance.
MAIN = [("T", "1"), ("F", "1"), ("T", "2"), ("F", "2"), ("T", "3"), ("F", "3"), ("T", "4"), ("T", "5"),
        ("T", "6"), ("F", "4"), ("F", "5"), ("T", "7"), ("T", "8"), ("T", "9"), ("F", "6"), ("T", "10"),
        ("F", "7"), ("F", "8")]

# Supplementary Information: (letter, heading, displays in order of appearance).
APPENDICES = [
    ("A", "Appendix A. Data audit", [("T", "A1"), ("F", "A1")]),
    ("B", "Appendix B. Implementation and reproducibility record", [("T", "B1"), ("T", "B2")]),
    ("C", "Appendix C. Supplementary Results for The Full-Feature Comparison",
     [("F", "C1"), ("T", "C1"), ("F", "C2"), ("T", "C2"), ("F", "C3"), ("T", "C3")]),
    ("D", "Appendix D. Feature Ranking, Criterion Comparison And Subset Analyses",
     [("T", "D1"), ("F", "D1"), ("T", "D2"), ("T", "D3"), ("T", "D4"), ("F", "D2")]),
    ("E", "Appendix E. Calibration, Clinical Utility, Compact Models And Interpretation",
     [("T", "E1"), ("T", "E2"), ("T", "E3"), ("F", "E1"), ("F", "E2"), ("F", "E3")]),
    ("F", "Appendix F. Leakage, robustness, reconciliation and computational cost",
     [("T", "F1"), ("T", "F2"), ("F", "F1"), ("T", "F3"), ("F", "F2"), ("T", "F4")]),
]
APPENDIX = [d for _, _, ds in APPENDICES for d in ds]

# Tables B1 and B2 record the run itself (software, hardware, run time) and the outcome of the
# consistency gate, so they are assembled after the gate (stage 18) and are not inspected by it.
RECORD_TABLES = {"B1", "B2"}

TABLES = [n for k, n in MAIN + APPENDIX if k == "T"]


def table_file(number: str) -> str:
    return f"table_{number}.json"


FIGURES = {
    "1": {"file": "fig_1_workflow.png", "width": 6.6,
          "title": "Leakage-free evaluation workflow.",
          "note": "Feature ranking, top-k selection, standardisation and model fitting are refitted inside every training "
                  "fold of the 10 × 10 repeated stratified cross-validation; the test fold is scored once and contributes "
                  "to every downstream analysis."},
    "2": {"file": "fig_2_structure.png", "width": 6.6,
          "title": "Structure of the 30 WDBC features: (a) Pearson correlation matrix ordered by average-linkage clustering "
                   "of 1 − |r|; (b) univariate discrimination of each feature with DeLong 95% confidence intervals.",
          "note": "In (b) the AUC is oriented so that values above .5 indicate separation in either direction; colour "
                  "denotes the feature family (mean, standard error, worst)."},
    "3": {"file": "fig_3_roc_pr.png", "width": 6.6,
          "title": "Pooled out-of-fold (a) receiver operating characteristic and (b) precision–recall curves of the five "
                   "full-feature classifiers.",
          "note": "Each case contributes its out-of-fold probability averaged over the 10 repeats. Legend values in (a) are "
                  "AUC with DeLong 95% CI; the inset magnifies the upper-left corner. AP = average precision; the dotted "
                  "line in (b) is the malignant prevalence (.373)."},
    "4": {"file": "fig_4_stability.png", "width": 6.6,
          "title": "Stability of fold-internal feature selection: (a) Nogueira stability index against subset size; "
                   "(b) frequency with which each feature entered the top five across the 100 training folds.",
          "note": "Dotted lines in (a) mark the conventional thresholds for intermediate (.40) and excellent (.75) "
                  "agreement. Only features selected at least once are shown in (b)."},
    "5": {"file": "fig_5_auc_vs_k.png", "width": 6.6,
          "title": "Leakage-free test-fold AUC as a function of the number of retained features for (a) logistic "
                   "regression, (b) random forest and (c) gradient-boosted trees.",
          "note": f"Shaded ribbons are corrected 95% CIs; the dashed line is the 30-feature AUC and the grey band its "
                  f"{_m}-unit non-inferiority margin. Stars mark the smallest k meeting the confidence-interval rule of "
                  f"Table 7 (stars coincide where criteria share that k). The x-axis is logarithmic."},
    "6": {"file": "fig_6_calibration_dca.png", "width": 6.6,
          "title": "Calibration and clinical utility of the pooled out-of-fold predictions: (a) reliability diagram by "
                   "deciles of predicted probability; (b) decision curves for biopsy referral.",
          "note": "Legend values in (a) are calibration slopes (ideal 1). In (b) a model is useful at a threshold where its "
                  "net benefit exceeds both reference strategies (biopsy all, biopsy none)."},
    "7": {"file": "fig_7_compact_models.png", "width": 6.6,
          "title": "The compact logistic models fitted to all cases: odds ratio of malignancy per standard-deviation "
                   "increase for (a) the five-feature and (b) the 15-feature model; (c) frequency with which each feature "
                   "was selected across bootstrap resamples with selection repeated.",
          "note": "Intervals in (a) and (b) are 95% percentile bootstrap CIs on a logarithmic axis; the dotted line in (c) "
                  "marks 80% selection."},
    "8": {"file": "fig_8_optimism.png", "width": 6.6,
          "title": "Optimism in AUC created by ranking features on all cases before cross-validation, by subset size, "
                   "for (a) logistic regression, (b) random forest and (c) gradient-boosted trees.",
          "note": "Lines show the fold-paired difference between the leaky and the leakage-free protocol with corrected "
                  "95% CIs; values above zero are inflation."},
    "A1": {"file": "fig_A1_distributions.png", "width": 6.6,
           "title": "Class-conditional distributions (z-scores) of the six features with the best mean full-sample rank."},
    "C1": {"file": "fig_C1_fold_auc_forest.png", "width": 6.6,
           "title": "Variability and paired differences in discrimination: (a) test-fold AUC of each classifier over the "
                    "100 folds; (b) difference in AUC between logistic regression and each comparator.",
           "note": "In (a) boxes show the interquartile range, the diamond the mean. In (b) solid intervals are "
                   "Nadeau–Bengio corrected 95% CIs of fold-paired differences and dashed intervals are DeLong 95% CIs on "
                   "pooled predictions; intervals crossing zero indicate no detectable difference."},
    "C2": {"file": "fig_C2_confusion.png", "width": 6.6,
           "title": "Pooled out-of-fold confusion matrices at probability threshold 0.5.",
           "note": "Cells give counts and row percentages (true class); the two compact LR panels use their own "
                   "leakage-free out-of-fold predictions."},
    "C3": {"file": "fig_C3_misclassification.png", "width": 4.6,
           "title": "Distribution of misclassified cases by the number of full-feature classifiers that misclassify them."},
    "D1": {"file": "fig_D1_rankings.png", "width": 4.6,
           "title": "Full-Sample Rank of Each Feature Under Correlation, Information-Gain And Chi-Square Criteria.",
           "note": "Rows are ordered by mean rank; label colour denotes the feature family (blue mean, amber standard "
                   "error, red worst). Darker cells mark higher relevance."},
    "D2": {"file": "fig_D2_rfe.png", "width": 4.4,
           "title": "Frequency with which each feature was retained by model-specific recursive feature elimination "
                    "(k = 5) across 50 training folds."},
    "E1": {"file": "fig_E1_learning.png", "width": 4.8,
           "title": "Learning curves: mean test-fold AUC against the number of training cases.",
           "note": "Ribbons are ± 1 SD over 50 test folds."},
    "E2": {"file": "fig_E2_shap.png", "width": 6.6,
           "title": "SHAP explanations of the 30-feature (a) logistic regression and (b) gradient-boosted trees fitted to "
                    "all cases (ten most influential features).",
           "note": "Each point is one case; colour encodes the standardised feature value (blue low, red high); positive "
                   "SHAP values push towards malignancy."},
    "E3": {"file": "fig_E3_permutation.png", "width": 5.6,
           "title": "Permutation importance (mean drop in test-fold AUC) for the twelve most important features.",
           "note": "Averaged over the 10 test folds of the first repeat with 10 permutations each; error bars are standard "
                   "errors across folds. Values near or below zero indicate redundancy: permuting the feature leaves AUC "
                   "essentially unchanged because correlated features carry the same information."},
    "F1": {"file": "fig_F1_sensitivity.png", "width": 6.2,
           "title": "Mean test-fold AUC with corrected 95% CIs under the primary protocol and each sensitivity analysis."},
    "F2": {"file": "fig_F2_reconciliation.png", "width": 6.6,
           "title": "Reconciliation of (a) sensitivity for malignancy and (b) AUC across the antecedent RapidMiner 7.1 "
                    "outputs, a Python analogue of the antecedent configuration and the present analysis."},
}
