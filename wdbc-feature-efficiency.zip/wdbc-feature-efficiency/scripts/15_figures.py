"""Stage 15 — render every figure from the results store.

Figures are numbered as in the article (Figures 1-8 in the main text, A1-F2 in the
Supplementary Information); file names are defined in display_plan.py.

Each figure also writes the values it draws into results/figures/manifest.json so the
consistency gate can compare figure content with the tables.
"""
import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyBboxPatch
from sklearn.metrics import average_precision_score, precision_recall_curve, roc_curve

from _common import CFG, ROOT, Timer
from wdbcfs import data, store
from wdbcfs import figstyle as fs
from wdbcfs.models import MODEL_ORDER
from display_plan import FIGURES

fs.apply()
OUT = ROOT / "results" / "figures"
OUT.mkdir(parents=True, exist_ok=True)
MAN = {}
LBL = {m: CFG["models"][m]["label"] for m in MODEL_ORDER}
SELS = CFG["selection"]["selectors"]
SUBM = CFG["selection"]["subset_models"]
X, y, feats = data.load(CFG)
D = len(feats)
comp = store.get("subsets")["compact"]
five = store.get("subsets")["five"]
LBL["LR5"] = f"Compact LR ({five['k']})"
LBL["LRc"] = f"Compact LR ({comp['k']})"


def f3(v):
    return f"{v:.3f}"


# ============================================================================ Figure 1 workflow
def fig_1_workflow():
    fig, ax = plt.subplots(figsize=(7.2, 4.3))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 60)
    ax.axis("off")

    def box(x, y0, w, h, text, fc, ec, bold=False, fsz=7.2):
        ax.add_patch(FancyBboxPatch((x, y0), w, h, boxstyle="round,pad=0.4,rounding_size=1.2", fc=fc, ec=ec, lw=1.1))
        ax.text(x + w / 2, y0 + h / 2, text, ha="center", va="center", fontsize=fsz, color=fs.INK,
                fontweight="bold" if bold else "normal", wrap=True)

    def arrow(x0, y0, x1, y1):
        ax.annotate("", xy=(x1, y1), xytext=(x0, y0), arrowprops=dict(arrowstyle="-|>", color=fs.INK2, lw=1.1))

    m = store.get("main")
    box(1, 44, 20, 13, f"WDBC\n{len(y)} aspirates\n{D} nuclear features\n({int(y.sum())} malignant)",
        "#cde2fb", "#2a78d6", True)
    box(26, 44, 22, 13, f"{m['repeats']} × {m['folds']}-fold repeated\nstratified CV\n({m['n_test_folds']} test folds)",
        "#f0efec", "#52514e", True)
    ax.add_patch(FancyBboxPatch((52, 26), 46, 32, boxstyle="round,pad=0.4,rounding_size=1.5", fc="#fbfbfa",
                                ec="#1c5cab", lw=1.3, ls="--"))
    ax.text(75, 56, "Inside each training fold only", ha="center", fontsize=7.4, color="#1c5cab", fontweight="bold")
    box(54, 45, 19, 8, "Rank features\ncorrelation | information\ngain | chi-square", "#ece9fb", "#4a3aa7", fsz=6.6)
    box(77, 45, 19, 8, "Keep top-k\nk in {1,...,30}", "#ece9fb", "#4a3aa7", fsz=6.8)
    box(54, 30, 19, 9, "z-standardise\n(training mean, SD)", "#e3f4ec", "#1baf7a", fsz=6.8)
    box(77, 30, 19, 9, "Fit classifier\nLR | RF | GBT |\nAdaBoost | SVM", "#fde3d6", "#eb6834", fsz=6.6)
    arrow(21.5, 50.5, 25.5, 50.5)
    arrow(48.5, 50.5, 53.5, 50.5)
    arrow(73.5, 49, 76.5, 49)
    arrow(86.5, 44.5, 66, 39.5)
    arrow(73.5, 34.5, 76.5, 34.5)
    box(26, 19, 22, 11, "Score untouched\ntest fold\n(threshold 0.5)", "#f0efec", "#52514e")
    ax.plot([86.5, 86.5], [29.4, 24.5], color=fs.INK2, lw=1.1)
    arrow(86.6, 24.5, 48.6, 24.5)
    outs = [("Discrimination &\nclassification", 2), ("Minimal subset\nnon-inferiority\n(RQ2)", 22),
            ("Selection stability\n& model dependence\n(RQ1, RQ3)", 42), ("Calibration &\ndecision curves", 62),
            ("Leakage optimism,\ncompact model,\nsensitivity", 81)]
    for t, x in outs:
        box(x, 1, 17, 11, t, "#fff4d6", "#c98500", fsz=6.4)
        arrow(37, 18.4, x + 8.5, 12.6)
    fs.save(fig, OUT / FIGURES["1"]["file"])
    MAN["fig_1"] = {"n": int(len(y)), "folds": m["folds"], "repeats": m["repeats"]}


# ============================================================================ Figure 2 data structure
def fig_2_structure():
    corr = store.load_arrays("correlation")
    R, order = corr["R"], corr["order"]
    desc = store.load_table("feature_descriptives").sort_values("auc_directional")
    fig = plt.figure(figsize=(7.2, 3.9))
    ax = fig.add_axes([0.04, 0.12, 0.42, 0.80])
    im = ax.imshow(R[np.ix_(order, order)], cmap=fs.DIV, vmin=-1, vmax=1)
    labs = [data.pretty(feats[i]) for i in order]
    ax.set_xticks(range(D))
    ax.set_yticks(range(D))
    ax.set_xticklabels(labs, rotation=90, fontsize=4.6)
    ax.set_yticklabels(labs, fontsize=4.6)
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02)
    cb.set_label("Pearson r", fontsize=7)
    cb.ax.tick_params(labelsize=6)
    fs.panel(ax, "a")
    ax2 = fig.add_axes([0.70, 0.12, 0.28, 0.80])
    yy = np.arange(len(desc))
    cols = [fs.FAMILY_COLORS[f] for f in desc["family"]]
    lo = np.where(desc["auc"] >= 0.5, desc["auc_lo"], 1 - desc["auc_hi"])
    hi = np.where(desc["auc"] >= 0.5, desc["auc_hi"], 1 - desc["auc_lo"])
    ax2.hlines(yy, lo, hi, color=cols, lw=1.4)
    ax2.scatter(desc["auc_directional"], yy, c=cols, s=14, zorder=3, edgecolor="white", linewidth=0.5)
    ax2.set_yticks(yy)
    ax2.set_yticklabels(desc["label"], fontsize=5.2)
    ax2.axvline(0.5, color=fs.INK2, lw=0.8, ls=":")
    ax2.set_xlabel("Univariate AUC (95% CI)")
    ax2.set_xlim(0.45, 1.0)
    for fam, lab in [("mean", "Mean"), ("error", "Standard error"), ("worst", "Worst")]:
        ax2.scatter([], [], c=fs.FAMILY_COLORS[fam], s=14, label=lab)
    ax2.legend(loc="lower right", fontsize=6)
    fs.panel(ax2, "b")
    fs.save(fig, OUT / FIGURES["2"]["file"])
    MAN["fig_2"] = {"best_feature": desc.iloc[-1]["feature"], "best_auc": float(desc.iloc[-1]["auc_directional"])}


# ============================================================================ Figure 3 ROC + PR
def fig_3_roc_pr():
    oof = store.load_arrays("oof_main")
    pooled = store.load_table("main_pooled").set_index("model")
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.4))
    man = {}
    for m in MODEL_ORDER:
        p = oof[m].mean(0)
        fpr, tpr, _ = roc_curve(y, p)
        a, lo, hi = pooled.loc[m, "AUC"], pooled.loc[m, "AUC_lo"], pooled.loc[m, "AUC_hi"]
        axs[0].plot(fpr, tpr, color=fs.MODEL_COLORS[m], ls=fs.MODEL_LINES[m], lw=1.5,
                    label=f"{LBL[m]}: {f3(a)} [{f3(lo)}, {f3(hi)}]")
        pr, rc, _ = precision_recall_curve(y, p)
        ap = average_precision_score(y, p)
        axs[1].plot(rc, pr, color=fs.MODEL_COLORS[m], ls=fs.MODEL_LINES[m], lw=1.5, label=f"{LBL[m]}: AP {f3(ap)}")
        man[m] = {"auc": round(float(a), 3), "ap": round(float(ap), 3)}
    axs[0].plot([0, 1], [0, 1], color=fs.INK2, lw=0.7, ls=":")
    axs[0].set_xlabel("1 - specificity")
    axs[0].set_ylabel("Sensitivity")
    axs[0].legend(loc="lower right", fontsize=6, title="AUC [95% CI]", title_fontsize=6.2)
    ins = axs[0].inset_axes([0.42, 0.42, 0.40, 0.30])
    for m in MODEL_ORDER:
        fpr, tpr, _ = roc_curve(y, oof[m].mean(0))
        ins.plot(fpr, tpr, color=fs.MODEL_COLORS[m], ls=fs.MODEL_LINES[m], lw=1.2)
    ins.set_xlim(0, 0.12)
    ins.set_ylim(0.85, 1.0)
    ins.tick_params(labelsize=5.5)
    axs[1].axhline(y.mean(), color=fs.INK2, lw=0.7, ls=":")
    axs[1].set_xlabel("Recall (sensitivity)")
    axs[1].set_ylabel("Precision (PPV)")
    axs[1].set_ylim(0.3, 1.02)
    axs[1].legend(loc="center left", fontsize=6)
    fs.panel(axs[0], "a")
    fs.panel(axs[1], "b")
    fig.tight_layout()
    fs.save(fig, OUT / FIGURES["3"]["file"])
    MAN["fig_3"] = man


# ============================================================================ Figure C1 fold AUC + forest
def fig_C1_fold_forest():
    folds = store.load_table("main_folds")
    pw = store.load_table("pairwise")
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.2), gridspec_kw={"width_ratios": [1.05, 1]})
    ax = axs[0]
    rng = np.random.default_rng(1)
    for i, m in enumerate(MODEL_ORDER):
        v = folds[folds.model == m]["AUC"].to_numpy()
        ax.boxplot(v, positions=[i], widths=0.55, showfliers=False, patch_artist=True,
                   boxprops=dict(facecolor=fs.MODEL_COLORS[m] + "33", edgecolor=fs.MODEL_COLORS[m]),
                   medianprops=dict(color=fs.MODEL_COLORS[m], lw=1.6), whiskerprops=dict(color=fs.MODEL_COLORS[m]),
                   capprops=dict(color=fs.MODEL_COLORS[m]))
        ax.scatter(i + rng.uniform(-0.18, 0.18, len(v)), v, s=4, color=fs.MODEL_COLORS[m], alpha=0.55, lw=0)
        ax.scatter([i], [v.mean()], marker="D", s=18, color="white", edgecolor=fs.INK, zorder=4, lw=0.8)
    ax.set_xticks(range(len(MODEL_ORDER)))
    ax.set_xticklabels(["LR", "RF", "GBT", "AdaBoost", "SVM"])
    ax.set_ylabel("Test-fold AUC (100 folds)")
    fs.panel(ax, "a")
    ax = axs[1]
    rows = pw[pw.a == "LR"].reset_index(drop=True)
    man = {}
    for i, r in rows.iterrows():
        yy = len(rows) - i
        ax.hlines(yy + 0.12, r.dAUC_lo, r.dAUC_hi, color=fs.MODEL_COLORS[r.b], lw=2)
        ax.plot(r.dAUC, yy + 0.12, "o", color=fs.MODEL_COLORS[r.b], ms=5)
        ax.hlines(yy - 0.12, r.delong_lo, r.delong_hi, color=fs.MODEL_COLORS[r.b], lw=1.2, ls=(0, (2, 1)))
        ax.plot(r.delong_d, yy - 0.12, "s", mfc="white", mec=fs.MODEL_COLORS[r.b], ms=4.5)
        man[r.b] = {"dAUC": round(r.dAUC, 4), "lo": round(r.dAUC_lo, 4), "hi": round(r.dAUC_hi, 4)}
    ax.axvline(0, color=fs.INK2, lw=0.8)
    ax.set_yticks(range(len(rows), 0, -1))
    ax.set_yticklabels([f"LR - {('AdaBoost' if b == 'ADA' else b)}" for b in rows.b])
    ax.set_xlabel("Difference in AUC (95% CI)")
    ax.xaxis.set_major_locator(plt.MaxNLocator(5))
    ax.xaxis.set_major_formatter(plt.FormatStrFormatter("%.3f"))
    ax.plot([], [], "o-", color=fs.INK2, label="Corrected resampled t")
    ax.plot([], [], "s--", mfc="white", color=fs.INK2, label="DeLong (pooled)")
    ax.legend(loc="lower right", fontsize=6)
    fs.panel(ax, "b")
    fig.tight_layout()
    fs.save(fig, OUT / FIGURES["C1"]["file"])
    MAN["fig_C1"] = man


# ============================================================================ Figure D1 rankings heatmap
def fig_D1_rankings():
    rk = store.load_table("rankings_full")
    M = rk[[f"{s}_rank" for s in SELS]].to_numpy()
    fig, ax = plt.subplots(figsize=(4.6, 6.2))
    im = ax.imshow(M, cmap=fs.SEQ.reversed(), vmin=1, vmax=D, aspect="auto")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            ax.text(j, i, int(M[i, j]), ha="center", va="center", fontsize=6.2,
                    color="white" if M[i, j] <= 12 else fs.INK)
    ax.set_xticks(range(len(SELS)))
    ax.set_xticklabels([fs.SELECTOR_LABELS[s] for s in SELS])
    ax.xaxis.tick_top()
    ax.set_yticks(range(len(rk)))
    ax.set_yticklabels(rk["label"], fontsize=6.4)
    for t, fam in zip(ax.get_yticklabels(), rk["family"]):
        t.set_color(fs.FAMILY_COLORS[fam])
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.05, pad=0.03)
    cb.set_label("Rank (1 = most relevant)", fontsize=7)
    fs.save(fig, OUT / FIGURES["D1"]["file"])
    MAN["fig_D1"] = {s: {f: int(r) for f, r in zip(rk["feature"], rk[f"{s}_rank"])} for s in SELS}


# ============================================================================ Figure 5 AUC vs k
def fig_5_auc_vs_k():
    g = store.load_table("subset_summary")
    ks = store.load_table("kstar")
    fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.9), sharey=True)
    man = {}
    for ax, m, L in zip(axs, SUBM, "abc"):
        full = g[(g.model == m) & (g.k == D)]["AUC"].iloc[0]
        ax.axhspan(full - CFG["selection"]["margin"], full, color="#f0efec", zorder=0)
        ax.axhline(full, color=fs.INK2, lw=0.8, ls="--")
        for s in SELS:
            d = g[(g.model == m) & (g.selector == s)].sort_values("k")
            ax.fill_between(d["k"], d["AUC_lo"], d["AUC_hi"], color=fs.SELECTOR_COLORS[s], alpha=0.06, lw=0)
            ax.plot(d["k"], d["AUC"], color=fs.SELECTOR_COLORS[s], marker=fs.SELECTOR_MARKERS[s], ms=3, lw=1.3,
                    label=fs.SELECTOR_LABELS[s])
            kn = int(ks[(ks.model == m) & (ks.selector == s)]["k_ni"].iloc[0])
            v = d[d.k == kn]["AUC"].iloc[0]
            ax.plot(kn, v, marker="*", ms=10, color=fs.SELECTOR_COLORS[s], mec="white", mew=0.6, zorder=5)
            man[f"{m}|{s}"] = {"k_ni": kn, "auc_k_ni": round(float(v), 4), "full": round(float(full), 4)}
        ax.set_xscale("log")
        ax.set_xticks([1, 2, 3, 5, 10, 20, 30])
        ax.set_xticklabels(["1", "2", "3", "5", "10", "20", "30"])
        ax.set_xlabel("Number of features k")
        ax.set_title(f"({L}) {CFG['models'][m]['label']}", loc="left", fontsize=8.2)
        ax.set_ylim(0.90, 1.0)
    axs[0].set_ylabel("Mean test-fold AUC (95% CI)")
    axs[0].legend(loc="lower right", fontsize=6)
    fig.tight_layout()
    fs.save(fig, OUT / FIGURES["5"]["file"])
    MAN["fig_5"] = man


# ============================================================================ Figure 4 stability
def fig_4_stability():
    st = store.load_table("stability")
    fq = store.load_table("selection_frequency")
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.6), gridspec_kw={"width_ratios": [1, 1.15]})
    ax = axs[0]
    man = {}
    for s in SELS:
        d = st[st.selector == s].sort_values("k")
        ax.plot(d["k"], d["nogueira"], color=fs.SELECTOR_COLORS[s], marker=fs.SELECTOR_MARKERS[s], ms=3.5,
                label=fs.SELECTOR_LABELS[s])
        man[s] = {int(k): round(float(v), 3) for k, v in zip(d["k"], d["nogueira"])}
    for thr, txt in [(0.75, "excellent"), (0.4, "intermediate")]:
        ax.axhline(thr, color=fs.INK2, lw=0.7, ls=":")
        ax.text(26, thr + 0.012, txt, fontsize=6, color=fs.INK2, ha="right")
    ax.set_xscale("log")
    ax.set_xticks([1, 2, 3, 5, 10, 25])
    ax.set_xticklabels(["1", "2", "3", "5", "10", "25"])
    ax.set_xlabel("Number of features k")
    ax.set_ylabel("Nogueira stability index (100 folds)")
    ax.set_ylim(0, 1.02)
    ax.legend(loc="lower right", fontsize=6.5)
    fs.panel(ax, "a")
    ax = axs[1]
    k5 = fq[fq.k == 5].pivot(index="feature", columns="selector", values="freq")[SELS]
    k5 = k5[(k5 > 0).any(axis=1)]
    k5 = k5.loc[k5.mean(axis=1).sort_values(ascending=False).index]
    im = ax.imshow(k5.to_numpy(), cmap=fs.SEQ, vmin=0, vmax=1, aspect="auto")
    for i in range(k5.shape[0]):
        for j in range(k5.shape[1]):
            v = k5.iloc[i, j]
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=6, color="white" if v > 0.6 else fs.INK)
    ax.set_xticks(range(len(SELS)))
    ax.set_xticklabels([fs.SELECTOR_LABELS[s] for s in SELS], fontsize=6.8)
    ax.set_yticks(range(k5.shape[0]))
    ax.set_yticklabels([data.pretty(f) for f in k5.index], fontsize=6.4)
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.05, pad=0.03)
    cb.set_label("Selection frequency at k = 5", fontsize=7)
    fs.panel(ax, "b")
    fig.tight_layout()
    fs.save(fig, OUT / FIGURES["4"]["file"])
    MAN["fig_4"] = {"nogueira": man, "freq_k5": {s: {f: round(float(v), 2) for f, v in k5[s].items()} for s in SELS}}


# ============================================================================ Figure 6 calibration + DCA
def fig_6_calibration_dca():
    rel = store.load_arrays("reliability")
    cal = store.load_table("calibration").set_index("model")
    dca = store.load_table("dca")
    order = MODEL_ORDER + ["LR5", "LRc"]
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.6))
    ax = axs[0]
    ax.plot([0, 1], [0, 1], color=fs.INK2, lw=0.8, ls=":")
    for m in order:
        mp, ob, nn = rel[m]
        ax.plot(mp, ob, color=fs.MODEL_COLORS[m], ls=fs.MODEL_LINES[m], marker=fs.MODEL_MARKERS[m], ms=3.2, lw=1.2,
                label=f"{LBL[m]}: slope {cal.loc[m, 'Slope']:.2f}")
    ax.set_xlabel("Mean predicted probability (decile)")
    ax.set_ylabel("Observed proportion malignant")
    ax.legend(loc="lower right", fontsize=5.8)
    fs.panel(ax, "a")
    ax = axs[1]
    for m in order + ["TreatAll", "TreatNone"]:
        d = dca[dca.model == m]
        lab = {"TreatAll": "Biopsy all", "TreatNone": "Biopsy none"}.get(m, LBL.get(m, m))
        ax.plot(d["threshold"], d["nb"], color=fs.MODEL_COLORS[m], ls=fs.MODEL_LINES.get(m, "-"),
                lw=1.0 if m.startswith("Treat") else 1.3, label=lab)
    ax.set_ylim(-0.05, y.mean() + 0.03)
    ax.set_xlim(0, CFG["evaluation"]["dca_thresholds"][1])
    ax.set_xlabel("Threshold probability")
    ax.set_ylabel("Net benefit")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.17), fontsize=5.8, ncol=3)
    fs.panel(ax, "b")
    fig.tight_layout()
    fs.save(fig, OUT / FIGURES["6"]["file"])
    MAN["fig_6"] = {m: round(float(cal.loc[m, "Slope"]), 2) for m in order}


# ============================================================================ Figure 7 compact models
def fig_7_compact_models():
    fig = plt.figure(figsize=(7.2, 5.6))
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.35], width_ratios=[1, 1])
    man = {}
    for (tag, pos, L) in [("LR5", gs[0, 0], "a"), ("LRc", gs[:, 1], "b")]:
        ax = fig.add_subplot(pos)
        coef = store.load_table(f"compact_coefficients_{tag}").iloc[1:].sort_values("OR_per_SD").reset_index(drop=True)
        yy = np.arange(len(coef))
        ax.hlines(yy, coef["OR_lo"], coef["OR_hi"], color=fs.MODEL_COLORS[tag], lw=2)
        ax.plot(coef["OR_per_SD"], yy, fs.MODEL_MARKERS[tag], color=fs.MODEL_COLORS[tag], ms=6, mec="white")
        ax.axvline(1, color=fs.INK2, lw=0.8, ls=":")
        ax.set_xscale("log")
        tk = [t for t in (0.1, 0.2, 0.5, 1, 2, 5, 10, 20) if coef["OR_lo"].min() * 0.8 <= t <= coef["OR_hi"].max() * 1.25]
        ax.set_xticks(tk)
        ax.set_xticklabels([f"{t:g}" for t in tk])
        ax.xaxis.set_minor_formatter(plt.NullFormatter())
        ax.set_yticks(yy)
        ax.set_yticklabels(coef["label"], fontsize=6.6)
        ax.set_xlabel("Odds ratio per SD (95% bootstrap CI)")
        ax.set_title(f"({L}) {LBL[tag]}", loc="left", fontsize=8.2)
        man[tag] = {r.term: round(float(r.OR_per_SD), 3) for r in coef.itertuples()}
    ax = fig.add_subplot(gs[1, 0])
    bf = store.load_table("bootstrap_selection_frequency")
    piv = bf.pivot(index="feature", columns="spec", values="freq")[["LR5", "LRc"]]
    piv = piv[(piv > 0).any(axis=1)].sort_values(["LR5", "LRc"])
    yy = np.arange(len(piv))
    ax.barh(yy + 0.2, piv["LR5"], height=0.38, color=fs.MODEL_COLORS["LR5"], label=LBL["LR5"])
    ax.barh(yy - 0.2, piv["LRc"], height=0.38, color=fs.MODEL_COLORS["LRc"], label=LBL["LRc"])
    ax.axvline(0.8, color=fs.INK2, lw=0.8, ls=":")
    ax.set_yticks(yy)
    ax.set_yticklabels([data.pretty(f) for f in piv.index], fontsize=5.6)
    ax.set_xlabel(f"Bootstrap selection frequency ({CFG['evaluation']['optimism_bootstrap']} resamples)")
    ax.set_xlim(0, 1.0)
    ax.legend(loc="lower right", fontsize=6)
    ax.set_title("(c) Selection frequency", loc="left", fontsize=8.2)
    fig.tight_layout()
    fs.save(fig, OUT / FIGURES["7"]["file"])
    MAN["fig_7"] = man


# ============================================================================ Figure 8 optimism
def fig_8_optimism():
    op = store.load_table("optimism")
    fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.8), sharey=True)
    man = {}
    for ax, m, L in zip(axs, SUBM, "abc"):
        for s in SELS:
            d = op[(op.model == m) & (op.selector == s)].sort_values("k")
            ax.fill_between(d["k"], d["opt_lo"], d["opt_hi"], color=fs.SELECTOR_COLORS[s], alpha=0.12, lw=0)
            ax.plot(d["k"], d["optimism"], color=fs.SELECTOR_COLORS[s], marker=fs.SELECTOR_MARKERS[s], ms=3,
                    label=fs.SELECTOR_LABELS[s], lw=1.3)
            man[f"{m}|{s}"] = {int(k): round(float(v), 4) for k, v in zip(d["k"], d["optimism"])}
        ax.axhline(0, color=fs.INK2, lw=0.8)
        ax.set_xscale("log")
        ax.set_xticks([1, 2, 3, 5, 10, 20])
        ax.set_xticklabels(["1", "2", "3", "5", "10", "20"])
        ax.set_xlabel("Number of features k")
        ax.set_title(f"({L}) {CFG['models'][m]['label']}", loc="left", fontsize=8.2)
    axs[0].set_ylabel("AUC optimism (leaky - leakage-free)")
    axs[0].legend(loc="upper right", fontsize=6)
    fig.tight_layout()
    fs.save(fig, OUT / FIGURES["8"]["file"])
    MAN["fig_8"] = man


# ============================================================================ Supplementary figures
def fig_A1_distributions():
    top = store.load_table("rankings_full")["feature"].head(6).tolist()
    Z = (X - X.mean()) / X.std(ddof=1)
    fig, axs = plt.subplots(2, 3, figsize=(7.2, 4.2))
    for ax, f in zip(axs.ravel(), top):
        vals = [Z.loc[y == 0, f], Z.loc[y == 1, f]]
        parts = ax.violinplot(vals, positions=[0, 1], showmedians=True, widths=0.8)
        for pc, c in zip(parts["bodies"], [fs.CLASS_COLORS["Benign"], fs.CLASS_COLORS["Malignant"]]):
            pc.set_facecolor(c)
            pc.set_edgecolor(c)
            pc.set_alpha(0.45)
        for key in ("cmedians", "cmins", "cmaxes", "cbars"):
            parts[key].set_color(fs.INK2)
            parts[key].set_linewidth(0.8)
        ax.set_xticks([0, 1])
        ax.set_xticklabels(["Benign", "Malignant"])
        ax.set_title(data.pretty(f), fontsize=7.6, loc="left")
        ax.set_ylabel("z-score", fontsize=7)
    fig.tight_layout()
    fs.save(fig, OUT / FIGURES["A1"]["file"])
    MAN["fig_A1"] = {"features": top}


def fig_C2_confusion():
    op = store.load_table("pooled_operating").set_index("model")
    order = MODEL_ORDER + ["LR5", "LRc"]
    fig, axs = plt.subplots(2, 4, figsize=(7.4, 4.0))
    axs.ravel()[-1].axis("off")
    man = {}
    for ax, m in zip(axs.ravel(), order):
        r = op.loc[m]
        M = np.array([[r.TP, r.FN], [r.FP, r.TN]])
        rowp = M / M.sum(1, keepdims=True)
        ax.imshow(rowp, cmap=fs.SEQ, vmin=0, vmax=1)
        for i in range(2):
            for j in range(2):
                ax.text(j, i, f"{int(M[i, j])}\n({rowp[i, j]:.1%})", ha="center", va="center", fontsize=6.6,
                        color="white" if rowp[i, j] > 0.6 else fs.INK)
        ax.set_xticks([0, 1])
        ax.set_xticklabels(["Pred. M", "Pred. B"], fontsize=6.3)
        ax.set_yticks([0, 1])
        ax.set_yticklabels(["Malignant", "Benign"], fontsize=6.3)
        ax.grid(False)
        ax.set_title(LBL[m], fontsize=7.4, loc="left")
        man[m] = M.astype(int).tolist()
    fig.tight_layout()
    fs.save(fig, OUT / FIGURES["C2"]["file"])
    MAN["fig_C2"] = man


def fig_E1_learning():
    lc = store.load_table("learning_curve")
    fig, ax = plt.subplots(figsize=(4.8, 3.1))
    man = {}
    for m in ["LR", "RF", "GBT", "LR5", "LRc"]:
        d = lc[lc.model == m].sort_values("n_train")
        ax.fill_between(d["n_train"], d["AUC"] - d["AUC_sd"], np.minimum(d["AUC"] + d["AUC_sd"], 1),
                        color=fs.MODEL_COLORS[m], alpha=0.05, lw=0)
        ax.plot(d["n_train"], d["AUC"], color=fs.MODEL_COLORS[m], marker=fs.MODEL_MARKERS[m], ms=3.5,
                ls=fs.MODEL_LINES[m], label=LBL[m])
        man[m] = {int(round(n)): round(float(a), 4) for n, a in zip(d["n_train"], d["AUC"])}
    ax.set_xlabel("Training cases")
    ax.set_ylabel("Mean test-fold AUC (± 1 SD)")
    ax.legend(loc="lower right", fontsize=6.5)
    fs.save(fig, OUT / FIGURES["E1"]["file"])
    MAN["fig_E1"] = man


def fig_E2_shap():
    sh = store.load_arrays("shap")
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.6), sharex=False)
    man = {}
    for ax, m, L in zip(axs, ["LR", "GBT"], "ab"):
        sv, Z = sh[m], sh["Z"]
        imp = np.abs(sv).mean(0)
        top = np.argsort(-imp)[:10][::-1]
        for i, j in enumerate(top):
            jit = np.random.default_rng(j).uniform(-0.28, 0.28, len(y))
            sc = ax.scatter(sv[:, j], i + jit, c=np.clip(Z[:, j], -2.5, 2.5), cmap=fs.DIV, s=3, lw=0, vmin=-2.5, vmax=2.5)
        ax.axvline(0, color=fs.INK2, lw=0.7)
        ax.set_yticks(range(len(top)))
        ax.set_yticklabels([data.pretty(feats[j]) for j in top], fontsize=6.4)
        ax.set_xlabel("SHAP value (log-odds)")
        ax.set_title(f"({L}) {CFG['models'][m]['label']}", loc="left", fontsize=8.2)
        man[m] = [feats[j] for j in top[::-1][:5]]
    fig.subplots_adjust(wspace=0.75)
    cb = fig.colorbar(sc, ax=axs, fraction=0.025, pad=0.02)
    cb.set_label("Feature value (z-score)", fontsize=7)
    fs.save(fig, OUT / FIGURES["E2"]["file"])
    MAN["fig_E2"] = man


def fig_E3_permutation():
    pim = store.load_table("permutation_importance")
    piv = pim.pivot(index="feature", columns="model", values="importance")[SUBM]
    sdv = pim.pivot(index="feature", columns="model", values="sd")[SUBM]
    top = piv.max(axis=1).sort_values(ascending=False).head(12).index[::-1]
    fig, ax = plt.subplots(figsize=(5.6, 4.2))
    h = 0.26
    for i, m in enumerate(SUBM):
        ax.barh(np.arange(len(top)) + (i - 1) * h, piv.loc[top, m], xerr=sdv.loc[top, m] / np.sqrt(10), height=h,
                color=fs.MODEL_COLORS[m], label=LBL[m], error_kw=dict(lw=0.6, ecolor=fs.INK2))
    ax.set_yticks(range(len(top)))
    ax.set_yticklabels([data.pretty(f) for f in top], fontsize=6.6)
    ax.axvline(0, color=fs.INK2, lw=0.7)
    ax.set_xlabel("Mean drop in test-fold AUC when permuted")
    ax.legend(loc="lower right", fontsize=6.5)
    fs.save(fig, OUT / FIGURES["E3"]["file"])
    MAN["fig_E3"] = {m: piv[m].sort_values(ascending=False).head(5).index.tolist() for m in SUBM}


def fig_D2_rfe():
    rf = store.load_table("rfe_frequency")
    piv = rf.pivot(index="feature", columns="model", values="freq")[SUBM]
    piv = piv[(piv > 0).any(axis=1)]
    piv = piv.loc[piv.mean(axis=1).sort_values(ascending=False).index]
    fig, ax = plt.subplots(figsize=(4.4, max(2.6, 0.2 * len(piv) + 0.8)))
    im = ax.imshow(piv.to_numpy(), cmap=fs.SEQ, vmin=0, vmax=1, aspect="auto")
    for i in range(piv.shape[0]):
        for j in range(piv.shape[1]):
            v = piv.iloc[i, j]
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=6, color="white" if v > 0.6 else fs.INK)
    ax.set_xticks(range(len(SUBM)))
    ax.set_xticklabels([LBL[m] for m in SUBM], fontsize=6.8)
    ax.set_yticks(range(len(piv)))
    ax.set_yticklabels([data.pretty(f) for f in piv.index], fontsize=6.4)
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.06, pad=0.03)
    cb.set_label("RFE selection frequency (k = 5)", fontsize=7)
    fs.save(fig, OUT / FIGURES["D2"]["file"])
    MAN["fig_D2"] = {m: {f: round(float(v), 2) for f, v in piv[m].items()} for m in SUBM}


def fig_F1_sensitivity():
    s = store.load_table("sensitivity")
    main = store.load_table("main_summary")
    rows = []
    for m in ["LR", "RF", "GBT"]:
        g = main[(main.model == m) & (main.metric == "AUC")].iloc[0]
        rows.append(("Primary analysis", m, g["mean"], g["lo"], g["hi"]))
    for r in s.itertuples():
        rows.append((r.analysis.split(" ", 1)[1], r.model, r.AUC, r.AUC_lo, r.AUC_hi))
    df = pd.DataFrame(rows, columns=["analysis", "model", "auc", "lo", "hi"])
    labels = list(dict.fromkeys(df["analysis"]))
    fig, ax = plt.subplots(figsize=(6.2, 4.4))
    off = {"LR": 0.22, "RF": 0.0, "GBT": -0.22}
    man = {}
    for i, a in enumerate(labels):
        yy = len(labels) - i
        for r in df[df.analysis == a].itertuples():
            ax.hlines(yy + off[r.model], r.lo, r.hi, color=fs.MODEL_COLORS[r.model], lw=1.6)
            ax.plot(r.auc, yy + off[r.model], fs.MODEL_MARKERS[r.model], color=fs.MODEL_COLORS[r.model], ms=4)
            man[f"{a}|{r.model}"] = round(float(r.auc), 4)
    ax.set_yticks(range(len(labels), 0, -1))
    ax.set_yticklabels(labels, fontsize=6.6)
    for m in ["LR", "RF", "GBT"]:
        ax.plot([], [], fs.MODEL_MARKERS[m] + "-", color=fs.MODEL_COLORS[m], label=LBL[m])
    ax.legend(loc="lower left", fontsize=6.5)
    ax.set_xlabel("Mean test-fold AUC (corrected 95% CI)")
    fs.save(fig, OUT / FIGURES["F1"]["file"])
    MAN["fig_F1"] = man


def fig_C3_misclassification():
    mis = store.load_table("misclassification_overlap")
    fig, ax = plt.subplots(figsize=(4.6, 2.8))
    x = mis["n_models_wrong"].to_numpy()
    ax.bar(x[1:] - 0.18, mis["n_malignant"][1:], width=0.36, color=fs.CLASS_COLORS["Malignant"], label="Malignant (missed)")
    ax.bar(x[1:] + 0.18, mis["n_benign"][1:], width=0.36, color=fs.CLASS_COLORS["Benign"], label="Benign (false alarm)")
    for xi, a, b in zip(x[1:], mis["n_malignant"][1:], mis["n_benign"][1:]):
        ax.text(xi - 0.18, a + 0.15, int(a), ha="center", fontsize=6.5, color=fs.INK)
        ax.text(xi + 0.18, b + 0.15, int(b), ha="center", fontsize=6.5, color=fs.INK)
    ax.set_xticks(x[1:])
    ax.set_xlabel("Number of the five classifiers that misclassify the case")
    ax.set_ylabel("Cases")
    ax.legend(fontsize=6.5)
    fs.save(fig, OUT / FIGURES["C3"]["file"])
    MAN["fig_C3"] = mis.to_dict(orient="list")


def fig_F2_reconciliation():
    rec = store.load_table("reconciliation")
    srcs = ["RapidMiner 7.1 (.per)", "Python analogue of antecedent configuration", "This study (10 × 10 CV)"]
    short = {srcs[0]: "RapidMiner 7.1", srcs[1]: "Python analogue", srcs[2]: "This study"}
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.9), sharey=False)
    cols = {srcs[0]: "#86b6ef", srcs[1]: "#2a78d6", srcs[2]: "#0d366b"}
    man = {}
    for ax, met, L in zip(axs, ["Sensitivity", "AUC"], "ab"):
        for i, src in enumerate(srcs):
            d = rec[rec.source == src].set_index("model")
            ms = [m for m in ["LR", "RF", "ADA"] if m in d.index]
            xs = np.arange(len(ms)) + (i - 1) * 0.26
            ax.bar(xs, d.loc[ms, met], width=0.26, color=cols[src], label=short[src])
            man[f"{src}|{met}"] = {m: round(float(d.loc[m, met]), 4) for m in ms}
        ax.set_xticks(range(3))
        ax.set_xticklabels(["LR", "RF", "AdaBoost"])
        ax.set_ylim(0.8 if met == "Sensitivity" else 0.9, 1.0)
        ax.set_ylabel(("Sensitivity for malignancy" if met == "Sensitivity" else "AUC"))
        fs.panel(ax, L)
    fig.legend(*axs[0].get_legend_handles_labels(), loc="upper center", ncol=3, fontsize=6.5, bbox_to_anchor=(0.5, 1.06))
    fig.tight_layout()
    fs.save(fig, OUT / FIGURES["F2"]["file"])
    MAN["fig_F2"] = man


if __name__ == "__main__":
    with Timer("15 figures"):
        for fn in [fig_1_workflow, fig_2_structure, fig_3_roc_pr, fig_4_stability, fig_5_auc_vs_k, fig_6_calibration_dca,
                   fig_7_compact_models, fig_8_optimism, fig_A1_distributions, fig_C1_fold_forest, fig_C2_confusion,
                   fig_C3_misclassification, fig_D1_rankings, fig_D2_rfe, fig_E1_learning, fig_E2_shap, fig_E3_permutation,
                   fig_F1_sensitivity, fig_F2_reconciliation]:
            fn()
            print("  ", fn.__name__, flush=True)
        (OUT / "manifest.json").write_text(json.dumps(MAN, indent=1, default=str), encoding="utf-8")
