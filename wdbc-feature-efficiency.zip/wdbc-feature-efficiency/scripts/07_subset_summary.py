"""Stage 07 — summarise stages 05, 06 and 08: minimal sufficient subsets (RQ2), selector
comparison (RQ1), model dependence of the optimal subset (RQ3), selection stability
and selection optimism."""
from collections import Counter
from itertools import combinations

import numpy as np
import pandas as pd

from _common import CFG, Timer
from wdbcfs import data, metrics, store

X, y, feats = data.load(CFG)
D = len(feats)
SELS = CFG["selection"]["selectors"]
MODELS = CFG["selection"]["subset_models"]
KGRID = CFG["selection"]["k_grid"]
MARGIN = CFG["selection"]["margin"]
MET = ["AUC", "Accuracy", "Sensitivity", "Specificity", "F1", "MCC", "Brier"]


def paired(a: pd.DataFrame, b: pd.DataFrame, col="AUC"):
    a = a.sort_values(["repeat", "fold"])
    b = b.sort_values(["repeat", "fold"])
    assert (a[["repeat", "fold"]].to_numpy() == b[["repeat", "fold"]].to_numpy()).all()
    n_tr, n_te = a["n_train"].mean(), a["n_test"].mean()
    return metrics.corrected_t(a[col].to_numpy() - b[col].to_numpy(), n_tr, n_te)


with Timer("07 subset summary"):
    sf = store.load_table("subset_folds")
    n_tr, n_te = sf["n_train"].mean(), sf["n_test"].mean()

    # ------------------------------------------------------------ grid summary + delta vs k = 30
    rows = []
    for (m, s, k), d in sf.groupby(["model", "selector", "k"]):
        row = {"model": m, "selector": s, "k": k}
        for met in MET:
            ci = metrics.corrected_t(d[met].to_numpy(), n_tr, n_te, bounds=(-1, 1) if met == "MCC" else (0, 1))
            row.update({met: ci["mean"], f"{met}_sd": ci["sd"], f"{met}_lo": ci["lo"], f"{met}_hi": ci["hi"]})
        full = sf[(sf.model == m) & (sf.selector == s) & (sf.k == D)]
        dd = paired(d, full)
        row.update(dAUC=dd["mean"], dAUC_lo=dd["lo"], dAUC_hi=dd["hi"], dAUC_p=dd["p"])
        rows.append(row)
    grid = pd.DataFrame(rows).sort_values(["model", "selector", "k"]).reset_index(drop=True)
    store.save_table("subset_summary", grid)

    # ------------------------------------------------------------ RQ2: minimal sufficient subset
    ks = []
    for (m, s), g in grid.groupby(["model", "selector"]):
        g = g.sort_values("k")
        kp = int(g[g["dAUC"] >= -MARGIN]["k"].min())
        kn = int(g[g["dAUC_lo"] >= -MARGIN]["k"].min())
        rp, rn = g[g.k == kp].iloc[0], g[g.k == kn].iloc[0]
        ks.append({"model": m, "selector": s, "k_point": kp, "k_ni": kn,
                   "AUC_full": float(g[g.k == D]["AUC"].iloc[0]),
                   "AUC_point": rp["AUC"], "dAUC_point": rp["dAUC"], "dAUC_point_lo": rp["dAUC_lo"],
                   "dAUC_point_hi": rp["dAUC_hi"],
                   "AUC_ni": rn["AUC"], "AUC_ni_lo": rn["AUC_lo"], "AUC_ni_hi": rn["AUC_hi"],
                   "dAUC_ni": rn["dAUC"], "dAUC_ni_lo": rn["dAUC_lo"], "dAUC_ni_hi": rn["dAUC_hi"],
                   "Accuracy_ni": rn["Accuracy"], "Sensitivity_ni": rn["Sensitivity"],
                   "Specificity_ni": rn["Specificity"]})
    kstar = pd.DataFrame(ks)
    store.save_table("kstar", kstar)

    # ------------------------------------------------------------ stability of fold-internal rankings
    fr = store.load_arrays("fold_rankings")
    orders = fr["orders"]                       # (folds, selectors, D)
    stab, freq_rows, modal = [], [], {}
    for si, s in enumerate(SELS):
        for k in KGRID:
            if k == D:
                continue
            Z = np.zeros((orders.shape[0], D))
            sets = []
            for i in range(orders.shape[0]):
                sel = orders[i, si, :k]
                Z[i, sel] = 1
                sets.append(tuple(sorted(sel)))
            cnt = Counter(sets)
            top, n_top = cnt.most_common(1)[0]
            stab.append({"selector": s, "k": k, "nogueira": metrics.nogueira(Z),
                         "jaccard": metrics.mean_pairwise_jaccard(sets), "n_distinct": len(cnt),
                         "modal_freq": n_top / len(sets),
                         "modal_subset": "|".join(feats[j] for j in top)})
            for j in range(D):
                freq_rows.append({"selector": s, "k": k, "feature": feats[j], "freq": Z[:, j].mean()})
    stab = pd.DataFrame(stab)
    store.save_table("stability", stab)
    store.save_table("selection_frequency", pd.DataFrame(freq_rows))

    # ------------------------------------------------------------ RQ1: selector comparison at fixed k
    comp = []
    for m in MODELS:
        for k in (3, 5, 10):
            for a, b in combinations(SELS, 2):
                da = sf[(sf.model == m) & (sf.selector == a) & (sf.k == k)]
                db = sf[(sf.model == m) & (sf.selector == b) & (sf.k == k)]
                c = paired(da, db)
                ca = paired(da, db, "Accuracy")
                comp.append({"model": m, "k": k, "a": a, "b": b, "dAUC": c["mean"], "dAUC_lo": c["lo"],
                             "dAUC_hi": c["hi"], "p": c["p"], "dAcc": ca["mean"], "dAcc_p": ca["p"]})
    comp = pd.DataFrame(comp)
    comp["p_holm"] = metrics.holm(comp["p"].to_numpy())
    comp["dAcc_p_holm"] = metrics.holm(comp["dAcc_p"].to_numpy())
    store.save_table("selector_compare", comp)
    # mean AUC over k = 1..10 (area under the low-k curve, fold-paired)
    auk = (sf[sf.k <= 10].groupby(["model", "selector", "repeat", "fold"])["AUC"].mean()
           .groupby(["model", "selector"]).mean().reset_index().rename(columns={"AUC": "AUC_k1_10"}))
    store.save_table("selector_auk", auk)

    # ------------------------------------------------------------ RQ3: model-specific RFE subsets
    rf = store.load_table("rfe_folds")
    rfe_rows, rfe_freq, rfe_modal = [], [], {}
    sf50 = sf[sf["repeat"] < CFG["selection"]["rfe_repeats"]]
    for m in MODELS:
        d = rf[rf.model == m]
        sets = [tuple(s.split("|")) for s in d["subset"]]
        cnt = Counter(sets)
        top, n_top = cnt.most_common(1)[0]
        rfe_modal[m] = list(top)
        Z = np.array([[f in s for f in feats] for s in sets], float)
        n_tr50, n_te50 = sf50["n_train"].mean(), sf50["n_test"].mean()
        auc = metrics.corrected_t(d["AUC"].to_numpy(), n_tr50, n_te50, bounds=(0, 1))
        # same folds, best filter at k = 5 for that model
        filt = {s: sf50[(sf50.model == m) & (sf50.selector == s) & (sf50.k == 5)] for s in SELS}
        best_s = max(SELS, key=lambda s: filt[s]["AUC"].mean())
        diff = paired(d, filt[best_s])
        rfe_rows.append({"model": m, "AUC": auc["mean"], "AUC_lo": auc["lo"], "AUC_hi": auc["hi"],
                         "Accuracy": d["Accuracy"].mean(), "Sensitivity": d["Sensitivity"].mean(),
                         "Specificity": d["Specificity"].mean(),
                         "nogueira": metrics.nogueira(Z), "n_distinct": len(cnt), "modal_freq": n_top / len(sets),
                         "modal_subset": "|".join(top), "best_filter": best_s,
                         "dAUC_vs_filter": diff["mean"], "dAUC_vs_filter_lo": diff["lo"],
                         "dAUC_vs_filter_hi": diff["hi"], "dAUC_vs_filter_p": diff["p"]})
        for j, f in enumerate(feats):
            rfe_freq.append({"model": m, "feature": f, "freq": Z[:, j].mean()})
    rfe_sum = pd.DataFrame(rfe_rows)
    store.save_table("rfe_summary", rfe_sum)
    store.save_table("rfe_frequency", pd.DataFrame(rfe_freq))
    rfe_j = {f"{a}-{b}": metrics.jaccard(rfe_modal[a], rfe_modal[b]) for a, b in combinations(MODELS, 2)}

    # ------------------------------------------------------------ selection optimism (leaky - free)
    lf = store.load_table("leaky_folds")
    opt = []
    for (m, s, k), d in lf.groupby(["model", "selector", "k"]):
        free = sf[(sf.model == m) & (sf.selector == s) & (sf.k == k)]
        c = paired(d, free)
        opt.append({"model": m, "selector": s, "k": k, "AUC_leaky": d["AUC"].mean(), "AUC_free": free["AUC"].mean(),
                    "Acc_leaky": d["Accuracy"].mean(), "Acc_free": free["Accuracy"].mean(),
                    "optimism": c["mean"], "opt_lo": c["lo"], "opt_hi": c["hi"], "opt_p": c["p"]})
    opt = pd.DataFrame(opt)
    store.save_table("optimism", opt)

    # ------------------------------------------------------------ compact LR specifications
    # Two specifications, both fixed by rule rather than by test-fold performance:
    #  LRc  non-inferior model: smallest k meeting the CI rule for logistic regression;
    #       ties between selectors broken by higher Nogueira stability at that k, then by
    #       the selector order in the configuration file.
    #  LR5  five-feature model: the subset size reported by the antecedent study, using
    #       the selector whose fold-internal top-5 subset is most stable.
    def stab_at(s, k):
        return float(stab[(stab.selector == s) & (stab.k == k)]["nogueira"].iloc[0]) if k < D else 1.0

    def spec(sel, k):
        out = {"selector": sel, "k": int(k), "stability": stab_at(sel, k)}
        if k < D:
            srow = stab[(stab.selector == sel) & (stab.k == k)].iloc[0]
            out["modal_subset"] = srow["modal_subset"].split("|")
            out["modal_freq"] = float(srow["modal_freq"])
        full_rank = store.load_table("rankings_full").sort_values(f"{sel}_rank")
        out["full_sample_subset"] = full_rank["feature"].head(int(k)).tolist()
        return out

    lr = kstar[kstar.model == "LR"].copy()
    lr["stab"] = [stab_at(r.selector, r.k_ni) for r in lr.itertuples()]
    lr["order"] = [SELS.index(x) for x in lr["selector"]]      # final tie-break: configuration order
    pick = lr.sort_values(["k_ni", "stab", "order"], ascending=[True, False, True]).iloc[0]
    compact = spec(pick["selector"], pick["k_ni"])
    g5 = grid[(grid.model == "LR") & (grid.k == 5)].set_index("selector")
    s5 = max(SELS, key=lambda s: (stab_at(s, 5), -SELS.index(s)))
    five = spec(s5, 5)

    # ------------------------------------------------------------ estimates
    est = {
        "margin": MARGIN, "compact": compact, "five": five,
        "kstar": {f"{r.model}|{r.selector}": {"k_point": r.k_point, "k_ni": r.k_ni, "AUC_ni": r.AUC_ni,
                                              "dAUC_ni": r.dAUC_ni, "dAUC_ni_lo": r.dAUC_ni_lo}
                  for r in kstar.itertuples()},
        "k_ni_min": int(kstar["k_ni"].min()), "k_ni_max": int(kstar["k_ni"].max()),
        "k_point_min": int(kstar["k_point"].min()), "k_point_max": int(kstar["k_point"].max()),
        "stability_k5": {r.selector: {"nogueira": r.nogueira, "jaccard": r.jaccard, "modal_freq": r.modal_freq,
                                      "n_distinct": r.n_distinct}
                         for r in stab[stab.k == 5].itertuples()},
        "rfe": {r.model: {"AUC": r.AUC, "nogueira": r.nogueira, "modal_freq": r.modal_freq,
                          "modal_subset": r.modal_subset} for r in rfe_sum.itertuples()},
        "rfe_modal_jaccard": rfe_j,
        "optimism_max": float(opt["optimism"].max()),
        "optimism_max_at": opt.loc[opt["optimism"].idxmax(), ["model", "selector", "k"]].astype(str).tolist(),
        "n_selector_pairs_sig_holm": int((comp["p_holm"] < 0.05).sum()), "n_selector_pairs": len(comp),
    }
    store.put("subsets", est)
    print(kstar.round(4).to_string())
    print(stab[stab.k.isin([3, 5, 10])].round(3).to_string())
    print(rfe_sum.round(4).to_string())
    print(opt.round(4).to_string())
    print(comp.round(4).to_string())
