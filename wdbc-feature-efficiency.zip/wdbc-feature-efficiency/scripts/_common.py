"""Shared bootstrap for numbered scripts: puts src/ on the import path."""
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from wdbcfs.config import load_config, fingerprint  # noqa: E402

CFG = load_config()
SEED = CFG["study"]["master_seed"]


class Timer:
    def __init__(self, name):
        self.name = name

    def __enter__(self):
        self.t = time.time()
        print(f"[{self.name}] start", flush=True)
        return self

    def __exit__(self, *a):
        print(f"[{self.name}] done in {time.time() - self.t:.1f}s", flush=True)
