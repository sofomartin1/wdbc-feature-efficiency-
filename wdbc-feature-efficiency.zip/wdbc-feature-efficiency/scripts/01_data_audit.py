"""Stage 01 — data audit: integrity, class balance, univariate separation, redundancy."""
import hashlib

import numpy as np
import pandas as pd
from scipy import stats
from scipy.cluster.hierarchy import leaves_list, linkage
from scipy.spatial.distance import squareform
from statsmodels.stats.outliers_influence import variance_inflation_factor

from _common import CFG, ROOT, Timer, fingerprint
from wdbcfs import data, metrics, store

with Timer("01 data audit"):
    X, y, feats = data.load(CFG)
    raw = (ROOT / CFG["data"]["path"]).read_bytes()
    sha = hashlib.sha256(raw.replace(b"\r\n", b"\n")).hexdigest()

    # Agreement with the copy of WDBC distributed with scikit-learn (UCI original).
    from sklearn.datasets import load_breast_cancer
    bc = load_breast_cancer()
    sk_match = bool(np.allclose(X.to_numpy(), bc.data, atol=0, rtol=0)
                    and np.array_equal(y, (bc.target == 0).astype(int)))

    # ---------------------------------------------------------------- per-feature descriptives
    rows = []
    for j, f in enumerate(feats):
        x = X[f].to_numpy()
        x1, x0 = x[y == 1], x[y == 0]
        auc, lo, hi = metrics.delong_ci(y, x)
        u = stats.mannwhitneyu(x1, x0, alternative="two-sided")
        rows.append({
            "feature": f, "label": data.pretty(f), "family": data.feature_family(f),
            "mean_benign": x0.mean(), "sd_benign": x0.std(ddof=1),
            "mean_malignant": x1.mean(), "sd_malignant": x1.std(ddof=1),
            "hedges_g": metrics.hedges_g(x1, x0),
            "auc": auc, "auc_lo": lo, "auc_hi": hi,
            "mw_p": u.pvalue, "skewness": stats.skew(x),
        })
    desc = pd.DataFrame(rows)
    desc["mw_q"] = metrics.bh(desc["mw_p"].to_numpy())
    # AUC orientation: < 0.5 means lower values indicate malignancy
    desc["auc_directional"] = np.maximum(desc["auc"], 1 - desc["auc"])

    # ---------------------------------------------------------------- redundancy
    R = X.corr().to_numpy()
    iu = np.triu_indices(len(feats), 1)
    absr = np.abs(R[iu])
    pairs = pd.DataFrame({"a": np.array(feats)[iu[0]], "b": np.array(feats)[iu[1]], "r": R[iu]})
    pairs["abs_r"] = pairs["r"].abs()
    pairs = pairs.sort_values("abs_r", ascending=False).reset_index(drop=True)
    dist = 1 - np.abs(R)
    np.fill_diagonal(dist, 0)
    order = leaves_list(linkage(squareform(dist, checks=False), method="average"))
    Z = ((X - X.mean()) / X.std(ddof=0)).to_numpy()
    vif = np.array([variance_inflation_factor(Z, j) for j in range(Z.shape[1])])
    desc["vif"] = vif

    store.save_table("feature_descriptives", desc)
    store.save_table("correlation_pairs", pairs)
    store.save_arrays("correlation", R=R, order=order, feats=np.array(feats))

    fam_counts = desc["family"].value_counts().to_dict()
    store.put("data", {
        "n": len(y), "n_malignant": int(y.sum()), "n_benign": int((1 - y).sum()),
        "prevalence": float(y.mean()), "n_features": len(feats),
        "n_family_mean": fam_counts["mean"], "n_family_error": fam_counts["error"],
        "n_family_worst": fam_counts["worst"],
        "missing": int(X.isna().sum().sum()), "duplicates": int(X.assign(y=y).duplicated().sum()),
        "sha256": sha, "sklearn_match": sk_match,
        "n_pairs": int(len(absr)), "n_pairs_r90": int((absr > 0.9).sum()), "n_pairs_r80": int((absr > 0.8).sum()),
        "max_r": float(pairs["abs_r"].iloc[0]), "max_r_pair": [pairs["a"].iloc[0], pairs["b"].iloc[0]],
        "median_abs_r": float(np.median(absr)),
        "vif_median": float(np.median(vif)), "vif_max": float(vif.max()),
        "vif_max_feature": feats[int(vif.argmax())], "n_vif_gt10": int((vif > 10).sum()),
        "n_q05": int((desc["mw_q"] < 0.05).sum()),
        "n_g_large": int((desc["hedges_g"].abs() >= 0.8).sum()),
        "best_univariate": desc.loc[desc["auc_directional"].idxmax(), "feature"],
        "best_univariate_auc": float(desc["auc_directional"].max()),
        "config_fingerprint": fingerprint(CFG),
    })
    print(store.get("data"))
