"""Stage 04 — full-sample feature rankings by the three filter criteria and their agreement.

These full-sample rankings are descriptive only (they reproduce what the antecedent
analysis reported). Every performance estimate for a feature subset comes from the
fold-internal rankings computed in stage 05.
"""
from itertools import combinations

import numpy as np
import pandas as pd
from scipy import stats

from _common import CFG, SEED, Timer
from wdbcfs import data, metrics, store
from wdbcfs.selectors import rank_from_scores, score_features

with Timer("04 rankings"):
    X, y, feats = data.load(CFG)
    sels = CFG["selection"]["selectors"]
    tab = pd.DataFrame({"feature": feats, "label": [data.pretty(f) for f in feats],
                        "family": [data.feature_family(f) for f in feats]})
    ranks = {}
    for s in sels:
        sc = score_features(X.to_numpy(), y, s, SEED, CFG["selection"]["mi_neighbors"])
        order = rank_from_scores(sc)
        r = np.empty(len(feats), int)
        r[order] = np.arange(1, len(feats) + 1)
        tab[f"{s}_score"] = sc
        tab[f"{s}_rank"] = r
        ranks[s] = r
    tab["mean_rank"] = tab[[f"{s}_rank" for s in sels]].mean(axis=1)
    tab = tab.sort_values("mean_rank").reset_index(drop=True)
    store.save_table("rankings_full", tab)

    # agreement between rankers
    M = np.vstack([ranks[s] for s in sels])          # m raters x n items
    m, n = M.shape
    Rj = M.sum(0)
    W = 12 * ((Rj - Rj.mean()) ** 2).sum() / (m ** 2 * (n ** 3 - n))
    chi = m * (n - 1) * W
    pW = stats.chi2.sf(chi, n - 1)
    agree = []
    for a, b in combinations(sels, 2):
        rho, p = stats.spearmanr(ranks[a], ranks[b])
        tau, pt = stats.kendalltau(ranks[a], ranks[b])
        top = {}
        for k in (5, 10):
            sa = set(np.array(feats)[ranks[a] <= k])
            sb = set(np.array(feats)[ranks[b] <= k])
            top[k] = metrics.jaccard(sa, sb)
        agree.append({"a": a, "b": b, "spearman": rho, "spearman_p": p, "kendall": tau, "kendall_p": pt,
                      "jaccard_top5": top[5], "jaccard_top10": top[10]})
    agree = pd.DataFrame(agree)
    store.save_table("ranking_agreement", agree)
    top5 = {s: sorted(np.array(feats)[ranks[s] <= 5].tolist(), key=lambda f: ranks[s][feats.index(f)]) for s in sels}
    store.put("rankings", {
        "kendall_W": W, "kendall_W_chi2": chi, "kendall_W_df": n - 1, "kendall_W_p": pW,
        "top5": top5, "top1": {s: top5[s][0] for s in sels},
        "n_worst_in_top5": {s: int(sum(f.startswith("worst_") for f in top5[s])) for s in sels},
        "common_top5": sorted(set.intersection(*[set(v) for v in top5.values()])),
        "union_top5": sorted(set.union(*[set(v) for v in top5.values()])),
        "spearman_min": float(agree["spearman"].min()), "spearman_max": float(agree["spearman"].max()),
    })
    print(tab.head(12).round(4).to_string())
    print(agree.round(4).to_string())
    print(store.get("rankings"))
