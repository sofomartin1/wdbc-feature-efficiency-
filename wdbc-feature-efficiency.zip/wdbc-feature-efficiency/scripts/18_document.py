"""Stage 18 — reproducibility record (Tables B1, B2) and Word documents of all displays.

Runs only after the consistency gate (stage 17) has passed. It

1. writes Table B1 (computational environment, configuration, resampling settings and run
   time of this run) and Table B2 (outcome of the consistency gate by check family);
2. lays out the display tables (results/display_tables/*.json) and figures
   (results/figures/*.png) with the numbering, order and captions of the article:
     results/manuscript_displays.docx      Tables 1-10 and Figures 1-8
     results/supplementary_displays.docx   Appendices A-F (Tables A1-F4, Figures A1-F2)

Tables use the "Table N: Title" caption and figures the "Figure N. Caption" style of the
article. Table notes are kept in the JSON files; pass --notes to print them as well.
This script performs no computation on analysis results.

    python scripts/18_document.py            # standard build
    python scripts/18_document.py --notes    # also print table and figure notes
"""
import argparse
import json
import os
import platform
import sys
from importlib import import_module

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from _common import CFG, ROOT, fingerprint
from wdbcfs import store

TAB = ROOT / "results" / "display_tables"
FIG = ROOT / "results" / "figures"
OUT_MAIN = ROOT / "results" / "manuscript_displays.docx"
OUT_SUPP = ROOT / "results" / "supplementary_displays.docx"
FONT = "Times New Roman"
TITLE = ("Feature-Efficient Machine-Learning Diagnosis of Breast Tumours: A Leakage-Free, Uncertainty-Aware "
         "Evaluation of Filter Feature Selection on the Wisconsin Diagnostic Dataset")
AUTHORS = "Martin Konadu Boamah, Prince Clement Addo, Maxwell Dorgbefu Jnr"
sys.path.insert(0, str(ROOT / "scripts"))
from display_plan import APPENDICES, FIGURES, MAIN, table_file  # noqa: E402


def set_font(run, size, bold=False, italic=False, color=None):
    run.font.name = FONT
    run._element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def para(doc_or_cell, text="", size=10, bold=False, italic=False, align=None, space_after=4, space_before=0,
         keep_next=False):
    p = doc_or_cell.add_paragraph()
    if text:
        set_font(p.add_run(text), size, bold, italic)
    pf = p.paragraph_format
    pf.space_after = Pt(space_after)
    pf.space_before = Pt(space_before)
    pf.line_spacing = 1.0
    pf.keep_with_next = keep_next
    if align:
        p.alignment = align
    return p


def border(cell, edge, sz=8, val="single"):
    tcPr = cell._tc.get_or_add_tcPr()
    b = tcPr.find(qn("w:tcBorders"))
    if b is None:
        b = OxmlElement("w:tcBorders")
        tcPr.append(b)
    e = OxmlElement(f"w:{edge}")
    e.set(qn("w:val"), val)
    e.set(qn("w:sz"), str(sz))
    e.set(qn("w:space"), "0")
    e.set(qn("w:color"), "000000")
    b.append(e)


def no_table_borders(tbl):
    tblPr = tbl._tbl.tblPr
    b = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{edge}")
        e.set(qn("w:val"), "nil")
        b.append(e)
    tblPr.append(b)


def repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    h = OxmlElement("w:tblHeader")
    h.set(qn("w:val"), "true")
    trPr.append(h)
    cs = OxmlElement("w:cantSplit")
    trPr.append(cs)


def cant_split(row):
    trPr = row._tr.get_or_add_trPr()
    trPr.append(OxmlElement("w:cantSplit"))


def cell_text(cell, text, size=9, bold=False, align=WD_ALIGN_PARAGRAPH.LEFT):
    cell.text = ""
    p = cell.paragraphs[0]
    lines = str(text).split("\n")
    for i, ln in enumerate(lines):
        r = p.add_run(ln)
        set_font(r, size, bold)
        if i < len(lines) - 1:
            r.add_break(WD_BREAK.LINE)
    p.alignment = align
    p.paragraph_format.space_after = Pt(1)
    p.paragraph_format.space_before = Pt(1)
    p.paragraph_format.line_spacing = 1.0


def tiny(paragraph):
    """Make an empty paragraph 1 pt high so it cannot push content onto an extra page."""
    pf = paragraph.paragraph_format
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf.line_spacing = Pt(1)


def new_section(doc, landscape, reuse=False):
    if reuse:                       # first display: lay out the existing first section
        sec = doc.sections[-1]
    else:
        sec = doc.add_section()
        tiny(doc.paragraphs[-1])    # paragraph that carries the section break
    w, h = Inches(8.5), Inches(11)
    if landscape:
        sec.orientation = WD_ORIENT.LANDSCAPE
        sec.page_width, sec.page_height = h, w
    else:
        sec.orientation = WD_ORIENT.PORTRAIT
        sec.page_width, sec.page_height = w, h
    for side in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
        setattr(sec, side, Inches(0.8))
    return sec


def add_table(doc, spec, number, avail_in, notes):
    cap = para(doc, space_after=3, space_before=8, keep_next=True)
    set_font(cap.add_run(f"Table {number}: "), 9, bold=True)
    set_font(cap.add_run(spec["title"]), 9)
    cols = spec["columns"]
    tbl = doc.add_table(rows=1 + len(spec["rows"]), cols=len(cols))
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.autofit = False
    no_table_borders(tbl)
    widths = spec.get("widths")
    if widths:
        scale = avail_in / sum(widths)
        widths = [w * scale for w in widths]
    else:
        first = min(1.9, avail_in * 0.22)
        rest = (avail_in - first) / (len(cols) - 1)
        widths = [first] + [rest] * (len(cols) - 1)
    for j, c in enumerate(cols):
        cell = tbl.rows[0].cells[j]
        cell_text(cell, c, 9, bold=False, align=WD_ALIGN_PARAGRAPH.LEFT if j == 0 else WD_ALIGN_PARAGRAPH.CENTER)
        border(cell, "top", 12)
        border(cell, "bottom", 6)
    repeat_header(tbl.rows[0])
    for i, row in enumerate(spec["rows"], start=1):
        cant_split(tbl.rows[i])
        for j, v in enumerate(row):
            cell_text(tbl.rows[i].cells[j], v, 9, align=WD_ALIGN_PARAGRAPH.LEFT if j == 0 else WD_ALIGN_PARAGRAPH.CENTER)
    for cell in tbl.rows[-1].cells:
        border(cell, "bottom", 12)
    for row in tbl.rows:
        for j, cell in enumerate(row.cells):
            cell.width = Inches(widths[j])
    if notes and spec.get("note"):
        n = para(doc, space_before=3, space_after=10)
        set_font(n.add_run("Note. "), 8, bold=True, italic=True)
        set_font(n.add_run(spec["note"]), 8, italic=True)
    else:
        tiny(para(doc))


def add_figure(doc, fig, number, width_in, notes):
    p = para(doc, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=2, keep_next=True)
    p.add_run().add_picture(str(FIG / fig["file"]), width=Inches(min(width_in, fig.get("width", width_in))))
    cap = para(doc, space_after=8)
    set_font(cap.add_run(f"Figure {number}. "), 9, bold=True)
    set_font(cap.add_run(fig["title"]), 9)
    if notes and fig.get("note"):
        n = para(doc, space_after=10)
        set_font(n.add_run("Note. "), 8, bold=True, italic=True)
        set_font(n.add_run(fig["note"]), 8, italic=True)


# ------------------------------------------------------------------------------------------ Tables B1, B2
def _version(module):
    try:
        return getattr(import_module(module), "__version__", "unknown")
    except ImportError:
        return "not installed"


def _k_set(ks):
    ks = list(ks)
    if len(ks) >= 4 and ks[:10] == list(range(1, 11)):
        return "{1, …, 10, " + ", ".join(str(k) for k in ks[10:]) + "}"
    return "{" + ", ".join(str(k) for k in ks) + "}"


def write_record_tables():
    est = store.load_estimates()
    dd, mn = est["data"], est["main"]
    cv, sel, ev = CFG["cv"], CFG["selection"], CFG["evaluation"]
    seed = CFG["study"]["master_seed"]
    libs = [("numpy", "numpy"), ("pandas", "pandas"), ("scipy", "scipy"), ("scikit-learn", "sklearn"),
            ("statsmodels", "statsmodels"), ("shap", "shap"), ("matplotlib", "matplotlib"), ("joblib", "joblib")]
    lib_txt = f"Python {platform.python_version()}; " + "; ".join(f"{n} {_version(m)}" for n, m in libs)
    machine = {"x86_64": "x86-64", "AMD64": "x86-64", "arm64": "ARM64", "aarch64": "ARM64"}.get(platform.machine(),
                                                                                              platform.machine())
    times_path = ROOT / "results" / "run_times.json"
    if times_path.exists():
        times = json.loads(times_path.read_text(encoding="utf-8"))
        run_txt = f"full pipeline run time {sum(times.values()) / 60:.1f} min"
    else:
        run_txt = "run time not recorded (stages were not run through run_all.py)"
    jobs = os.environ.get("WDBC_JOBS")
    cores = int(jobs) if jobs else (os.cpu_count() or 1)
    n_cols = dd["n_features"] + 1
    ident = "identical to the UCI release" if dd["sklearn_match"] else "NOT identical to the UCI release"
    leaky = [k for k in sel["leaky_k_grid"] if k < dd["n_features"]]
    a, b, _ = ev["dca_thresholds"]
    fr = ev["learning_fractions"]
    if dd["config_fingerprint"] != fingerprint(CFG):
        sys.exit("config/study.yaml changed after stage 01; re-run the pipeline from stage 01")
    rows = [
        ["Language and libraries", lib_txt],
        ["Hardware", f"{platform.system()} {machine}, {cores} CPU cores; {run_txt}"],
        ["Data file", f"{os.path.basename(CFG['data']['path'])}; {dd['n']} × {n_cols}; SHA-256 {dd['sha256'][:16]}…; {ident}"],
        ["Configuration fingerprint", dd["config_fingerprint"]],
        ["Master seed", f"{seed}; fold seed = {seed} + 100 × repeat + fold (both zero-based)"],
        ["Primary resampling", f"{mn['repeats']} × {mn['folds']} repeated stratified cross-validation "
                               f"({mn['n_test_folds']} test folds)"],
        ["Subset sizes", f"k ∈ {_k_set(sel['k_grid'])}; tolerance δ = {sel['margin']}"],
        ["Leaky reference protocol", f"full-sample ranking; k ∈ {_k_set(leaky)}; same folds and seeds"],
        ["Recursive feature elimination", f"step 1 to k = {sel['rfe_sizes'][0]}; first {sel['rfe_repeats']} repeats "
                                          f"({sel['rfe_repeats'] * cv['folds']} folds)"],
        ["Nested tuning", f"inner stratified {cv['inner_folds']}-fold grid search; first {cv['nested_repeats']} repeats "
                          f"({cv['nested_repeats'] * cv['folds']} outer folds)"],
        ["Bootstrap", f"{ev['bootstrap']:,} case resamples for pooled intervals and coefficients; "
                      f"{ev['optimism_bootstrap']} for Harrell optimism"],
        ["Learning curves", f"training fractions {min(fr)}–{max(fr)}; first {ev['learning_repeats']} repeats "
                            f"({ev['learning_repeats'] * cv['folds']} folds)"],
        ["Classification threshold", f"{ev['threshold']} (decision curves {a:.2f}–{b:.2f})"],
    ]
    b1 = {"id": "B1", "title": "Computational Environment, Configuration and Resampling Settings",
          "columns": ["Item", "Setting"], "rows": rows,
          "note": "All settings are read from config/study.yaml in the released package; changing any setting changes the "
                  "configuration fingerprint stored with the results. Wall-clock times are hardware-dependent.",
          "landscape": False, "part": "appendix", "widths": [2.0, 4.6], "group": None}

    rep = json.loads((ROOT / "results" / "consistency_report.json").read_text(encoding="utf-8"))
    if rep["n_fail"]:
        sys.exit(f"consistency gate reported {rep['n_fail']} failures; documents not built")
    fam = rep["by_family"]
    desc = [("Data", "A data", "Class counts in every confusion matrix; sensitivity, specificity and accuracy re-derived "
                               "from counts; identity with the UCI release"),
            ("Identity", "B identity", "k = 30 subset folds reproduce the full-feature folds; pooled AUCs recompute from "
                                       "out-of-fold arrays; array completeness"),
            ("Decision rules", "C rules", "Point and non-inferiority rules hold at the reported k and fail at every smaller "
                                          "k; net benefit and optimism identities; interval containment"),
            ("Tables", "C tables", "Every displayed cell equals the results store after rounding"),
            ("Figures", "D figures", "Every plotted value or legend value equals the corresponding table cell"),
            ("Format", "E format", "No missing-value strings or process labels; rectangular tables; non-blank 300-dpi "
                                   "figures"),
            ("Numbering", "F numbering", "Displays numbered in order of appearance; every cited table exists")]
    rows = [[lab, txt, str(fam[key]["count"]), str(fam[key]["sum"])] for lab, key, txt in desc]
    rows.append(["Total", "", str(rep["n_checks"]), str(rep["n_pass"])])
    b2 = {"id": "B2", "title": "Automated Consistency Checks Required Before Display Assembly",
          "columns": ["Family", "What is verified", "Checks", "Passed"], "rows": rows,
          "note": "Implemented in scripts/17_consistency.py of the released package; the full report is written to "
                  "results/consistency_report.json.",
          "landscape": False, "part": "appendix", "widths": [1.2, 3.8, 0.7, 0.7], "group": None}
    for spec in (b1, b2):
        (TAB / table_file(spec["id"])).write_text(json.dumps(spec, indent=1, ensure_ascii=False), encoding="utf-8")


# ------------------------------------------------------------------------------------------ documents
def new_document(heading):
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = FONT
    st.font.size = Pt(10)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Inches(8.5), Inches(11)
    for side in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
        setattr(sec, side, Inches(0.8))
    para(doc, heading, 11, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4)
    para(doc, TITLE, 10, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=2)
    para(doc, AUTHORS, 9, italic=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=12)
    doc.core_properties.title = f"{heading} — {TITLE}"
    doc.core_properties.author = AUTHORS
    return doc


def lay_out(doc, seq, specs, notes, headings=None):
    cur_land, first = False, True
    for kind, num in seq:
        if kind == "T":
            spec = specs[num]
            land = spec["landscape"]
        else:
            land = FIGURES[num].get("landscape", False)
        if first or land != cur_land or kind == "F" or (kind == "T" and len(spec["rows"]) > 6) or \
                (headings and num in headings and kind == headings[num][0]):
            new_section(doc, land, reuse=first)
            cur_land = land
        first = False
        if headings and num in headings and kind == headings[num][0]:
            para(doc, headings[num][1], 10, bold=True, space_after=6, keep_next=True)
        avail = (11 - 1.6) if land else (8.5 - 1.6)
        if kind == "T":
            add_table(doc, spec, num, avail, notes)
        else:
            add_figure(doc, FIGURES[num], num, FIGURES[num].get("width", 6.6 if not land else 9.0), notes)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--notes", action="store_true", help="print table and figure notes")
    a = ap.parse_args()
    write_record_tables()
    specs = {p.stem[len("table_"):]: json.loads(p.read_text(encoding="utf-8")) for p in TAB.glob("table_*.json")}

    doc = new_document("Tables and Figures of the Main Text")
    lay_out(doc, MAIN, specs, a.notes)
    doc.save(OUT_MAIN)
    print("saved", OUT_MAIN)

    doc = new_document("Supplementary Information: Tables and Figures")
    seq, heads = [], {}
    for _, heading, ds in APPENDICES:
        heads[ds[0][1]] = (ds[0][0], heading)
        seq += ds
    lay_out(doc, seq, specs, a.notes, heads)
    doc.save(OUT_SUPP)
    print("saved", OUT_SUPP)


if __name__ == "__main__":
    main()
