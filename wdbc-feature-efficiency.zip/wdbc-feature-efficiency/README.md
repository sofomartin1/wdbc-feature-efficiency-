# Feature-efficient machine-learning diagnosis of breast tumours (WDBC)

Analysis code for the article

> Boamah, M. K., Addo, P. C., & Dorgbefu, M., Jnr. **Feature-Efficient Machine-Learning Diagnosis of
> Breast Tumours: A Leakage-Free, Uncertainty-Aware Evaluation of Filter Feature Selection on the
> Wisconsin Diagnostic Dataset.**

The repository contains everything needed to reproduce every estimate, table and figure of the
article and its Supplementary Information from the public Wisconsin Diagnostic Breast Cancer (WDBC)
data: the data file, a single configuration file, the analysis library, the numbered pipeline
stages, an automated consistency gate, a tool that compares the regenerated tables cell by cell
with the article, and companion RapidMiner and SPSS files. Tables and figures are numbered exactly
as in the article.

| | |
|---|---|
| Task | Malignant vs benign classification of 569 breast fine-needle aspirates from 30 nuclear-morphometry features |
| Research questions | **RQ1** How do correlation, information-gain and chi-square ranking compare? **RQ2** What is the smallest feature subset whose AUC stays within 0.01 of the 30-feature model (point rule and non-inferiority rule)? **RQ3** Does the optimal subset depend on the classifier? |
| Classifiers | Logistic regression (LR), random forest (RF), gradient-boosted trees (GBT), AdaBoost, support vector machine with RBF kernel (SVM) |
| Validation | 10 × 10 repeated stratified cross-validation (100 test folds); feature ranking, top-k selection and z-standardisation refitted inside every training fold |
| Inference | Nadeau–Bengio corrected resampled t-tests, DeLong and exact McNemar tests with Holm adjustment; Nogueira selection stability; calibration and decision-curve analysis; bootstrap optimism correction |
| Master seed | 2026 (`config/study.yaml`) |
| Software | Python 3.13.16 (exact package versions in `requirements.txt`); companion RapidMiner Studio 7.1 process and IBM SPSS syntax |
| Run time | 48.8 min for the reported run on 2 CPU cores (Table B1); scales with the number of cores |

---

## Contents

1. [Dataset](#1-dataset)
2. [Repository layout](#2-repository-layout)
3. [Installation](#3-installation)
4. [Reproducing the results](#4-reproducing-the-results)
5. [Where each table and figure comes from](#5-where-each-table-and-figure-comes-from)
6. [Checking the results against the article](#6-checking-the-results-against-the-article)
7. [Methods implemented](#7-methods-implemented)
8. [Determinism and expected variation](#8-determinism-and-expected-variation)
9. [Companion files](#9-companion-files)
10. [Tests](#10-tests)
11. [Citation, licence and contact](#11-citation-licence-and-contact)
12. [References for the implemented methods](#12-references-for-the-implemented-methods)

---

## 1. Dataset

**Breast Cancer Wisconsin (Diagnostic)** — Wolberg, W., Mangasarian, O., Street, N., & Street, W. (1993).
UCI Machine Learning Repository. <https://doi.org/10.24432/C5DW2B>

| Property | Value |
|---|---|
| Dataset page | <https://archive.ics.uci.edu/dataset/17/breast+cancer+wisconsin+diagnostic> |
| DOI | [10.24432/C5DW2B](https://doi.org/10.24432/C5DW2B) |
| Licence | Creative Commons Attribution 4.0 International (CC BY 4.0) |
| Other distributions | scikit-learn `sklearn.datasets.load_breast_cancer()` (identical values, verified by stage 01 and the unit tests); Kaggle mirror <https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data> |
| Origin | Digitised images of fine-needle aspirates of breast masses, University of Wisconsin Hospitals, Madison; features computed from the traced boundaries of the cell nuclei (Street, Wolberg & Mangasarian, 1993, <https://doi.org/10.1117/12.148698>) |
| Unit of analysis | One aspirate image of one breast mass |
| Cases | 569 (212 malignant, 37.3%; 357 benign, 62.7%) |
| Features | 30 real-valued features; no missing values; no duplicate records |
| Outcome | `diagnosis` ∈ {`Malignant`, `Benign`}; **malignant is the positive class** throughout |

### Feature dictionary

Ten nuclear properties are measured for every nucleus in an image, and each is summarised three
ways per image, giving 3 × 10 = 30 features:

* `mean_<property>` — mean over all nuclei in the image;
* `<property>_error` — standard error of the property within the image;
* `worst_<property>` — mean of the three largest values in the image.

| Property | Definition |
|---|---|
| `radius` | mean distance from the centre to points on the nuclear perimeter |
| `texture` | standard deviation of grey-scale values |
| `perimeter` | nuclear perimeter |
| `area` | nuclear area |
| `smoothness` | local variation in radius lengths |
| `compactness` | perimeter² / area − 1.0 |
| `concavity` | severity of concave portions of the contour |
| `concave_points` | number of concave portions of the contour |
| `symmetry` | symmetry of the nucleus |
| `fractal_dimension` | "coastline approximation" − 1 |

`data/codebook.csv` lists every column with its label, family, definition, type and observed
range.

### Files in `data/`

| File | Description |
|---|---|
| `raw/wdbc_cleaned.csv` | Analysis file read by the pipeline: 569 rows; 30 feature columns with snake_case names; `diagnosis` recoded from M/B to Malignant/Benign. SHA-256 (LF line endings) `1d1596fade984ff1e3a17c7da9656eb456573c4e5d8def91544fd7bec2d8901f` |
| `raw/breast_cancer_wdbc_cleaned.xlsx` | The same data in Excel format, read by the RapidMiner processes |
| `codebook.csv` | Variable-level codebook |

No other preparation was applied: the UCI file has no missing values and no duplicates, the case
ID column is not used, and all 17,070 feature values and 569 labels are identical to the UCI
release. Details and a snippet that rebuilds the CSV from scikit-learn are in `data/README.md`.

---

## 2. Repository layout

```
wdbc-feature-efficiency/
├── config/study.yaml              all settings: seed, CV design, hyperparameters, grids, thresholds
├── data/
│   ├── raw/                       WDBC data (CSV for Python, XLSX for RapidMiner)
│   ├── codebook.csv               variable-level codebook
│   └── README.md                  data provenance and preparation
├── src/wdbcfs/                    analysis library
│   ├── config.py                  configuration loading and fingerprint
│   ├── data.py                    loading, validation, feature metadata
│   ├── selectors.py               correlation / information-gain / chi-square rankers; fold-internal TopK
│   ├── models.py                  classifier pipelines (selection -> standardisation -> classifier)
│   ├── cv.py                      shared repeated stratified splits and fold seeds
│   ├── metrics.py                 metrics, corrected resampled t, DeLong, McNemar, calibration,
│   │                              net benefit, Nogueira stability, Holm/BH adjustment
│   ├── store.py                   single results store (estimates.json + CSV tables + NPZ arrays)
│   └── figstyle.py                colours and style shared by all figures
├── scripts/                       numbered pipeline stages 01-18 (section 4) and display_plan.py
├── tools/compare_with_manuscript.py   cell-by-cell comparison with the article's Word files
├── tests/test_core.py             unit tests (14)
├── notebooks/walkthrough.ipynb    stage-by-stage walkthrough (committed without outputs)
├── rapidminer/wdbc_leakage_free_RM71.rmp   leakage-free RapidMiner Studio 7.1 process
├── spss/                          SPSS data file, its writer script and companion syntax
├── antecedent/                    outputs of the antecedent analysis, used for the reconciliation
├── run_all.py                     runs every stage in order
├── requirements.txt               exact package versions of the reported run
├── requirements-dev.txt           optional: tests, notebook, SPSS writer
├── CITATION.cff
└── LICENSE
```

`results/` is created by the pipeline and is excluded from version control (`.gitignore`); the
repository contains no generated outputs.

---

## 3. Installation

The reported results were produced with **Python 3.13.16** on Linux x86-64 (Table B1). No GPU is
needed. A virtual environment is recommended.

```bash
# download the repository (GitHub: Code > Download ZIP, or git clone), then:
cd wdbc-feature-efficiency
python -m venv .venv
# Windows: .venv\Scripts\activate        macOS / Linux: source .venv/bin/activate
pip install -r requirements.txt
pip install -r requirements-dev.txt      # optional: pytest, notebook, SPSS writer
pytest -q                                # 14 tests, a few seconds
```

`requirements.txt` pins the exact versions used for the reported results:

| Package | Version | Used for |
|---|---|---|
| numpy | 2.5.3 | arrays, linear algebra |
| pandas | 3.0.5 | tables, CSV and Excel input/output |
| scipy | 1.18.1 | distributions, rank statistics, clustering |
| scikit-learn | 1.9.1 | classifiers, cross-validation, feature scoring, RFE, permutation importance |
| statsmodels | 0.15.0 | variance inflation factors, calibration GLM, Wilson intervals |
| shap | 0.52.0 | SHAP values (Figure E2) |
| matplotlib | 3.11.2 | figures |
| joblib | 1.6.0 | parallel cross-validation folds |
| PyYAML | 6.0.3 | configuration file |
| python-docx | 1.2.0 | Word documents of the displays; comparison tool |
| openpyxl | 3.1.5 | reading the antecedent Excel results |
| pillow | 12.3.0 | figure checks in the consistency gate |

`requirements-dev.txt` adds pytest 9.1.1, nbformat 5.11.1, jupyter and pyreadstat 1.3.6. Other
package versions may change the last decimal places of tree-ensemble, boosting and
mutual-information estimates.

---

## 4. Reproducing the results

```bash
python run_all.py                 # every stage (48.8 min on 2 cores for the reported run)
python run_all.py --jobs 8        # choose the number of parallel workers (default: all cores)
python run_all.py --from 15       # re-render figures, tables and documents from existing results
```

Each stage can also be run on its own (`python scripts/05_subset_grid.py`), provided the stages it
reads from have run. `run_all.py` stops at the first failing stage and writes the wall-clock time
of every stage to `results/run_times.json`.

| Stage | Script | What it does | Main outputs in `results/` |
|---|---|---|---|
| 01 | `01_data_audit.py` | integrity, identity with the UCI copy, checksum, class-wise descriptives, univariate AUC, correlation, VIF | `tables/feature_descriptives.csv` |
| 02 | `02_main_cv.py` | five classifiers, 30 features, 10 × 10 CV | `tables/main_folds.csv`, `main_summary.csv`, `arrays/oof_main.npz` |
| 03 | `03_pairwise.py` | corrected resampled t, DeLong, McNemar; Holm | `tables/pairwise.csv` |
| 04 | `04_rankings.py` | full-sample rankings (descriptive) and their agreement | `tables/rankings_full.csv` |
| 05 | `05_subset_grid.py` | **leakage-free** top-k grid: 3 criteria × 16 k × LR/RF/GBT × 100 folds | `tables/subset_folds.csv`, `arrays/oof_subset.npz` |
| 06 | `06_leaky_grid.py` | antecedent protocol (ranking on all cases first) on the same folds | `tables/leaky_folds.csv` |
| 08 | `08_rfe.py` | classifier-specific recursive feature elimination (RQ3) | `tables/rfe_folds.csv` |
| 07 | `07_subset_summary.py` | smallest sufficient subsets, stability, criterion comparisons, optimism, compact-model rules | `tables/kstar.csv`, `stability.csv`, `optimism.csv` |
| 09 | `09_calibration_dca.py` | calibration, decision curves, pooled operating characteristics | `tables/calibration.csv`, `dca*.csv` |
| 10 | `10_compact_model.py` | compact logistic models fitted to all cases; bootstrap CIs; Harrell optimism | `tables/compact_coefficients_*.csv` |
| 11 | `11_interpretability.py` | permutation importance, SHAP | `tables/permutation_importance.csv`, `arrays/shap.npz` |
| 12 | `12_learning_curve.py` | AUC against training-set size | `tables/learning_curve.csv` |
| 13 | `13_sensitivity.py` | nested tuning, 5-fold CV, class weights, no scaling, log transform, feature-family restriction | `tables/sensitivity.csv` |
| 14 | `14_reconciliation.py` | reconciliation with the antecedent RapidMiner/Python outputs; misclassification analysis | `tables/reconciliation.csv` |
| 15 | `15_figures.py` | 19 figures (300 dpi) and a manifest of every plotted value | `figures/fig_<number>_<name>.png` |
| 16 | `16_tables.py` | 25 formatted display tables | `display_tables/table_<number>.json` |
| 17 | `17_consistency.py` | **consistency gate**: 1,037 checks across store, tables and figures | `consistency_report.json` |
| 18 | `18_document.py` | Tables B1–B2 (reproducibility record) and Word documents of all displays | `manuscript_displays.docx`, `supplementary_displays.docx` |

Stage 08 runs before stage 07 because stage 07 summarises its output.

---

## 5. Where each table and figure comes from

Every display is rendered only from the results store, under the number it carries in the article.
Display tables are written to `results/display_tables/table_<number>.json` (caption, column
headers, formatted cells and a note) and figures to `results/figures/fig_<number>_<name>.png`;
numbering, order and captions are defined in `scripts/display_plan.py`.

**Main text**

| Display | Content | Computed in stage |
|---|---|---|
| Table 1 | Composition, class separation and redundancy of the dataset | 01, 02 |
| Figure 1 | Leakage-free evaluation workflow | 15 |
| Table 2 | Classifier and feature-selection specifications | `config/study.yaml` |
| Figure 2 | Correlation structure and univariate discrimination | 01 |
| Table 3 | Full-feature performance of the five classifiers | 02 |
| Figure 3 | Pooled ROC and precision–recall curves | 02 |
| Table 4 | Pairwise classifier comparisons | 03 |
| Table 5 | Feature relevance under the three filter criteria | 04 |
| Table 6 | Filter criteria at fixed subset sizes (RQ1) | 05, 07 |
| Figure 4 | Stability of fold-internal selection | 05, 07 |
| Figure 5 | AUC against the number of retained features | 05, 07 |
| Table 7 | Smallest feature subsets retaining the 30-feature AUC (RQ2) | 07 |
| Table 8 | Model dependence of the optimal subset (RQ3) | 08, 07 |
| Table 9 | Calibration and clinical utility | 09 |
| Figure 6 | Reliability diagram and decision curves | 09 |
| Table 10 | Five-feature compact logistic model | 10 |
| Figure 7 | Compact models: odds ratios and bootstrap selection frequency | 10 |
| Figure 8 | Optimism of ranking before cross-validation | 06, 07 |

**Supplementary Information**

| Display | Content | Computed in stage |
|---|---|---|
| Table A1, Figure A1 | Descriptive statistics; class-conditional distributions | 01, 04 |
| Table B1 | Computational environment, configuration, resampling settings and run time of the run | 18 |
| Table B2 | Outcome of the consistency gate by check family | 17, 18 |
| Figure C1 | Fold-level AUC and paired AUC differences | 02, 03 |
| Table C1, Figure C2 | Pooled operating characteristics and confusion matrices | 09 |
| Table C2, Figure C3, Table C3 | Error agreement across classifiers; profile of persistently misclassified cases | 14 |
| Table D1, Figure D1 | Complete full-sample rankings | 04 |
| Table D2 | Fold-paired comparisons between criteria | 07 |
| Table D3 | Stability at every subset size | 07 |
| Table D4 | Complete leakage-free performance grid | 07 |
| Figure D2 | RFE selection frequency | 08, 07 |
| Table E1 | Net benefit at five thresholds | 09 |
| Table E2 | 15-feature compact logistic model | 10 |
| Table E3, Figure E1 | Learning curves | 12 |
| Figure E2 | SHAP explanations | 11 |
| Figure E3 | Permutation importance | 11 |
| Table F1 | Optimism of ranking before cross-validation | 06, 07 |
| Table F2, Figure F1 | Sensitivity analyses | 13 |
| Table F3, Figure F2 | Reconciliation with the antecedent outputs | 14 |
| Table F4 | Computational cost per training fold | 02 |

The Word documents built by stage 18 use the article's caption style ("Table N: Title",
"Figure N. Caption"). Table notes are stored in the JSON files; `python scripts/18_document.py
--notes` prints them in the documents as well.

---

## 6. Checking the results against the article

### Consistency gate (stage 17)

`17_consistency.py` re-derives the displayed numbers from the results store and runs 1,037
checks in seven families (Table B2): class counts and confusion-matrix identities; identities
between analyses (the k = 30 arm of the subset grid reproduces stage 02 fold by fold; pooled AUCs
recompute from the out-of-fold arrays); decision rules (the point and non-inferiority rules hold at
the reported k and fail at every smaller k; net-benefit and optimism identities; interval
containment); every displayed cell against the store after rounding; every plotted value against
the corresponding table cell; formatting (no missing-value strings, rectangular tables, non-blank
300-dpi figures); and numbering (displays numbered in order of appearance, every cited table
exists). The Word documents are built only if all checks pass. Tables B1 and B2, which record the
run and the gate itself, are assembled after the gate.

### Cell-by-cell comparison with the article

`tools/compare_with_manuscript.py` reads the article's Word files and compares every table
caption, column header and cell, and every figure caption, with the regenerated displays:

```bash
python tools/compare_with_manuscript.py \
    --manuscript Manuscript.docx --supplementary Supplementary.docx --report comparison.json
```

Text is compared after normalising whitespace and minus signs only. Cells that describe the
computer used for the run — software versions, hardware and run time in Table B1, and the
timings of Table F4 — are listed separately as machine-dependent. The exit status is 0 when all
other captions, headers and cells agree.

---

## 7. Methods implemented

* **Pre-processing.** z-standardisation with training-fold means and standard deviations, inside
  the model pipeline.
* **Filter criteria.** Absolute point-biserial (Pearson) correlation with the label; k-nearest-
  neighbour mutual information (3 neighbours); chi-square statistic on min–max scaled features.
  Ranked inside each training fold; top-k subsets for k ∈ {1, …, 10, 12, 15, 18, 20, 25, 30}.
* **Classifiers.** Hyperparameters fixed before analysis (`config/study.yaml`, Table 2): LR (L2,
  C = 1, L-BFGS), RF (300 trees, max features √p), GBT (150 trees, learning rate 0.1, depth 3,
  subsample 0.8), AdaBoost (200 stumps, learning rate 0.5), SVM (RBF, C = 1, γ = 1/(p·Var(X)),
  Platt-scaled probabilities by internal 5-fold CV). A nested 5-fold grid search is reported as a
  sensitivity analysis.
* **Inference.** Nadeau–Bengio corrected resampled t statistic for fold-paired differences
  (variance factor 1/J + n_test/n_train, df = J − 1); DeLong and exact McNemar tests on pooled
  out-of-fold predictions (each case's probability averaged over the 10 repeats); Holm
  adjustment within families; Benjamini–Hochberg for the univariate tests.
* **RQ2 decision rules.** Point rule: smallest k whose mean ΔAUC ≥ −0.01. Non-inferiority rule:
  smallest k whose corrected 95% lower confidence limit of ΔAUC ≥ −0.01.
* **Compact models.** Compact LR (5): five features from the criterion with the most stable
  fold-internal top five (information gain). Compact LR (15): the smallest LR subset meeting the
  non-inferiority rule (correlation, k = 15). Both specifications are fixed by these rules in
  `07_subset_summary.py`, never by the test-fold AUC of the candidates; both are refitted on all
  cases with 2,000-resample bootstrap intervals and Harrell optimism correction over 500
  resamples in which selection is repeated.
* **Selection stability.** Nogueira, Sechidis & Brown (2018) index over the 100 training folds.
* **RQ3.** Recursive feature elimination (step 1, k = 5) by absolute standardised coefficient (LR)
  or impurity importance (RF, GBT) inside 50 training folds.
* **Calibration and utility.** Brier and scaled Brier scores; calibration slope from the logistic
  recalibration model and calibration-in-the-large (intercept with the slope fixed at 1);
  expected calibration error (10 equal-frequency bins); net benefit and decision curves; 2,000
  case-level bootstrap resamples.
* **Further analyses.** Permutation importance on held-out folds, SHAP values, learning curves,
  six sensitivity analyses, the leaky reference protocol (ranking on all cases before
  validation) and the reconciliation with the antecedent RapidMiner outputs.

---

## 8. Determinism and expected variation

All randomness is seeded from `master_seed` (2026). Test folds come from one
`RepeatedStratifiedKFold(n_splits=10, n_repeats=10, random_state=2026)` shared by every stage,
and the model seed of a fold depends only on (repeat, fold): fold seed = 2026 + 100 × repeat +
fold, both zero-based. The k = 30 rows of the subset grid therefore reproduce stage 02 exactly,
which the consistency gate checks. Results do not depend on the number of parallel workers.

Changing any value in `config/study.yaml` changes the configuration fingerprint stored in
`results/estimates.json` and printed in Table B1 (`0080d3854d0a41bb` for the released file).

With the package versions in `requirements.txt`, every estimate reproduces to the printed
precision. Only the following describe the computer used and vary between runs: the software
versions, hardware and run time in Table B1, and the wall-clock timings in Table F4.

---

## 9. Companion files

### Walkthrough notebook (`notebooks/walkthrough.ipynb`)

Runs the stages one by one and shows intermediate results (committed without outputs). Requires
the optional packages in `requirements-dev.txt`.

### RapidMiner (`rapidminer/wdbc_leakage_free_RM71.rmp`)

A RapidMiner Studio 7.1 process that mirrors the leakage-free design: malignancy set as the
positive class (Nominal to Binominal + Remap Binominals), z-transformation fitted inside each
training fold and grouped with the learner, 10-fold stratified X-Validation (seed 2026) for LR,
RF and AdaBoost, and a fourth validation in which information-gain weighting and top-5
selection are performed inside the training fold and passed to the test fold. Before running,
set the two process macros (*Process > Context > Macros*): `data_file` (full path to
`data/raw/breast_cancer_wdbc_cleaned.xlsx`) and `output_dir` (folder for the performance
files). RapidMiner's implementations differ from scikit-learn's (for example, its logistic
regression is a kernel logistic regression), so its values differ in the decimals; the Python
pipeline is the reference implementation.

### SPSS (`spss/`)

* `wdbc_cleaned.sav` — the data with variable and value labels (`malignant`: 1 = Malignant,
  0 = Benign; `case_id`: row number of the UCI file); values identical to the CSV.
* `make_sav.py` — regenerates the `.sav` from the CSV (requires pyreadstat).
* `descriptives.sps` — class-wise descriptives, Mann–Whitney tests and ROC areas (Table A1) and
  an unpenalised maximum-likelihood fit of the five-feature logistic model of Table 10.

### Antecedent outputs (`antecedent/`)

RapidMiner 7.1 performance vectors, information-gain weights, the antecedent RapidMiner process
and the antecedent Python results workbook. Stage 14 parses them to re-derive malignant-class
sensitivity from the stored confusion matrices (Table F3, Figure F2). See `antecedent/README.md`.

---

## 10. Tests

```bash
pytest -q
```

The 14 unit tests cover data integrity and identity with the scikit-learn copy of WDBC, the
DeLong implementation against scikit-learn's AUC, the corrected resampled t statistic, the
Nogueira index, net-benefit identities, Holm adjustment, fold-internal top-k selection, the
configuration fingerprint, the display numbering of the article and the data codebook.

---

## 11. Citation, licence and contact

If you use this code, please cite the article (see `CITATION.cff`) and the dataset:

> Wolberg, W., Mangasarian, O., Street, N., & Street, W. (1993). *Breast Cancer Wisconsin (Diagnostic)*
> [Data set]. UCI Machine Learning Repository. https://doi.org/10.24432/C5DW2B

**Licence.** Code: MIT (see `LICENSE`). Data: CC BY 4.0, © the original authors; redistributed
here unchanged apart from column renaming and label recoding.

**Authors.** Martin Konadu Boamah¹, Prince Clement Addo², Maxwell Dorgbefu Jnr²
¹ Department of Information Technology Education, Faculty of Technical Education, University of
Skills Training and Entrepreneurial Development (USTED), Kumasi, Ghana.
² Faculty of Technical Education, University of Skills Training and Entrepreneurial Development
(USTED), Kumasi, Ghana.

**Contact.** Martin Konadu Boamah (corresponding author), academics005@gmail.com

---

## 12. References for the implemented methods

* Nadeau, C., & Bengio, Y. (2003). Inference for the generalization error. *Machine Learning, 52*, 239–281. https://doi.org/10.1023/A:1024068626366
* Bates, S., Hastie, T., & Tibshirani, R. (2024). Cross-validation: What does it estimate and how well does it do it? *Journal of the American Statistical Association, 119*(546), 1434–1445. https://doi.org/10.1080/01621459.2023.2197686
* DeLong, E. R., DeLong, D. M., & Clarke-Pearson, D. L. (1988). Comparing the areas under two or more correlated ROC curves. *Biometrics, 44*(3), 837–845. https://doi.org/10.2307/2531595
* Sun, X., & Xu, W. (2014). Fast implementation of DeLong's algorithm. *IEEE Signal Processing Letters, 21*(11), 1389–1393. https://doi.org/10.1109/LSP.2014.2337313
* Nogueira, S., Sechidis, K., & Brown, G. (2018). On the stability of feature selection algorithms. *Journal of Machine Learning Research, 18*(174), 1–54.
* Kraskov, A., Stögbauer, H., & Grassberger, P. (2004). Estimating mutual information. *Physical Review E, 69*, 066138. https://doi.org/10.1103/PhysRevE.69.066138
* Vickers, A. J., & Elkin, E. B. (2006). Decision curve analysis. *Medical Decision Making, 26*(6), 565–574. https://doi.org/10.1177/0272989X06295361
* Vickers, A. J., Van Calster, B., Wynants, L., & Steyerberg, E. W. (2023). Decision curve analysis: Confidence intervals and hypothesis testing for net benefit. *Diagnostic and Prognostic Research, 7*, 11. https://doi.org/10.1186/s41512-023-00148-y
* Collins, G. S., Dhiman, P., Ma, J., et al. (2024). Evaluation of clinical prediction models (part 1): From development to external validation. *BMJ, 384*, e074819. https://doi.org/10.1136/bmj-2023-074819
* Kapoor, S., & Narayanan, A. (2023). Leakage and the reproducibility crisis in machine-learning-based science. *Patterns, 4*(9), 100804. https://doi.org/10.1016/j.patter.2023.100804
* Street, W. N., Wolberg, W. H., & Mangasarian, O. L. (1993). Nuclear feature extraction for breast tumor diagnosis. *Proc. SPIE 1905*, 861–870. https://doi.org/10.1117/12.148698
