* SPSS companion syntax (IBM SPSS Statistics 26 or later).
* Reproduces the class-wise descriptives and Mann-Whitney tests of Table A1, the
* univariate ROC areas, and an unpenalised check of the five-feature logistic model.
* Open spss/wdbc_cleaned.sav first (File > Open > Data), then run all.
* The Python pipeline is the reference implementation. The logistic model below is
* unpenalised maximum likelihood. Worst radius and worst perimeter are almost collinear with
* worst area (VIFs of 119.8 and 111.3 in Table 10), so without the L2 penalty the individual
* coefficients change in size and, for worst radius and worst perimeter, in sign, while the
* apparent AUC of the two fits is almost the same (0.989 vs 0.988). Read the coefficients
* jointly, as in the article.

* 1. Class-wise means and SDs (Table A1, columns 2-3).
MEANS TABLES=mean_radius TO worst_fractal_dimension BY malignant
  /CELLS=MEAN STDDEV COUNT.

* 2. Mann-Whitney U tests (Table A1, q column before Benjamini-Hochberg adjustment).
NPAR TESTS
  /M-W= mean_radius TO worst_fractal_dimension BY malignant(0 1)
  /MISSING ANALYSIS.

* 3. Univariate ROC areas with DeLong-type standard errors (Table A1, AUC column).
ROC mean_radius TO worst_fractal_dimension BY malignant (1)
  /PLOT=NONE
  /PRINT=SE
  /CRITERIA=CUTOFF(INCLUDE) TESTPOS(LARGE) DISTRIBUTION(FREE) CI(95)
  /MISSING=EXCLUDE.

* 4. Five-feature logistic model (features of Table 10), standardised inputs.
DESCRIPTIVES VARIABLES=mean_concave_points worst_radius worst_perimeter worst_area worst_concave_points
  /SAVE.
LOGISTIC REGRESSION VARIABLES malignant
  /METHOD=ENTER Zmean_concave_points Zworst_radius Zworst_perimeter Zworst_area Zworst_concave_points
  /PRINT=CI(95)
  /CRITERIA=PIN(.05) POUT(.10) ITERATE(100) CUT(.5).
