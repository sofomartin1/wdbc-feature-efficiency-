"""Write the WDBC data to an SPSS .sav file with variable and value labels.

    python spss/make_sav.py      ->  spss/wdbc_cleaned.sav

Requires pyreadstat (pip install -r requirements-dev.txt). The released .sav contains the
same 569 x 30 feature values and labels as data/raw/wdbc_cleaned.csv, plus case_id
(row number) and malignant (1 = Malignant, 0 = Benign).
"""
import sys
from pathlib import Path

import pandas as pd
import pyreadstat

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from wdbcfs.data import pretty  # noqa: E402

df = pd.read_csv(ROOT / "data" / "raw" / "wdbc_cleaned.csv")
df.insert(0, "case_id", range(1, len(df) + 1))
df["malignant"] = (df["diagnosis"] == "Malignant").astype(int)
df = df.drop(columns="diagnosis")
labels = {c: pretty(c) for c in df.columns if c not in ("case_id", "malignant")}
labels.update(case_id="Case number (row order of the UCI file)", malignant="Diagnosis (1 = malignant, 0 = benign)")
pyreadstat.write_sav(df, ROOT / "spss" / "wdbc_cleaned.sav", column_labels=labels,
                     variable_value_labels={"malignant": {0: "Benign", 1: "Malignant"}},
                     variable_measure={**{c: "scale" for c in labels if c not in ("malignant", "case_id")},
                                       "malignant": "nominal", "case_id": "nominal"})
print("wrote", ROOT / "spss" / "wdbc_cleaned.sav", df.shape)
