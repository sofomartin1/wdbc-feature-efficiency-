"""Run the complete analysis pipeline end to end.

    python run_all.py              # every stage, then the consistency gate, then the Word documents
    python run_all.py --from 15    # re-render figures, tables and documents from existing results
    python run_all.py --jobs 4     # parallel workers for the cross-validation stages

The Word documents are built only if the consistency gate (stage 17) passes. The wall-clock
time of every stage is written to results/run_times.json (reported in Table B1).
"""
import json
import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STAGES = [
    ("01", "01_data_audit.py"), ("02", "02_main_cv.py"), ("03", "03_pairwise.py"), ("04", "04_rankings.py"),
    ("05", "05_subset_grid.py"), ("06", "06_leaky_grid.py"), ("08", "08_rfe.py"), ("07", "07_subset_summary.py"),
    ("09", "09_calibration_dca.py"), ("10", "10_compact_model.py"), ("11", "11_interpretability.py"),
    ("12", "12_learning_curve.py"), ("13", "13_sensitivity.py"), ("14", "14_reconciliation.py"),
    ("15", "15_figures.py"), ("16", "16_tables.py"), ("17", "17_consistency.py"), ("18", "18_document.py"),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="start", default="01", help="first stage to run (e.g. 15)")
    ap.add_argument("--jobs", type=int, default=None, help="parallel workers (default: all CPU cores)")
    a = ap.parse_args()
    env = dict(os.environ, PYTHONWARNINGS="ignore")
    if a.jobs:
        env["WDBC_JOBS"] = str(a.jobs)
    order = [s for s, _ in STAGES]
    if a.start not in order:
        sys.exit(f"unknown stage {a.start}; choose from {order}")
    t0 = time.time()
    times_path = ROOT / "results" / "run_times.json"
    times = json.loads(times_path.read_text(encoding="utf-8")) if times_path.exists() and a.start != "01" else {}
    for stage, script in STAGES[order.index(a.start):]:
        print(f"\n=== stage {stage}: {script}", flush=True)
        ts = time.time()
        r = subprocess.run([sys.executable, str(ROOT / "scripts" / script)], cwd=ROOT, env=env)
        if r.returncode != 0:
            sys.exit(f"stage {stage} failed (exit {r.returncode}); later stages not run")
        times[stage] = round(time.time() - ts, 1)
        times_path.parent.mkdir(parents=True, exist_ok=True)
        times_path.write_text(json.dumps(times, indent=1), encoding="utf-8")
    print(f"\nAll stages complete in {(time.time() - t0) / 60:.1f} min. Outputs in results/.")


if __name__ == "__main__":
    main()
