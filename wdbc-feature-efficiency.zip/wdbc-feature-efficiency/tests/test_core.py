"""Unit tests for the statistical core. Run with:  pytest -q"""
import sys
from pathlib import Path

import numpy as np
import pytest
from sklearn.metrics import roc_auc_score

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from wdbcfs import data, metrics  # noqa: E402
from wdbcfs.config import fingerprint, load_config  # noqa: E402
from wdbcfs.selectors import TopK, rank_from_scores, score_features  # noqa: E402

CFG = load_config()
RNG = np.random.default_rng(0)


def test_data_integrity():
    X, y, feats = data.load(CFG)
    assert X.shape == (569, 30)
    assert y.sum() == 212
    assert len({data.feature_family(f) for f in feats}) == 3


def test_matches_uci_copy():
    from sklearn.datasets import load_breast_cancer
    X, y, _ = data.load(CFG)
    bc = load_breast_cancer()
    assert np.array_equal(X.to_numpy(), bc.data)
    assert np.array_equal(y, (bc.target == 0).astype(int))


def test_delong_matches_sklearn():
    y = RNG.integers(0, 2, 300)
    p = RNG.random(300) + 0.3 * y
    a, _ = metrics.delong(y, [p])
    assert a[0] == pytest.approx(roc_auc_score(y, p), abs=1e-12)


def test_delong_ci_contains_point():
    y = RNG.integers(0, 2, 200)
    p = RNG.random(200) + 0.5 * y
    a, lo, hi = metrics.delong_ci(y, p)
    assert lo < a < hi


def test_delong_diff_zero_for_identical():
    y = RNG.integers(0, 2, 200)
    p = RNG.random(200)
    d, lo, hi, pv = metrics.delong_diff(y, p, p + 1e-12 * RNG.random(200))
    assert abs(d) < 1e-6


def test_corrected_t_wider_than_naive():
    v = RNG.normal(0.01, 0.02, 100)
    c = metrics.corrected_t(v, 512, 57)
    naive = v.std(ddof=1) / np.sqrt(100)
    assert c["se"] > naive


def test_nogueira_bounds():
    Z = np.zeros((10, 30))
    Z[:, :5] = 1
    assert metrics.nogueira(Z) == pytest.approx(1.0)
    Zr = np.zeros((200, 30))
    for i in range(200):
        Zr[i, RNG.choice(30, 5, replace=False)] = 1
    assert abs(metrics.nogueira(Zr)) < 0.1


def test_net_benefit_treat_all_identity():
    y = RNG.integers(0, 2, 500)
    p = np.ones(500)
    for t in (0.1, 0.3):
        assert metrics.net_benefit(y, p, t) == pytest.approx(metrics.net_benefit_all(y, t))


def test_holm_monotone():
    p = np.array([0.01, 0.04, 0.03, 0.2])
    adj = metrics.holm(p)
    assert np.all(adj >= p) and adj.max() <= 1


def test_topk_uses_training_data_only():
    X, y, _ = data.load(CFG)
    Xn = X.to_numpy()
    tr = np.arange(300)
    sel = TopK("Correlation", 5).fit(Xn[tr], y[tr])
    expected = np.sort(rank_from_scores(score_features(Xn[tr], y[tr], "Correlation"))[:5])
    assert np.array_equal(sel.support_, expected)


def test_topk_full_keeps_original_order():
    X, y, _ = data.load(CFG)
    sel = TopK("ChiSquare", 30).fit(X.to_numpy(), y)
    assert np.array_equal(sel.support_, np.arange(30))


def test_fingerprint_order_independent():
    assert fingerprint({"a": 1, "b": 2}) == fingerprint({"b": 2, "a": 1})


def test_display_numbering_matches_article():
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
    from display_plan import APPENDICES, FIGURES, MAIN, TABLES
    assert [n for k, n in MAIN if k == "T"] == [str(i) for i in range(1, 11)]
    assert [n for k, n in MAIN if k == "F"] == [str(i) for i in range(1, 9)]
    app_t = [n for _, _, ds in APPENDICES for k, n in ds if k == "T"]
    app_f = [n for _, _, ds in APPENDICES for k, n in ds if k == "F"]
    assert app_t == ["A1", "B1", "B2", "C1", "C2", "C3", "D1", "D2", "D3", "D4", "E1", "E2", "E3",
                     "F1", "F2", "F3", "F4"]
    assert app_f == ["A1", "C1", "C2", "C3", "D1", "D2", "E1", "E2", "E3", "F1", "F2"]
    assert set(FIGURES) == {n for k, n in MAIN if k == "F"} | set(app_f)
    assert len(TABLES) == 27


def test_codebook_matches_data():
    import pandas as pd
    root = Path(__file__).resolve().parents[1]
    cb = pd.read_csv(root / "data" / "codebook.csv")
    df = pd.read_csv(root / "data" / "raw" / "wdbc_cleaned.csv")
    assert cb["column"].tolist() == df.columns.tolist()
    num = cb[cb["type"] == "real"]
    assert np.allclose(num["min"].astype(float), df[num["column"]].min().to_numpy(), rtol=1e-5)
    assert np.allclose(num["max"].astype(float), df[num["column"]].max().to_numpy(), rtol=1e-5)
