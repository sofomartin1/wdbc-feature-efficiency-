# Antecedent analysis outputs

This folder holds the outputs of the authors' earlier (antecedent) analysis of the same
WDBC data. They are **inputs to the reconciliation in Table F3 and Figure F2** of the
Supplementary Information and are not used by any other analysis. The present study
re-examines the antecedent conclusions with the leakage-free protocol of the main pipeline.

The antecedent analysis addressed the same three research questions as the present study
(RQ1 comparison of correlation, information-gain and chi-square ranking; RQ2 smallest subset
within 1% of the 30-feature AUC; RQ3 linear versus ensemble classifiers), following the
aggregated filter-ranking approach of Sreehari & Dhinesh Babu (2025),
<https://doi.org/10.1038/s41598-025-87826-7>.

## Files

| File | Content | Read by |
|---|---|---|
| `antecedent_process_RM71.rmp` | RapidMiner Studio 7.1 process of the antecedent analysis (see below) | – (record) |
| `performance_Logistic_Regression.per` | RapidMiner performance vector written by that process: logistic regression | `scripts/14_reconciliation.py` |
| `performance_Random_Forest.per` | Same, random forest | `scripts/14_reconciliation.py` |
| `performance_Boosted_Trees_AdaBoost.per` | Same, AdaBoost (boosted decision trees) | `scripts/14_reconciliation.py` |
| `Weight_by_Information_Gain.wgt` | Information-gain feature weights computed on all 569 cases | – (record) |
| `results_summary.xlsx` | Results of the antecedent Python analysis: sheets `Perf_Full30`, `Confusion_Matrices`, `FS_Grid`, `FS_AUC_Pivot`, `Feature_Weights` | `scripts/14_reconciliation.py` (sheet `Perf_Full30`) |

## The antecedent RapidMiner process

`antecedent_process_RM71.rmp` reads `breast_cancer_wdbc_cleaned.xlsx` (Read Excel), sets
`diagnosis` as the label (Set Role) and runs three 10-fold stratified cross-validations
(X-Validation, local random seed 2026):

* Logistic Regression;
* Random Forest, 100 trees, gain-ratio criterion, maximal depth 10;
* AdaBoost of decision trees, 30 iterations, gain-ratio criterion, maximal depth 10.

It also computes information-gain weights of the 30 features on all cases (Weight by
Information Gain) and writes the three performance vectors and the weights (Write
Performance, Write Weights). The process does not standardise the features and does not
declare a positive class, so RapidMiner used **Benign** as the positive class; the `.per`
files record `positiveClassName = Benign`. The precision and recall it reported therefore
describe the benign class. Stage 14 re-derives malignant-class sensitivity and specificity
from the confusion matrices stored in the `.per` files (Table F3).

The leakage-free RapidMiner counterpart used in the present study is
`rapidminer/wdbc_leakage_free_RM71.rmp`.

## Key results of the antecedent analysis

From `results_summary.xlsx`, sheet `Perf_Full30` (single 10-fold cross-validation, all 30
features, malignant as positive class):

| Classifier | Accuracy | AUC | Precision | Recall (sensitivity) | Specificity | F-measure | Kappa |
|---|---|---|---|---|---|---|---|
| Logistic regression | 0.982 | 0.995 | 0.986 | 0.967 | 0.992 | 0.976 | 0.962 |
| Random forest | 0.961 | 0.989 | 0.952 | 0.943 | 0.972 | 0.948 | 0.917 |
| Gradient-boosted trees | 0.961 | 0.990 | 0.961 | 0.934 | 0.978 | 0.947 | 0.917 |

Smallest subset reported within 1% of the full-feature AUC: k = 5 with correlation ranking
for logistic regression (AUC 0.987, sheet `FS_Grid`). In the antecedent analysis the
features were ranked on all 569 cases before cross-validation; stage 06 of the present
pipeline reproduces that protocol on the same folds to measure its optimism (Table F1,
Figure 8).

## Changes made for this release

* The process file was renamed from `Study2_BreastCancer_RM71.rmp` to
  `antecedent_process_RM71.rmp`.
* The absolute file paths of the authors' computer in the Read Excel, Write Performance and
  Write Weights operators were replaced by the process macros `%{data_file}` and
  `%{output_dir}` (set them under *Process > Context > Macros* before running).

No other content of any file in this folder was changed.
